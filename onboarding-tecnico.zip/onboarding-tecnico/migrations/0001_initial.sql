-- 0001_initial.sql
-- Modelo de dados da Plataforma de Onboarding Técnico.
-- Datas em ISO-8601 UTC (TEXT). Booleanos como INTEGER 0/1.

CREATE TABLE users (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  name             TEXT    NOT NULL,
  email            TEXT    NOT NULL UNIQUE COLLATE NOCASE,
  password_hash    TEXT    NOT NULL,
  role             TEXT    NOT NULL CHECK (role IN ('admin','manager','collaborator')),
  active           INTEGER NOT NULL DEFAULT 1,
  manager_id       INTEGER REFERENCES users(id) ON DELETE SET NULL,
  job_title        TEXT,
  start_date       TEXT,                       -- data de início do onboarding (AAAA-MM-DD)
  session_version  INTEGER NOT NULL DEFAULT 1, -- incrementa para invalidar sessões
  failed_logins    INTEGER NOT NULL DEFAULT 0,
  locked_until     TEXT,
  must_change_password INTEGER NOT NULL DEFAULT 0,
  is_demo          INTEGER NOT NULL DEFAULT 0, -- dados de demonstração
  last_login_at    TEXT,
  last_activity_at TEXT,
  created_at       TEXT    NOT NULL,
  updated_at       TEXT    NOT NULL
);
CREATE INDEX idx_users_manager ON users(manager_id);

CREATE TABLE tracks (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  title          TEXT NOT NULL,
  description    TEXT NOT NULL DEFAULT '',
  status         TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','archived')),
  expected_days  INTEGER NOT NULL DEFAULT 30,  -- prazo esperado para concluir (ritmo)
  created_by     INTEGER REFERENCES users(id) ON DELETE SET NULL,
  published_at   TEXT,
  created_at     TEXT NOT NULL,
  updated_at     TEXT NOT NULL
);

CREATE TABLE track_assignments (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  track_id     INTEGER NOT NULL REFERENCES tracks(id) ON DELETE CASCADE,
  user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  assigned_by  INTEGER REFERENCES users(id) ON DELETE SET NULL,
  assigned_at  TEXT NOT NULL,
  completed_at TEXT,
  UNIQUE (track_id, user_id)
);
CREATE INDEX idx_assign_user ON track_assignments(user_id);

CREATE TABLE modules (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  track_id          INTEGER NOT NULL REFERENCES tracks(id) ON DELETE CASCADE,
  title             TEXT NOT NULL,
  description       TEXT NOT NULL DEFAULT '',
  objectives        TEXT NOT NULL DEFAULT '',  -- um objetivo por linha
  position          INTEGER NOT NULL DEFAULT 0,
  estimated_minutes INTEGER,
  active            INTEGER NOT NULL DEFAULT 1,
  created_at        TEXT NOT NULL,
  updated_at        TEXT NOT NULL
);
CREATE INDEX idx_modules_track ON modules(track_id, position);

CREATE TABLE module_prerequisites (
  module_id          INTEGER NOT NULL REFERENCES modules(id) ON DELETE CASCADE,
  requires_module_id INTEGER NOT NULL REFERENCES modules(id) ON DELETE CASCADE,
  PRIMARY KEY (module_id, requires_module_id),
  CHECK (module_id <> requires_module_id)
);

CREATE TABLE lessons (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  module_id         INTEGER NOT NULL REFERENCES modules(id) ON DELETE CASCADE,
  title             TEXT NOT NULL,
  summary           TEXT NOT NULL DEFAULT '',
  body              TEXT NOT NULL DEFAULT '',   -- Markdown seguro (renderizado no servidor)
  video_url         TEXT,
  position          INTEGER NOT NULL DEFAULT 0,
  required          INTEGER NOT NULL DEFAULT 1,
  -- 'confirm': colaborador abre a aula e confirma a leitura
  -- 'activity': concluída quando a atividade vinculada for aprovada
  completion_rule   TEXT NOT NULL DEFAULT 'confirm' CHECK (completion_rule IN ('confirm','activity')),
  min_seconds       INTEGER NOT NULL DEFAULT 0, -- tempo mínimo na aula antes de confirmar
  estimated_minutes INTEGER,
  active            INTEGER NOT NULL DEFAULT 1,
  created_at        TEXT NOT NULL,
  updated_at        TEXT NOT NULL
);
CREATE INDEX idx_lessons_module ON lessons(module_id, position);

CREATE TABLE materials (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  lesson_id   INTEGER NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
  kind        TEXT NOT NULL CHECK (kind IN ('link','file')),
  title       TEXT NOT NULL,
  url         TEXT,
  stored_name TEXT,       -- nome aleatório no disco
  original_name TEXT,
  mime        TEXT,
  size_bytes  INTEGER,
  position    INTEGER NOT NULL DEFAULT 0,
  created_by  INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at  TEXT NOT NULL
);
CREATE INDEX idx_materials_lesson ON materials(lesson_id);

CREATE TABLE activities (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  module_id       INTEGER NOT NULL REFERENCES modules(id) ON DELETE CASCADE,
  lesson_id       INTEGER REFERENCES lessons(id) ON DELETE SET NULL,
  title           TEXT NOT NULL,
  description     TEXT NOT NULL DEFAULT '',
  instructions    TEXT NOT NULL DEFAULT '',
  -- quiz: objetivo; open: resposta aberta; case: estudo de caso; simulation: simulação de atendimento;
  -- practical: atividade prática com evidência; final: avaliação final (objetiva)
  kind            TEXT NOT NULL CHECK (kind IN ('quiz','open','case','simulation','practical','final')),
  pass_percent    INTEGER NOT NULL DEFAULT 70 CHECK (pass_percent BETWEEN 0 AND 100),
  max_attempts    INTEGER NOT NULL DEFAULT 3 CHECK (max_attempts >= 0), -- 0 = ilimitado
  -- immediate: mostra gabarito ao enviar; after_close: só depois de aprovado ou sem tentativas; never
  feedback_mode   TEXT NOT NULL DEFAULT 'immediate' CHECK (feedback_mode IN ('immediate','after_close','never')),
  required        INTEGER NOT NULL DEFAULT 1,
  position        INTEGER NOT NULL DEFAULT 0,
  active          INTEGER NOT NULL DEFAULT 1,
  published       INTEGER NOT NULL DEFAULT 1,
  version         INTEGER NOT NULL DEFAULT 1, -- incrementa a cada edição de questões/critérios
  created_at      TEXT NOT NULL,
  updated_at      TEXT NOT NULL
);
CREATE INDEX idx_activities_module ON activities(module_id, position);

CREATE TABLE questions (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  activity_id INTEGER NOT NULL REFERENCES activities(id) ON DELETE CASCADE,
  qtype       TEXT NOT NULL CHECK (qtype IN ('single','multiple','truefalse','open')),
  prompt      TEXT NOT NULL,
  explanation TEXT NOT NULL DEFAULT '',
  points      REAL NOT NULL DEFAULT 1 CHECK (points >= 0),
  position    INTEGER NOT NULL DEFAULT 0,
  active      INTEGER NOT NULL DEFAULT 1,
  created_at  TEXT NOT NULL,
  updated_at  TEXT NOT NULL
);
CREATE INDEX idx_questions_activity ON questions(activity_id, position);

CREATE TABLE question_options (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  question_id INTEGER NOT NULL REFERENCES questions(id) ON DELETE CASCADE,
  text        TEXT NOT NULL,
  is_correct  INTEGER NOT NULL DEFAULT 0,
  position    INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX idx_options_question ON question_options(question_id, position);

CREATE TABLE attempts (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  activity_id      INTEGER NOT NULL REFERENCES activities(id) ON DELETE CASCADE,
  user_id          INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  number           INTEGER NOT NULL,             -- nº da tentativa do usuário nesta atividade
  activity_version INTEGER NOT NULL,
  -- in_progress: rascunho; pending_review: aguardando correção; graded: corrigida (auto ou manual)
  status           TEXT NOT NULL CHECK (status IN ('in_progress','pending_review','graded')),
  started_at       TEXT NOT NULL,
  submitted_at     TEXT,
  score            REAL,
  max_score        REAL,
  percent          REAL,
  pass_percent     INTEGER NOT NULL,             -- critério vigente no envio (snapshot)
  passed           INTEGER,                      -- NULL até corrigir
  correct_count    INTEGER,
  wrong_count      INTEGER,
  evidence_text    TEXT,
  evidence_url     TEXT,
  evidence_file    TEXT,                         -- stored_name
  evidence_original TEXT,
  graded_by        INTEGER REFERENCES users(id) ON DELETE SET NULL,
  graded_at        TEXT,
  feedback         TEXT,
  UNIQUE (activity_id, user_id, number)
);
CREATE INDEX idx_attempts_user ON attempts(user_id, activity_id);
CREATE INDEX idx_attempts_status ON attempts(status);

CREATE TABLE attempt_answers (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  attempt_id       INTEGER NOT NULL REFERENCES attempts(id) ON DELETE CASCADE,
  question_id      INTEGER REFERENCES questions(id) ON DELETE SET NULL,
  question_snapshot TEXT NOT NULL,              -- JSON: enunciado, tipo, alternativas, gabarito, pontos
  selected_options TEXT,                         -- JSON: lista de ids de alternativas
  text_answer      TEXT,
  is_correct       INTEGER,                      -- NULL para abertas até corrigir
  points_awarded   REAL,
  reviewer_comment TEXT
);
CREATE INDEX idx_answers_attempt ON attempt_answers(attempt_id);
CREATE INDEX idx_answers_question ON attempt_answers(question_id);

CREATE TABLE lesson_progress (
  user_id         INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  lesson_id       INTEGER NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
  first_viewed_at TEXT NOT NULL,
  last_viewed_at  TEXT NOT NULL,
  view_count      INTEGER NOT NULL DEFAULT 1,
  completed_at    TEXT,
  PRIMARY KEY (user_id, lesson_id)
);

CREATE TABLE events (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind       TEXT NOT NULL,   -- lesson_viewed, lesson_completed, attempt_submitted, attempt_graded, login...
  ref_type   TEXT,
  ref_id     INTEGER,
  detail     TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_events_user ON events(user_id, created_at);

CREATE TABLE audit_log (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  actor_id   INTEGER REFERENCES users(id) ON DELETE SET NULL,
  action     TEXT NOT NULL,
  entity     TEXT NOT NULL,
  entity_id  INTEGER,
  detail     TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_audit_created ON audit_log(created_at);
