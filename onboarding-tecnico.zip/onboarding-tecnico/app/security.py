"""Autenticação, sessão, CSRF, autorização por perfil e cabeçalhos de segurança."""
import hmac
import secrets
from datetime import datetime, timedelta, timezone
from functools import wraps

from flask import abort, current_app, flash, g, redirect, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

from .db import one, run
from .utils import now_iso, parse_iso

STAFF_ROLES = ("admin", "manager")


# ---------- senhas ----------
def hash_password(raw):
    return generate_password_hash(raw, method="scrypt")


def verify_password(hashed, raw):
    try:
        return check_password_hash(hashed, raw)
    except (ValueError, TypeError):
        return False


def password_problems(raw):
    problems = []
    if len(raw or "") < current_app.config["PASSWORD_MIN_LENGTH"]:
        problems.append(f"ter pelo menos {current_app.config['PASSWORD_MIN_LENGTH']} caracteres")
    if raw and (raw.isdigit() or raw.isalpha()):
        problems.append("misturar letras e números ou símbolos")
    return problems


# ---------- sessão ----------
def login_user(user):
    session.clear()
    session.permanent = True
    session["uid"] = user["id"]
    session["sv"] = user["session_version"]
    session["csrf"] = secrets.token_urlsafe(32)


def logout_user():
    session.clear()


def load_current_user():
    g.user = None
    uid = session.get("uid")
    if not uid:
        return
    user = one("SELECT * FROM users WHERE id = ?", (uid,))
    # Usuário removido, desativado ou com sessão revogada (troca de senha/desativação) perde o acesso.
    if user is None or not user["active"] or user["session_version"] != session.get("sv"):
        session.clear()
        return
    g.user = user


def touch_activity(user_id):
    run("UPDATE users SET last_activity_at = ? WHERE id = ?", (now_iso(), user_id))


def is_locked(user):
    until = parse_iso(user["locked_until"])
    return until is not None and until > datetime.now(timezone.utc)


def register_failure(user):
    fails = user["failed_logins"] + 1
    lock = None
    if fails >= current_app.config["LOGIN_MAX_FAILURES"]:
        lock = (datetime.now(timezone.utc) + timedelta(minutes=current_app.config["LOGIN_LOCK_MINUTES"])) \
            .replace(microsecond=0).isoformat()
        fails = 0
    run("UPDATE users SET failed_logins = ?, locked_until = ? WHERE id = ?", (fails, lock, user["id"]))
    return lock


# ---------- CSRF ----------
def csrf_token():
    tok = session.get("csrf")
    if not tok:
        tok = secrets.token_urlsafe(32)
        session["csrf"] = tok
    return tok


def check_csrf():
    if request.method in ("GET", "HEAD", "OPTIONS"):
        return
    sent = request.form.get("csrf_token") or request.headers.get("X-CSRF-Token") or ""
    tok = session.get("csrf") or ""
    if not tok or not hmac.compare_digest(sent, tok):
        abort(400, description="Sessão expirada ou formulário inválido. Recarregue a página e tente de novo.")


# ---------- autorização ----------
def login_required(view):
    @wraps(view)
    def wrapped(*a, **kw):
        if g.get("user") is None:
            if request.path.startswith("/api/"):
                abort(401)
            flash("Entre com sua conta para continuar.", "info")
            return redirect(url_for("auth.login", next=request.full_path if request.query_string else request.path))
        if g.user["must_change_password"] and request.endpoint not in ("account.password", "auth.logout", "static"):
            flash("Defina uma nova senha para continuar.", "info")
            return redirect(url_for("account.password"))
        return view(*a, **kw)

    return wrapped


def roles_required(*roles):
    def deco(view):
        @wraps(view)
        @login_required
        def wrapped(*a, **kw):
            if g.user["role"] not in roles:
                abort(403)
            return view(*a, **kw)

        return wrapped

    return deco


staff_required = roles_required(*STAFF_ROLES)
admin_required = roles_required("admin")


def is_staff(user=None):
    u = user or g.get("user")
    return bool(u) and u["role"] in STAFF_ROLES


def can_view_user(viewer, target):
    """Regra de visibilidade de dados individuais (progresso, respostas, notas)."""
    if viewer is None or target is None:
        return False
    if viewer["id"] == target["id"]:
        return True
    if viewer["role"] == "admin":
        return True
    if viewer["role"] == "manager":
        return target["role"] == "collaborator" and target["manager_id"] == viewer["id"]
    return False


def visible_collaborators_sql(viewer):
    """Cláusula SQL + parâmetros para restringir consultas aos colaboradores visíveis pelo usuário."""
    if viewer["role"] == "admin":
        return "u.role = 'collaborator'", ()
    if viewer["role"] == "manager":
        return "u.role = 'collaborator' AND u.manager_id = ?", (viewer["id"],)
    return "u.id = ?", (viewer["id"],)


def require_view_user(target):
    if target is None:
        abort(404)
    if not can_view_user(g.user, target):
        abort(403)


# ---------- cabeçalhos ----------
def apply_security_headers(resp):
    resp.headers.setdefault(
        "Content-Security-Policy",
        "default-src 'self'; img-src 'self' data: https:; style-src 'self'; style-src-attr 'unsafe-inline'; "
        "script-src 'self'; "
        "font-src 'self'; frame-ancestors 'none'; form-action 'self'; base-uri 'self'; object-src 'none'",
    )
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("X-Frame-Options", "DENY")
    resp.headers.setdefault("Referrer-Policy", "same-origin")
    resp.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    if current_app.config.get("SESSION_COOKIE_SECURE"):
        resp.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
    if g.get("user") is not None and "Cache-Control" not in resp.headers:
        resp.headers["Cache-Control"] = "no-store"
    return resp


def audit(action, entity, entity_id=None, detail=None):
    actor = g.user["id"] if g.get("user") is not None else None
    run(
        "INSERT INTO audit_log(actor_id, action, entity, entity_id, detail, created_at) VALUES (?,?,?,?,?,?)",
        (actor, action, entity, entity_id, detail, now_iso()),
    )


def log_event(user_id, kind, ref_type=None, ref_id=None, detail=None):
    run(
        "INSERT INTO events(user_id, kind, ref_type, ref_id, detail, created_at) VALUES (?,?,?,?,?,?)",
        (user_id, kind, ref_type, ref_id, detail, now_iso()),
    )
