"""Formatação de datas, números e percentuais no padrão pt-BR, e utilidades gerais."""
import json
from datetime import datetime, timezone, date
from zoneinfo import ZoneInfo

from flask import current_app

MONTHS = ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"]


def now_iso():
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def parse_iso(s):
    if not s:
        return None
    if isinstance(s, datetime):
        return s
    try:
        d = datetime.fromisoformat(s)
    except ValueError:
        return None
    if d.tzinfo is None:
        d = d.replace(tzinfo=timezone.utc)
    return d


def _tz():
    try:
        return ZoneInfo(current_app.config.get("TIMEZONE", "America/Sao_Paulo"))
    except Exception:
        return ZoneInfo("America/Sao_Paulo")


def fmt_datetime(s):
    d = parse_iso(s)
    if not d:
        return "—"
    d = d.astimezone(_tz())
    return d.strftime("%d/%m/%Y %H:%M")


def fmt_date(s):
    if not s:
        return "—"
    if isinstance(s, str) and len(s) == 10:
        try:
            d = date.fromisoformat(s)
            return d.strftime("%d/%m/%Y")
        except ValueError:
            return s
    d = parse_iso(s)
    if not d:
        return "—"
    return d.astimezone(_tz()).strftime("%d/%m/%Y")


def fmt_relative(s):
    d = parse_iso(s)
    if not d:
        return "nunca"
    delta = datetime.now(timezone.utc) - d
    secs = int(delta.total_seconds())
    if secs < 60:
        return "agora"
    mins = secs // 60
    if mins < 60:
        return f"há {mins} min"
    hrs = mins // 60
    if hrs < 24:
        return f"há {hrs} h"
    days = hrs // 24
    if days == 1:
        return "ontem"
    if days < 30:
        return f"há {days} dias"
    return fmt_date(s)


def fmt_percent(v, digits=0):
    if v is None:
        return "—"
    s = f"{v:.{digits}f}".replace(".", ",")
    return f"{s}%"


def fmt_number(v, digits=1):
    if v is None:
        return "—"
    if float(v).is_integer():
        return str(int(v))
    return f"{v:.{digits}f}".replace(".", ",")


def fmt_minutes(m):
    if not m:
        return None
    m = int(m)
    if m < 60:
        return f"{m} min"
    h, r = divmod(m, 60)
    return f"{h} h {r:02d} min" if r else f"{h} h"


def today_local():
    return datetime.now(_tz()).date()


def days_since(date_str):
    if not date_str:
        return None
    try:
        d = date.fromisoformat(date_str[:10])
    except ValueError:
        return None
    return (today_local() - d).days


def jdump(v):
    return json.dumps(v, ensure_ascii=False)


def jload(s, default=None):
    if not s:
        return default
    try:
        return json.loads(s)
    except (TypeError, ValueError):
        return default


def to_int(v, default=None, lo=None, hi=None):
    try:
        n = int(str(v).strip())
    except (TypeError, ValueError):
        return default
    if lo is not None and n < lo:
        return default
    if hi is not None and n > hi:
        return default
    return n


ROLE_LABELS = {"admin": "Administrador", "manager": "Gestor", "collaborator": "Colaborador"}
KIND_LABELS = {
    "quiz": "Questionário",
    "open": "Resposta aberta",
    "case": "Estudo de caso",
    "simulation": "Simulação de atendimento",
    "practical": "Atividade prática",
    "final": "Avaliação final",
}
QTYPE_LABELS = {
    "single": "Múltipla escolha (uma resposta)",
    "multiple": "Múltipla escolha (várias respostas)",
    "truefalse": "Verdadeiro ou falso",
    "open": "Resposta aberta",
}
TRACK_STATUS_LABELS = {"draft": "Rascunho", "published": "Publicada", "archived": "Arquivada"}
