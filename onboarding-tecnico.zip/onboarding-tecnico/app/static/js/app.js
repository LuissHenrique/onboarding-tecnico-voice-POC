/* Interações progressivas. Todas as regras de negócio ficam no servidor; sem este arquivo os
   formulários continuam funcionando. */
(function () {
  "use strict";
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  /* menu lateral no celular */
  var app = $(".app");
  var navBtn = $("#navToggle");
  function setNav(open) {
    if (!app) return;
    app.classList.toggle("nav-open", open);
    if (navBtn) navBtn.setAttribute("aria-expanded", String(open));
    if (open) { var first = $(".sidebar a"); if (first) first.focus(); }
  }
  if (navBtn) navBtn.addEventListener("click", function () { setNav(!app.classList.contains("nav-open")); });
  var ov = $(".overlay");
  if (ov) ov.addEventListener("click", function () { setNav(false); });
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && app && app.classList.contains("nav-open")) { setNav(false); if (navBtn) navBtn.focus(); }
  });

  /* fechar mensagens */
  $$(".alert .close").forEach(function (b) {
    b.addEventListener("click", function () { b.closest(".alert").remove(); });
  });
  $$(".alert-success[data-autoclose]").forEach(function (a) {
    setTimeout(function () { if (a.isConnected) a.remove(); }, 7000);
  });

  /* confirmação antes de ações destrutivas: <form data-confirm="Texto" data-confirm-ok="Excluir"> */
  var dlg = $("#confirmDialog");
  var pending = null;
  /* também vale para botões: <button data-confirm="..."> pede confirmação só para aquele botão */
  $$("form").forEach(function (f) {
    f.addEventListener("submit", function (e) {
      var src = (e.submitter && e.submitter.dataset.confirm) ? e.submitter : (f.dataset.confirm ? f : null);
      if (!src || f.dataset.confirmed === "1") return;
      if (!dlg || typeof dlg.showModal !== "function") return; // sem suporte: envia direto (o servidor valida)
      e.preventDefault();
      e.stopImmediatePropagation();
      pending = { form: f, submitter: e.submitter || null };
      $("#confirmTitle").textContent = src.dataset.confirmTitle || "Confirmar ação";
      $("#confirmText").textContent = src.dataset.confirm;
      var ok = $("#confirmOk");
      ok.textContent = src.dataset.confirmOk || "Confirmar";
      ok.className = "btn " + (src.dataset.confirmTone === "primary" ? "btn-primary" : "btn-danger");
      dlg.showModal();
      ok.focus();
    });
  });
  if (dlg) {
    $("#confirmOk").addEventListener("click", function () {
      if (!pending) return;
      var f = pending.form, s = pending.submitter;
      f.dataset.confirmed = "1";
      dlg.close();
      f.dataset.dirty = "";
      if (s && s.name) {
        var h = document.createElement("input");
        h.type = "hidden"; h.name = s.name; h.value = s.value; f.appendChild(h);
      }
      if (s) s.classList.add("loading");
      f.submit();
    });
    $("#confirmCancel").addEventListener("click", function () { dlg.close(); pending = null; });
  }

  /* estado de carregamento nos envios */
  $$("form").forEach(function (f) {
    f.addEventListener("submit", function (e) {
      if (e.defaultPrevented) return;
      var b = e.submitter;
      if (b && b.classList.contains("btn") && !b.hasAttribute("data-no-loading")) {
        setTimeout(function () { b.classList.add("loading"); b.setAttribute("aria-busy", "true"); }, 0);
      }
      f.dataset.dirty = "";
    });
  });

  /* copiar blocos de código */
  $$("[data-copy]").forEach(function (b) {
    b.addEventListener("click", function () {
      var pre = b.closest("figure").querySelector("pre");
      var text = pre.innerText;
      var done = function () { b.textContent = "Copiado"; setTimeout(function () { b.textContent = "Copiar"; }, 1500); };
      var fallback = function () {
        var r = document.createRange(); r.selectNodeContents(pre);
        var s = window.getSelection(); s.removeAllRanges(); s.addRange(r); b.textContent = "Selecionado";
      };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(done, fallback);
      else fallback();
    });
  });

  /* tempo mínimo de leitura da aula */
  var timer = $("[data-min-seconds]");
  if (timer) {
    var left = parseInt(timer.dataset.minSeconds, 10) || 0;
    var btns = $$("[data-requires-timer]");
    var label = $("#timerLabel");
    var tick = function () {
      if (left <= 0) {
        btns.forEach(function (b) { b.disabled = false; b.removeAttribute("aria-disabled"); });
        if (label) label.textContent = "";
        return;
      }
      btns.forEach(function (b) { b.disabled = true; b.setAttribute("aria-disabled", "true"); });
      if (label) {
        var m = Math.floor(left / 60), s = left % 60;
        label.textContent = "Disponível em " + m + ":" + (s < 10 ? "0" : "") + s;
      }
      left -= 1;
      setTimeout(tick, 1000);
    };
    tick();
  }

  /* aviso de respostas não salvas */
  $$("form[data-dirty-guard]").forEach(function (f) {
    f.addEventListener("input", function () { f.dataset.dirty = "1"; });
    window.addEventListener("beforeunload", function (e) {
      if (f.dataset.dirty === "1") { e.preventDefault(); e.returnValue = ""; }
    });
  });

  /* contador de respostas no questionário */
  var quiz = $("form[data-quiz]");
  if (quiz) {
    var counter = $("#answeredCount");
    var update = function () {
      var qs = $$(".question", quiz), n = 0;
      qs.forEach(function (q) {
        var ok = $$("input:checked", q).length > 0 || $$("textarea", q).some(function (t) { return t.value.trim(); });
        if (ok) n += 1;
      });
      if (counter) counter.textContent = n + " de " + qs.length + " respondidas";
    };
    quiz.addEventListener("change", update);
    quiz.addEventListener("input", update);
    update();
  }

  /* alternativas no formulário de questão */
  var optWrap = $("#options");
  var typeSel = $("#qtype");
  function syncType() {
    if (!typeSel) return;
    var t = typeSel.value;
    $$("[data-for-type]").forEach(function (el) {
      el.hidden = el.dataset.forType.split(" ").indexOf(t) === -1;
    });
  }
  if (typeSel) { typeSel.addEventListener("change", syncType); syncType(); }
  if (optWrap) {
    var reindex = function () {
      $$(".opt-row", optWrap).forEach(function (row, i) {
        var cb = $("input[type=checkbox]", row); cb.value = String(i);
        var txt = $("input[type=text]", row); txt.setAttribute("aria-label", "Alternativa " + (i + 1));
      });
    };
    $("#addOption").addEventListener("click", function () {
      var rows = $$(".opt-row", optWrap);
      if (rows.length >= 10) return;
      var clone = rows[rows.length - 1].cloneNode(true);
      $("input[type=text]", clone).value = "";
      $("input[type=checkbox]", clone).checked = false;
      optWrap.appendChild(clone);
      reindex();
      $("input[type=text]", clone).focus();
    });
    optWrap.addEventListener("click", function (e) {
      var b = e.target.closest("[data-remove-option]");
      if (!b) return;
      var rows = $$(".opt-row", optWrap);
      if (rows.length <= 2) return;
      b.closest(".opt-row").remove();
      reindex();
    });
  }

  /* nome do arquivo selecionado */
  $$("input[type=file][data-filename]").forEach(function (inp) {
    var out = document.getElementById(inp.dataset.filename);
    inp.addEventListener("change", function () {
      if (out) out.textContent = inp.files && inp.files[0] ? inp.files[0].name : "";
    });
  });

  /* auto-envio de filtros select */
  $$("select[data-autosubmit]").forEach(function (s) {
    s.addEventListener("change", function () { s.form.requestSubmit ? s.form.requestSubmit() : s.form.submit(); });
  });
})();
