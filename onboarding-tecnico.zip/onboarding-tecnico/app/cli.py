"""Comandos de linha de comando: flask --app wsgi <comando>."""
import getpass

import click

from .db import Tx, connect, migrate, one, run
from .security import hash_password, password_problems
from .utils import now_iso


def register(app):
    @app.cli.command("db-migrate")
    def db_migrate():
        """Aplica as migrações pendentes."""
        conn = connect(app.config["DATABASE_PATH"])
        try:
            done = migrate(conn)
        finally:
            conn.close()
        click.echo("Migrações aplicadas: " + (", ".join(done) if done else "nenhuma pendente"))

    @app.cli.command("create-admin")
    @click.option("--email", prompt="E-mail")
    @click.option("--name", prompt="Nome completo")
    @click.option("--password", default=None, help="Se omitido, será solicitado de forma oculta.")
    def create_admin(email, name, password):
        """Cria o primeiro administrador (ou promove um usuário existente)."""
        email = email.strip().lower()
        if password is None:
            password = getpass.getpass("Senha: ")
            if password != getpass.getpass("Repita a senha: "):
                raise click.ClickException("As senhas não conferem.")
        probs = password_problems(password)
        if probs:
            raise click.ClickException("A senha precisa " + " e ".join(probs) + ".")
        ts = now_iso()
        with Tx():
            row = one("SELECT id FROM users WHERE email = ?", (email,))
            if row:
                run("UPDATE users SET role='admin', active=1, password_hash=?, name=?, updated_at=?, "
                    "session_version = session_version + 1 WHERE id=?", (hash_password(password), name, ts, row["id"]))
                click.echo(f"Usuário {email} promovido a administrador.")
            else:
                run("INSERT INTO users(name,email,password_hash,role,active,created_at,updated_at) "
                    "VALUES (?,?,?,'admin',1,?,?)", (name, email, hash_password(password), ts, ts))
                click.echo(f"Administrador {email} criado.")

    @app.cli.command("seed-content")
    @click.option("--publish/--draft", default=True)
    def seed_content(publish):
        """Carrega a trilha de onboarding WideVoice (seed/widevoice_track.json)."""
        from .seed import load_track
        tid = load_track(publish=publish)
        click.echo(f"Trilha carregada (id {tid}).")

    @app.cli.command("seed-demo")
    def seed_demo():
        """Cria gestor e colaboradores de DEMONSTRAÇÃO com progresso simulado."""
        from .seed import load_demo
        info = load_demo()
        click.echo("Dados de demonstração criados. Contas (senha para todas: %s):" % info["password"])
        for e in info["emails"]:
            click.echo("  " + e)

    @app.cli.command("remove-demo")
    def remove_demo():
        """Remove todos os usuários marcados como demonstração (e seus registros)."""
        with Tx():
            n = one("SELECT COUNT(*) FROM users WHERE is_demo = 1")[0]
            run("DELETE FROM users WHERE is_demo = 1")
        click.echo(f"{n} usuário(s) de demonstração removido(s).")
