"""Tentativas, correção automática e correção manual.

Regras explícitas sobre edição de atividades já respondidas:
- Editar questões, alternativas, pontos ou critérios incrementa `activities.version`.
- Tentativas enviadas guardam um snapshot das questões e o critério vigente (`attempts.pass_percent`);
  a nota e a aprovação delas NUNCA são recalculadas.
- Aprovação obtida em versão anterior continua valendo para o progresso.
- Rascunho (tentativa em andamento) de versão anterior é descartado ao detectar a mudança, sem
  consumir tentativa, e o colaborador recomeça na versão nova.
"""
from ..db import one, q, run
from ..security import log_event
from ..utils import jdump, jload, now_iso

MANUAL_KINDS = {"open", "case", "simulation", "practical"}


class GradingError(Exception):
    pass


def questions_for(activity_id):
    qs = [dict(r) for r in q(
        "SELECT * FROM questions WHERE activity_id = ? AND active = 1 ORDER BY position, id", (activity_id,))]
    if qs:
        ph = ",".join("?" * len(qs))
        opts = q(f"SELECT * FROM question_options WHERE question_id IN ({ph}) ORDER BY position, id",
                 [x["id"] for x in qs])
        by = {}
        for o in opts:
            by.setdefault(o["question_id"], []).append(dict(o))
        for x in qs:
            x["options"] = by.get(x["id"], [])
    return qs


def snapshot(question):
    return {
        "id": question["id"],
        "qtype": question["qtype"],
        "prompt": question["prompt"],
        "explanation": question["explanation"],
        "points": question["points"],
        "options": [{"id": o["id"], "text": o["text"], "is_correct": bool(o["is_correct"])} for o in question["options"]],
    }


def needs_manual(activity, questions):
    if activity["kind"] in MANUAL_KINDS:
        return True
    return any(x["qtype"] == "open" for x in questions)


def validate_activity(activity, questions):
    """Uma atividade só pode ser respondida se estiver consistente."""
    if activity["kind"] == "practical":
        return None
    if not questions:
        return "Esta atividade ainda não tem questões cadastradas."
    for x in questions:
        if x["qtype"] in ("single", "truefalse"):
            if sum(1 for o in x["options"] if o["is_correct"]) != 1:
                return f"A questão “{x['prompt'][:60]}” precisa de exatamente uma alternativa correta."
        if x["qtype"] == "multiple" and not any(o["is_correct"] for o in x["options"]):
            return f"A questão “{x['prompt'][:60]}” precisa de pelo menos uma alternativa correta."
    return None


def start_attempt(activity, user_id, state):
    if state["draft"] is not None:
        return state["draft"]["id"]
    if not state["can_start"]:
        raise GradingError("Não há tentativas disponíveis para esta atividade.")
    qs = questions_for(activity["id"])
    problem = validate_activity(activity, qs)
    if problem:
        raise GradingError(problem)
    number = (one("SELECT COALESCE(MAX(number),0) FROM attempts WHERE activity_id = ? AND user_id = ?",
                  (activity["id"], user_id))[0]) + 1
    aid = run(
        "INSERT INTO attempts(activity_id, user_id, number, activity_version, status, started_at, pass_percent) "
        "VALUES (?,?,?,?, 'in_progress', ?, ?)",
        (activity["id"], user_id, number, activity["version"], now_iso(), activity["pass_percent"]),
    )
    for x in qs:
        run("INSERT INTO attempt_answers(attempt_id, question_id, question_snapshot) VALUES (?,?,?)",
            (aid, x["id"], jdump(snapshot(x))))
    log_event(user_id, "attempt_started", "activity", activity["id"], f"tentativa {number}")
    return aid


def discard_if_outdated(attempt, activity):
    if attempt["status"] == "in_progress" and attempt["activity_version"] != activity["version"]:
        run("DELETE FROM attempts WHERE id = ?", (attempt["id"],))
        return True
    return False


def save_answers(attempt, form):
    """Grava as respostas do formulário (rascunho ou envio). Retorna nº de questões sem resposta."""
    answers = q("SELECT * FROM attempt_answers WHERE attempt_id = ?", (attempt["id"],))
    blank = 0
    for ans in answers:
        snap = jload(ans["question_snapshot"], {})
        key = f"q_{ans['id']}"
        if snap.get("qtype") == "open":
            text = (form.get(key) or "").strip()[:20000]
            if not text:
                blank += 1
            run("UPDATE attempt_answers SET text_answer = ? WHERE id = ?", (text or None, ans["id"]))
        else:
            valid = {o["id"] for o in snap.get("options", [])}
            raw = form.getlist(key) if hasattr(form, "getlist") else form.get(key, [])
            chosen = []
            for v in raw:
                try:
                    v = int(v)
                except (TypeError, ValueError):
                    continue
                if v in valid and v not in chosen:
                    chosen.append(v)
            if snap.get("qtype") in ("single", "truefalse"):
                chosen = chosen[:1]
            if not chosen:
                blank += 1
            run("UPDATE attempt_answers SET selected_options = ? WHERE id = ?", (jdump(chosen), ans["id"]))
    return blank


def _auto_grade(answers):
    score = max_score = 0.0
    correct = wrong = 0
    manual_pending = False
    for ans in answers:
        snap = jload(ans["question_snapshot"], {})
        pts = float(snap.get("points") or 0)
        max_score += pts
        if snap.get("qtype") == "open":
            manual_pending = True
            continue
        right = {o["id"] for o in snap.get("options", []) if o["is_correct"]}
        chosen = set(jload(ans["selected_options"], []) or [])
        ok = bool(chosen) and chosen == right
        awarded = pts if ok else 0.0
        score += awarded
        correct += ok
        wrong += (not ok)
        run("UPDATE attempt_answers SET is_correct = ?, points_awarded = ? WHERE id = ?",
            (1 if ok else 0, awarded, ans["id"]))
    return score, max_score, correct, wrong, manual_pending


def submit_attempt(attempt, activity, evidence=None):
    """Finaliza a tentativa. Objetivas são corrigidas na hora; abertas/práticas vão para correção."""
    if attempt["status"] != "in_progress":
        raise GradingError("Esta tentativa já foi enviada.")
    answers = q("SELECT * FROM attempt_answers WHERE attempt_id = ?", (attempt["id"],))
    ts = now_iso()
    if activity["kind"] == "practical":
        ev = evidence or {}
        if not (ev.get("text") or ev.get("url") or ev.get("file")):
            raise GradingError("Envie uma descrição, um link ou um arquivo como evidência.")
        run(
            "UPDATE attempts SET status = 'pending_review', submitted_at = ?, evidence_text = ?, evidence_url = ?, "
            "evidence_file = ?, evidence_original = ?, max_score = 100 WHERE id = ?",
            (ts, ev.get("text"), ev.get("url"), ev.get("file"), ev.get("original"), attempt["id"]),
        )
        log_event(attempt["user_id"], "attempt_submitted", "activity", activity["id"], "aguardando correção")
        return "pending_review"
    score, max_score, correct, wrong, manual = _auto_grade(answers)
    manual = manual or activity["kind"] in MANUAL_KINDS
    if manual:
        run(
            "UPDATE attempts SET status = 'pending_review', submitted_at = ?, score = ?, max_score = ?, "
            "correct_count = ?, wrong_count = ? WHERE id = ?",
            (ts, score, max_score, correct, wrong, attempt["id"]),
        )
        log_event(attempt["user_id"], "attempt_submitted", "activity", activity["id"], "aguardando correção")
        return "pending_review"
    pct = (score / max_score * 100) if max_score else 0.0
    passed = 1 if pct + 1e-9 >= attempt["pass_percent"] else 0
    run(
        "UPDATE attempts SET status = 'graded', submitted_at = ?, graded_at = ?, score = ?, max_score = ?, "
        "percent = ?, passed = ?, correct_count = ?, wrong_count = ? WHERE id = ?",
        (ts, ts, score, max_score, pct, passed, correct, wrong, attempt["id"]),
    )
    log_event(attempt["user_id"], "attempt_graded", "activity", activity["id"],
              f"{'aprovado' if passed else 'reprovado'} com {pct:.0f}%")
    return "graded"


def grade_manual(attempt, grader_id, per_answer, feedback, practical_percent=None):
    """per_answer: {answer_id: (pontos, comentário)} para questões abertas."""
    if attempt["status"] != "pending_review":
        raise GradingError("Esta tentativa não está aguardando correção.")
    ts = now_iso()
    if practical_percent is not None:
        pct = float(practical_percent)
        if not 0 <= pct <= 100:
            raise GradingError("A nota deve estar entre 0 e 100.")
        passed = 1 if pct + 1e-9 >= attempt["pass_percent"] else 0
        run(
            "UPDATE attempts SET status = 'graded', score = ?, max_score = 100, percent = ?, passed = ?, "
            "graded_by = ?, graded_at = ?, feedback = ? WHERE id = ?",
            (pct, pct, passed, grader_id, ts, feedback, attempt["id"]),
        )
    else:
        answers = q("SELECT * FROM attempt_answers WHERE attempt_id = ?", (attempt["id"],))
        score = max_score = 0.0
        correct = attempt["correct_count"] or 0
        wrong = attempt["wrong_count"] or 0
        for ans in answers:
            snap = jload(ans["question_snapshot"], {})
            pts = float(snap.get("points") or 0)
            max_score += pts
            if snap.get("qtype") == "open":
                if ans["id"] not in per_answer:
                    raise GradingError("Atribua pontos a todas as respostas abertas.")
                given, comment = per_answer[ans["id"]]
                if given is None or given < 0 or given > pts + 1e-9:
                    raise GradingError(f"Os pontos de cada resposta devem ficar entre 0 e {pts:g}.")
                ok = 1 if given + 1e-9 >= pts else 0
                correct += ok
                wrong += (1 - ok)
                run("UPDATE attempt_answers SET points_awarded = ?, is_correct = ?, reviewer_comment = ? WHERE id = ?",
                    (given, ok, comment or None, ans["id"]))
                score += given
            else:
                score += float(ans["points_awarded"] or 0)
        pct = (score / max_score * 100) if max_score else 0.0
        passed = 1 if pct + 1e-9 >= attempt["pass_percent"] else 0
        run(
            "UPDATE attempts SET status = 'graded', score = ?, max_score = ?, percent = ?, passed = ?, "
            "correct_count = ?, wrong_count = ?, graded_by = ?, graded_at = ?, feedback = ? WHERE id = ?",
            (score, max_score, pct, passed, correct, wrong, grader_id, ts, feedback, attempt["id"]),
        )
    log_event(attempt["user_id"], "attempt_graded", "activity", attempt["activity_id"],
              f"{'aprovado' if passed else 'reprovado'} com {pct:.0f}% (correção manual)")
    return passed


def can_show_answers(activity, state, attempt):
    """Quando o colaborador pode ver o gabarito da tentativa."""
    if attempt["status"] != "graded":
        return False
    mode = activity["feedback_mode"]
    if mode == "immediate":
        return True
    if mode == "after_close":
        return state["passed"] or state["remaining"] == 0
    return False
