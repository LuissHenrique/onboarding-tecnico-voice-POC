"""Regras de acesso a conteúdos (validadas no servidor em toda requisição)."""
from flask import abort, g

from ..db import one
from ..security import is_staff
from .progress import user_track_state


def load_lesson_ctx(lesson_id):
    row = one(
        "SELECT l.*, m.title AS module_title, m.active AS module_active, m.track_id, t.title AS track_title, "
        "t.status AS track_status FROM lessons l JOIN modules m ON m.id = l.module_id "
        "JOIN tracks t ON t.id = m.track_id WHERE l.id = ?",
        (lesson_id,),
    )
    if row is None:
        abort(404)
    return row


def load_activity_ctx(activity_id):
    row = one(
        "SELECT a.*, m.title AS module_title, m.active AS module_active, m.track_id, t.title AS track_title, "
        "t.status AS track_status FROM activities a JOIN modules m ON m.id = a.module_id "
        "JOIN tracks t ON t.id = m.track_id WHERE a.id = ?",
        (activity_id,),
    )
    if row is None:
        abort(404)
    return row


def is_assigned(user_id, track_id):
    return one("SELECT 1 FROM track_assignments WHERE user_id = ? AND track_id = ?", (user_id, track_id)) is not None


def learner_gate(ctx, module_id):
    """Para colaboradores: trilha publicada e atribuída, conteúdo ativo e módulo liberado.

    Retorna (state, module_state). Gestores/admins acessam em modo de pré-visualização (state=None).
    """
    user = g.user
    if is_staff(user) and not is_assigned(user["id"], ctx["track_id"]):
        return None, None
    if ctx["track_status"] != "published" or not is_assigned(user["id"], ctx["track_id"]):
        abort(404)
    if not ctx["active"] or not ctx["module_active"]:
        abort(410, description="Este conteúdo foi desativado pela gestão do onboarding.")
    if "published" in ctx.keys() and not ctx["published"]:
        abort(404)
    state = user_track_state(user["id"], ctx["track_id"])
    mod = state["by_id"].get(module_id)
    if mod is None:
        abort(404)
    if mod["locked"]:
        names = ", ".join(m["title"] for m in mod["missing_prereqs"])
        abort(423, description=f"Conclua antes: {names}.")
    return state, mod
