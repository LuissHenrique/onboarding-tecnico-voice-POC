"""Cálculo de progresso: fonte única de verdade para trilha, módulos, aulas e atividades.

Regras (ver docs/REGRAS.md):
- Só contam etapas OBRIGATÓRIAS e ATIVAS de módulos ATIVOS.
- Aula concluída: regra 'confirm' => colaborador confirmou a leitura (lesson_progress.completed_at);
  regra 'activity' => alguma atividade vinculada à aula foi aprovada.
- Atividade concluída: existe ao menos uma tentativa corrigida com aprovação (nota >= mínima vigente no envio).
- Acesso a uma aula (visualização) NÃO é conclusão.
- Módulo bloqueado enquanto algum pré-requisito ativo não estiver concluído.
"""
from collections import defaultdict

from flask import current_app, url_for

from ..db import one, q, run
from ..utils import days_since, now_iso


# ---------------------------------------------------------------- estrutura
def track_structure(track_id, include_inactive=False):
    act = "" if include_inactive else " AND active = 1"
    modules = [dict(m) for m in q(f"SELECT * FROM modules WHERE track_id = ?{act} ORDER BY position, id", (track_id,))]
    mids = [m["id"] for m in modules]
    lessons, activities, prereq = defaultdict(list), defaultdict(list), defaultdict(list)
    if mids:
        ph = ",".join("?" * len(mids))
        for l in q(f"SELECT * FROM lessons WHERE module_id IN ({ph}){act} ORDER BY position, id", mids):
            lessons[l["module_id"]].append(dict(l))
        pub = "" if include_inactive else " AND published = 1"
        for a in q(f"SELECT * FROM activities WHERE module_id IN ({ph}){act}{pub} ORDER BY position, id", mids):
            activities[a["module_id"]].append(dict(a))
        for p in q(
            f"SELECT mp.module_id, mp.requires_module_id FROM module_prerequisites mp "
            f"JOIN modules r ON r.id = mp.requires_module_id WHERE mp.module_id IN ({ph}) AND r.active = 1",
            mids,
        ):
            prereq[p["module_id"]].append(p["requires_module_id"])
    for m in modules:
        m["lessons"] = lessons[m["id"]]
        m["activities"] = activities[m["id"]]
        m["prerequisites"] = prereq[m["id"]]
    return modules


# ---------------------------------------------------------------- estado das atividades
STATUS_LABELS = {
    "pending": "Pendente",
    "in_progress": "Em andamento",
    "awaiting_review": "Aguardando correção",
    "passed": "Aprovado",
    "failed_retry": "Reprovado · nova tentativa disponível",
    "failed": "Reprovado",
    "completed": "Concluído",
    "not_started": "Não iniciado",
    "locked": "Bloqueado",
}


def activity_state(activity, attempts):
    """attempts: tentativas do usuário nesta atividade (qualquer versão), ordem crescente."""
    submitted = [a for a in attempts if a["status"] != "in_progress"]
    draft = next((a for a in attempts if a["status"] == "in_progress"), None)
    passed = any(a["status"] == "graded" and a["passed"] for a in attempts)
    pending_review = any(a["status"] == "pending_review" for a in attempts)
    used = len(submitted)
    maxa = activity["max_attempts"]
    remaining = None if maxa == 0 else max(0, maxa - used)
    graded = [a for a in attempts if a["status"] == "graded"]
    best = max((a["percent"] or 0 for a in graded), default=None)
    last = submitted[-1] if submitted else None
    if passed:
        status = "passed"
    elif pending_review:
        status = "awaiting_review"
    elif draft is not None:
        status = "in_progress"
    elif graded:
        status = "failed_retry" if (remaining is None or remaining > 0) else "failed"
    else:
        status = "pending"
    can_start = not passed and not pending_review and (remaining is None or remaining > 0)
    return {
        "status": status,
        "label": STATUS_LABELS[status],
        "passed": passed,
        "attempts_used": used,
        "remaining": remaining,
        "best_percent": best,
        "last": last,
        "draft": draft,
        "can_start": can_start or draft is not None,
        "exhausted": (not passed) and remaining == 0 and not pending_review,
    }


# ---------------------------------------------------------------- estado do usuário na trilha
def user_track_state(user_id, track_id, structure=None):
    modules = structure if structure is not None else track_structure(track_id)
    lesson_ids = [l["id"] for m in modules for l in m["lessons"]]
    activity_ids = [a["id"] for m in modules for a in m["activities"]]
    lp = {}
    if lesson_ids:
        ph = ",".join("?" * len(lesson_ids))
        for r in q(f"SELECT * FROM lesson_progress WHERE user_id = ? AND lesson_id IN ({ph})", [user_id] + lesson_ids):
            lp[r["lesson_id"]] = dict(r)
    atts = defaultdict(list)
    if activity_ids:
        ph = ",".join("?" * len(activity_ids))
        for r in q(
            f"SELECT * FROM attempts WHERE user_id = ? AND activity_id IN ({ph}) ORDER BY number",
            [user_id] + activity_ids,
        ):
            atts[r["activity_id"]].append(dict(r))

    mod_out = []
    by_id = {}
    total_req = total_done = 0
    for m in modules:
        a_states = {}
        for a in m["activities"]:
            a_states[a["id"]] = activity_state(a, atts[a["id"]])
        passed_lessons = {a["lesson_id"] for a in m["activities"] if a["lesson_id"] and a_states[a["id"]]["passed"]}
        lessons = []
        req = done = 0
        touched = False
        for l in m["lessons"]:
            p = lp.get(l["id"])
            if p:
                touched = True
            if l["completion_rule"] == "activity":
                completed = l["id"] in passed_lessons
            else:
                completed = bool(p and p["completed_at"])
            lessons.append({**l, "viewed": bool(p), "completed": completed, "progress": p})
            if l["required"]:
                req += 1
                done += completed
        acts = []
        for a in m["activities"]:
            st = a_states[a["id"]]
            if atts[a["id"]]:
                touched = True
            acts.append({**a, "state": st})
            if a["required"]:
                req += 1
                done += st["passed"]
        pct = round(done / req * 100) if req else (100 if touched else 0)
        completed = (req > 0 and done == req) or (req == 0 and touched)
        status = "completed" if completed else ("in_progress" if touched else "not_started")
        item = {
            **{k: v for k, v in m.items() if k not in ("lessons", "activities")},
            "lessons": lessons,
            "activities": acts,
            "required_total": req,
            "required_done": done,
            "percent": pct,
            "status": status,
            "completed": completed,
            "touched": touched,
            "content_count": len(lessons) + len(acts),
        }
        mod_out.append(item)
        by_id[m["id"]] = item
        total_req += req
        total_done += done

    # bloqueio por pré-requisitos
    for m in mod_out:
        missing = [by_id[p] for p in m["prerequisites"] if p in by_id and not by_id[p]["completed"]]
        m["locked"] = bool(missing)
        m["missing_prereqs"] = missing
        m["prereq_modules"] = [by_id[p] for p in m["prerequisites"] if p in by_id]
        if m["locked"]:
            m["display_status"] = "locked"
        else:
            m["display_status"] = m["status"]

    percent = round(total_done / total_req * 100) if total_req else 0
    return {
        "modules": mod_out,
        "by_id": by_id,
        "required_total": total_req,
        "required_done": total_done,
        "percent": percent,
        "completed": total_req > 0 and total_done == total_req,
        "modules_total": len(mod_out),
        "modules_done": sum(1 for m in mod_out if m["completed"]),
    }


def next_step(state, track_id):
    """Próxima etapa recomendada: primeiro item obrigatório não concluído do primeiro módulo liberado."""
    for m in state["modules"]:
        if m["locked"] or m["completed"]:
            continue
        for l in m["lessons"]:
            if l["required"] and not l["completed"] and l["completion_rule"] == "confirm":
                return {"kind": "lesson", "title": l["title"], "module": m,
                        "url": url_for("learner.lesson", lesson_id=l["id"]),
                        "verb": "Continuar aula" if l["viewed"] else "Começar aula"}
        for a in m["activities"]:
            st = a["state"]
            if a["required"] and not st["passed"] and st["status"] != "awaiting_review" and st["can_start"]:
                return {"kind": "activity", "title": a["title"], "module": m,
                        "url": url_for("learner.activity", activity_id=a["id"]),
                        "verb": "Retomar atividade" if st["status"] == "in_progress" else "Fazer atividade"}
        for l in m["lessons"]:
            if l["required"] and not l["completed"]:
                return {"kind": "lesson", "title": l["title"], "module": m,
                        "url": url_for("learner.lesson", lesson_id=l["id"]), "verb": "Abrir aula"}
    return None


def pending_activities(state):
    out = []
    for m in state["modules"]:
        if m["locked"]:
            continue
        for a in m["activities"]:
            if a["required"] and not a["state"]["passed"]:
                out.append({**a, "module": m})
    return out


# ---------------------------------------------------------------- trilhas atribuídas
def assigned_tracks(user_id, only_published=True):
    pub = " AND t.status = 'published'" if only_published else ""
    return q(
        "SELECT t.*, ta.assigned_at, ta.completed_at AS assignment_completed_at, ta.id AS assignment_id "
        f"FROM track_assignments ta JOIN tracks t ON t.id = ta.track_id WHERE ta.user_id = ?{pub} "
        "ORDER BY ta.assigned_at DESC",
        (user_id,),
    )


def sync_completion(user_id, track_id, state):
    """Registra (ou remove) a data de conclusão da trilha conforme o estado calculado."""
    row = one("SELECT id, completed_at FROM track_assignments WHERE user_id = ? AND track_id = ?", (user_id, track_id))
    if not row:
        return
    if state["completed"] and not row["completed_at"]:
        run("UPDATE track_assignments SET completed_at = ? WHERE id = ?", (now_iso(), row["id"]))
    elif not state["completed"] and row["completed_at"]:
        # novo conteúdo obrigatório publicado depois da conclusão: a trilha volta a ficar em andamento
        run("UPDATE track_assignments SET completed_at = NULL WHERE id = ?", (row["id"],))


# ---------------------------------------------------------------- desempenho
def performance(user_id, track_id=None):
    params = [user_id]
    extra = ""
    if track_id:
        extra = " AND m.track_id = ?"
        params.append(track_id)
    rows = q(
        "SELECT at.*, a.title, a.kind FROM attempts at JOIN activities a ON a.id = at.activity_id "
        "JOIN modules m ON m.id = a.module_id "
        f"WHERE at.user_id = ? AND at.status = 'graded'{extra} ORDER BY at.submitted_at",
        params,
    )
    if not rows:
        return {"graded": 0, "avg_percent": None, "pass_rate": None, "correct": 0, "wrong": 0}
    correct = sum(r["correct_count"] or 0 for r in rows)
    wrong = sum(r["wrong_count"] or 0 for r in rows)
    return {
        "graded": len(rows),
        "avg_percent": sum(r["percent"] or 0 for r in rows) / len(rows),
        "pass_rate": sum(1 for r in rows if r["passed"]) / len(rows) * 100,
        "correct": correct,
        "wrong": wrong,
    }


# ---------------------------------------------------------------- classificação para o gestor
FLAG_LABELS = {
    "completed": "Concluiu",
    "not_started": "Não iniciou",
    "needs_attention": "Precisa de acompanhamento",
    "below_min": "Abaixo da nota mínima",
    "awaiting_review": "Aguardando correção",
    "on_track": "Progredindo normalmente",
}
FLAG_TONES = {
    "completed": "success", "not_started": "neutral", "needs_attention": "danger",
    "below_min": "warning", "awaiting_review": "info", "on_track": "brand",
}


def classify(user, assignment, state):
    cfg = current_app.config
    started = any(m["touched"] for m in state["modules"])
    reasons = []
    flags = set()
    if state["completed"]:
        flags.add("completed")
    elif not started:
        flags.add("not_started")
    exhausted = []
    below = []
    awaiting = 0
    for m in state["modules"]:
        for a in m["activities"]:
            st = a["state"]
            if st["status"] == "awaiting_review":
                awaiting += 1
            if a["required"] and st["status"] in ("failed", "failed_retry"):
                below.append(a)
            if a["required"] and st["exhausted"]:
                exhausted.append(a)
    if below:
        flags.add("below_min")
    if awaiting:
        flags.add("awaiting_review")
    start = user["start_date"] or (assignment["assigned_at"][:10] if assignment else None)
    elapsed = days_since(start)
    expected = None
    if elapsed is not None and assignment is not None:
        exp_days = max(1, assignment["expected_days"] or 30)
        expected = min(100, round(max(0, elapsed) / exp_days * 100))
    if not state["completed"]:
        if exhausted:
            reasons.append(f"{len(exhausted)} atividade(s) sem tentativas restantes e não aprovada(s)")
        if expected is not None and state["percent"] < expected - cfg["PACE_TOLERANCE_POINTS"]:
            reasons.append(f"progresso {state['percent']}% abaixo do esperado ({expected}%) para o dia {elapsed}")
        inactive = days_since(user["last_activity_at"][:10]) if user["last_activity_at"] else None
        if started and inactive is not None and inactive >= cfg["INACTIVITY_ALERT_DAYS"]:
            reasons.append(f"sem atividade há {inactive} dias")
        if not started and elapsed is not None and elapsed >= cfg["INACTIVITY_ALERT_DAYS"]:
            reasons.append(f"não iniciou após {elapsed} dias")
    if reasons:
        flags.add("needs_attention")
    if started and not state["completed"] and not reasons and not below:
        flags.add("on_track")
    for key in ("completed", "needs_attention", "not_started", "below_min", "awaiting_review", "on_track"):
        if key in flags:
            primary = key
            break
    else:
        primary = "on_track"
    return {
        "flags": [f for f in FLAG_LABELS if f in flags],
        "primary": primary,
        "reasons": reasons,
        "expected_percent": expected,
        "elapsed_days": elapsed,
        "awaiting": awaiting,
        "below": below,
        "exhausted": exhausted,
        "start_date": start,
    }


def history_points(user_id, track_id, weeks=8):
    """Itens obrigatórios concluídos por semana (para o histórico de evolução)."""
    from datetime import timedelta
    from ..utils import parse_iso, today_local
    rows = q(
        "SELECT lp.completed_at AS t FROM lesson_progress lp JOIN lessons l ON l.id = lp.lesson_id "
        "JOIN modules m ON m.id = l.module_id WHERE lp.user_id = ? AND m.track_id = ? AND lp.completed_at IS NOT NULL "
        "AND l.required = 1 AND l.active = 1 AND m.active = 1 "
        "UNION ALL "
        "SELECT COALESCE(at.graded_at, at.submitted_at) AS t FROM attempts at JOIN activities a ON a.id = at.activity_id "
        "JOIN modules m ON m.id = a.module_id WHERE at.user_id = ? AND m.track_id = ? AND at.status = 'graded' "
        "AND at.passed = 1 AND a.required = 1 AND a.active = 1 AND m.active = 1 "
        "AND at.number = (SELECT MIN(x.number) FROM attempts x WHERE x.user_id = at.user_id "
        "                 AND x.activity_id = at.activity_id AND x.status = 'graded' AND x.passed = 1)",
        (user_id, track_id, user_id, track_id),
    )
    today = today_local()
    start = today - timedelta(days=today.weekday()) - timedelta(weeks=weeks - 1)
    buckets = [0] * weeks
    for r in rows:
        d = parse_iso(r["t"])
        if not d:
            continue
        idx = (d.date() - start).days // 7
        if 0 <= idx < weeks:
            buckets[idx] += 1
    labels = [(start + timedelta(weeks=i)).strftime("%d/%m") for i in range(weeks)]
    return list(zip(labels, buckets))
