"""Consultas de acompanhamento e relatórios (sempre restritas aos colaboradores visíveis)."""
import csv
import io

from ..db import one, q
from ..security import visible_collaborators_sql
from .progress import assigned_tracks, classify, performance, track_structure, user_track_state


def team_overview(viewer, track_id=None, include_inactive=False):
    where, params = visible_collaborators_sql(viewer)
    if not include_inactive:
        where += " AND u.active = 1"
    users = q(f"SELECT u.*, m.name AS manager_name FROM users u LEFT JOIN users m ON m.id = u.manager_id "
              f"WHERE {where} ORDER BY u.name", params)
    structures = {}
    rows = []
    for u in users:
        tracks = assigned_tracks(u["id"])
        if track_id:
            tracks = [t for t in tracks if t["id"] == track_id]
        if not tracks:
            rows.append({"user": u, "track": None, "state": None, "cls": {"primary": "unassigned", "flags": [],
                         "reasons": [], "expected_percent": None, "awaiting": 0, "start_date": u["start_date"]},
                         "perf": performance(u["id"])})
            continue
        for t in tracks:
            if t["id"] not in structures:
                structures[t["id"]] = track_structure(t["id"])
            st = user_track_state(u["id"], t["id"], structures[t["id"]])
            rows.append({"user": u, "track": t, "state": st, "cls": classify(u, t, st),
                         "perf": performance(u["id"], t["id"])})
    return rows


def module_error_stats(viewer, track_id):
    """Por módulo: tentativas corrigidas, % de reprovação, média e respostas erradas."""
    where, params = visible_collaborators_sql(viewer)
    return q(
        "SELECT m.id, m.title, m.position, COUNT(at.id) AS attempts, "
        "SUM(CASE WHEN at.passed = 0 THEN 1 ELSE 0 END) AS failed, AVG(at.percent) AS avg_percent, "
        "SUM(COALESCE(at.wrong_count,0)) AS wrong, SUM(COALESCE(at.correct_count,0)) AS correct "
        "FROM modules m JOIN activities a ON a.module_id = m.id "
        "JOIN attempts at ON at.activity_id = a.id AND at.status = 'graded' "
        f"JOIN users u ON u.id = at.user_id WHERE m.track_id = ? AND {where} "
        "GROUP BY m.id ORDER BY (CAST(SUM(COALESCE(at.wrong_count,0)) AS REAL) / "
        "NULLIF(SUM(COALESCE(at.wrong_count,0)) + SUM(COALESCE(at.correct_count,0)),0)) DESC, m.position",
        [track_id] + list(params),
    )


def question_error_stats(viewer, track_id, limit=10):
    where, params = visible_collaborators_sql(viewer)
    return q(
        "SELECT aa.question_id, json_extract(aa.question_snapshot,'$.prompt') AS prompt, a.title AS activity, "
        "a.id AS activity_id, m.title AS module, COUNT(*) AS answers, "
        "SUM(CASE WHEN aa.is_correct = 0 THEN 1 ELSE 0 END) AS wrong "
        "FROM attempt_answers aa JOIN attempts at ON at.id = aa.attempt_id AND at.status = 'graded' "
        "JOIN activities a ON a.id = at.activity_id JOIN modules m ON m.id = a.module_id "
        f"JOIN users u ON u.id = at.user_id WHERE m.track_id = ? AND aa.is_correct IS NOT NULL AND {where} "
        "GROUP BY aa.question_id HAVING wrong > 0 "
        "ORDER BY CAST(wrong AS REAL)/COUNT(*) DESC, wrong DESC LIMIT ?",
        [track_id] + list(params) + [limit],
    )


def pending_reviews(viewer):
    where, params = visible_collaborators_sql(viewer)
    return q(
        "SELECT at.*, a.title AS activity_title, a.kind, m.title AS module_title, u.name AS user_name, u.is_demo "
        "FROM attempts at JOIN activities a ON a.id = at.activity_id JOIN modules m ON m.id = a.module_id "
        f"JOIN users u ON u.id = at.user_id WHERE at.status = 'pending_review' AND {where} "
        "ORDER BY at.submitted_at",
        params,
    )


def pending_reviews_count(viewer):
    where, params = visible_collaborators_sql(viewer)
    return one(
        "SELECT COUNT(*) FROM attempts at JOIN users u ON u.id = at.user_id "
        f"WHERE at.status = 'pending_review' AND {where}", params)[0]


def attempts_for_export(viewer, track_id=None):
    where, params = visible_collaborators_sql(viewer)
    extra = ""
    p = list(params)
    if track_id:
        extra = " AND m.track_id = ?"
        p.append(track_id)
    return q(
        "SELECT u.name, u.email, t.title AS track, m.title AS module, a.title AS activity, a.kind, at.number, "
        "at.status, at.submitted_at, at.graded_at, at.score, at.max_score, at.percent, at.pass_percent, at.passed, "
        "at.correct_count, at.wrong_count, at.activity_version, u.is_demo "
        "FROM attempts at JOIN users u ON u.id = at.user_id JOIN activities a ON a.id = at.activity_id "
        "JOIN modules m ON m.id = a.module_id JOIN tracks t ON t.id = m.track_id "
        f"WHERE at.status <> 'in_progress' AND {where}{extra} ORDER BY u.name, m.position, a.position, at.number",
        p,
    )


def to_csv(header, rows):
    buf = io.StringIO()
    buf.write("﻿")  # BOM para o Excel reconhecer UTF-8
    w = csv.writer(buf, delimiter=";", quoting=csv.QUOTE_MINIMAL)
    w.writerow(header)
    for r in rows:
        w.writerow(["" if v is None else _safe_cell(v) for v in r])
    return buf.getvalue()


def _safe_cell(v):
    # evita injeção de fórmulas ao abrir no Excel
    s = str(v)
    if s and s[0] in "=+-@\t\r":
        return "'" + s
    return s
