"""Plataforma de Onboarding Técnico — fábrica da aplicação Flask."""
import os
import secrets
from pathlib import Path

from flask import Flask, g, render_template, request
from werkzeug.exceptions import HTTPException

from . import db as dbmod
from .config import Config
from .markdown import render as md
from .security import (apply_security_headers, check_csrf, csrf_token, is_staff, load_current_user,
                       touch_activity)
from .utils import (KIND_LABELS, QTYPE_LABELS, ROLE_LABELS, TRACK_STATUS_LABELS, fmt_date, fmt_datetime,
                    fmt_minutes, fmt_number, fmt_percent, fmt_relative)


def create_app(overrides=None):
    app = Flask(__name__, instance_relative_config=False)
    app.config.from_object(Config)
    if overrides:
        app.config.update(overrides)

    if not app.config["SECRET_KEY"]:
        if app.config["ENV"] == "production":
            raise RuntimeError("Defina SECRET_KEY no ambiente antes de iniciar em produção.")
        app.config["SECRET_KEY"] = _dev_secret(app)

    Path(app.config["UPLOAD_DIR"]).mkdir(parents=True, exist_ok=True)
    if app.config["DATABASE_PATH"] != ":memory:":
        Path(app.config["DATABASE_PATH"]).parent.mkdir(parents=True, exist_ok=True)
        conn = dbmod.connect(app.config["DATABASE_PATH"])
        try:
            dbmod.migrate(conn)
        finally:
            conn.close()

    app.teardown_appcontext(dbmod.close_db)

    @app.before_request
    def _before():
        load_current_user()
        check_csrf()
        if g.user is not None and request.endpoint != "static" and request.method == "POST":
            touch_activity(g.user["id"])

    app.after_request(apply_security_headers)

    from .blueprints import account, admin, admin_content, auth, files, learner
    for bp in (auth.bp, learner.bp, account.bp, files.bp, admin.bp, admin_content.bp):
        app.register_blueprint(bp)

    app.jinja_env.filters.update(
        dt=fmt_datetime, date=fmt_date, rel=fmt_relative, pct=fmt_percent, num=fmt_number,
        minutes=fmt_minutes, md=md,
    )
    app.jinja_env.globals.update(
        csrf_token=csrf_token, ROLE_LABELS=ROLE_LABELS, KIND_LABELS=KIND_LABELS, QTYPE_LABELS=QTYPE_LABELS,
        TRACK_STATUS_LABELS=TRACK_STATUS_LABELS, is_staff=is_staff,
    )

    @app.context_processor
    def _ctx():
        pending = 0
        if g.get("user") is not None and is_staff(g.user):
            from .services.reports import pending_reviews_count
            pending = pending_reviews_count(g.user)
        logo = app.config["LOGO_FILE"]
        has_logo = bool(logo) and (Path(app.static_folder) / logo).is_file()
        return {"current_user": g.get("user"), "pending_reviews": pending, "app_name": app.config["APP_NAME"],
                "app_subtitle": app.config["APP_SUBTITLE"], "logo_file": logo if has_logo else None}

    @app.errorhandler(HTTPException)
    def _http_error(e):
        titles = {400: "Não foi possível processar o pedido", 401: "Entre para continuar",
                  403: "Acesso não permitido", 404: "Página não encontrada", 410: "Conteúdo desativado",
                  413: "Arquivo grande demais", 423: "Conteúdo bloqueado", 429: "Muitas tentativas"}
        texts = {403: "Seu perfil não tem permissão para acessar esta área.",
                 404: "O endereço pode ter mudado ou o conteúdo não está disponível para você.",
                 413: f"O limite por arquivo é de {app.config['MAX_CONTENT_LENGTH'] // (1024 * 1024)} MB."}
        desc = e.description if e.description and not e.description.startswith(("The ", "You ")) else texts.get(e.code, "")
        return render_template("error.html", code=e.code, title=titles.get(e.code, "Algo deu errado"),
                               text=desc), e.code

    from . import cli
    cli.register(app)
    return app


def _dev_secret(app):
    """Em desenvolvimento, gera e reaproveita uma chave local (nunca usada em produção)."""
    p = Path(app.config["DATABASE_PATH"]).parent / ".dev_secret_key"
    if app.config["DATABASE_PATH"] == ":memory:":
        return secrets.token_hex(32)
    p.parent.mkdir(parents=True, exist_ok=True)
    if p.exists():
        return p.read_text().strip()
    key = secrets.token_hex(32)
    p.write_text(key)
    os.chmod(p, 0o600)
    return key
