"""Carga do conteúdo do onboarding WideVoice e dos dados de DEMONSTRAÇÃO."""
import json
import random
from datetime import datetime, timedelta, timezone
from pathlib import Path

from werkzeug.datastructures import MultiDict

from .db import Tx, one, q, run
from .security import hash_password
from .services import grading
from .services.progress import activity_state, sync_completion, user_track_state
from .utils import now_iso

SEED_DIR = Path(__file__).resolve().parent.parent / "seed"
TRACK_TITLE = "Onboarding Suporte N2 · WideVoice"
DEMO_PASSWORD = "Demo2026onboarding"


def _extra_activities():
    """Atividades adicionais montadas a partir do conteúdo do onboarding (roteiros e práticas)."""
    return {
        "atendimento": [
            {
                "title": "Estudo de caso: áudio mudo em chamadas",
                "kind": "case", "pass_percent": 70, "max_attempts": 2, "feedback_mode": "immediate",
                "description": "Aplique o roteiro de troubleshooting a um chamado de áudio.",
                "instructions": (
                    "## Cenário\n\nUm cliente abre um chamado informando que, em algumas ligações, **o áudio fica mudo**. "
                    "Ele não sabe dizer se acontece com todos os ramais.\n\n"
                    "Use o roteiro geral de troubleshooting e o roteiro de áudio mudo ou picotando da aula "
                    "anterior para responder. A correção é feita pela gestão."),
                "questions": [
                    {"qtype": "open", "points": 5,
                     "prompt": "Quais perguntas você faz ao cliente para entender o problema, o ambiente e o impacto?",
                     "explanation": "Referência: o que acontece, desde quando e o que mudou; qual dispositivo, um ou vários, "
                                    "contínuo ou intermitente, WiFi ou cabo, mudanças de rede; quantos usuários e urgência; "
                                    "mensagens de erro, sintomas e prints."},
                    {"qtype": "open", "points": 5,
                     "prompt": "Quais verificações técnicas você faz, e em que ordem, para isolar a causa do áudio mudo?",
                     "explanation": "Referência: entrada, saída ou ambos; teste ramal-ramal e ramal-externo; mudo desde o "
                                    "início ou após segundos; QoS, firewall, NAT e SIP ALG; volume e dispositivos do "
                                    "softphone; atualizações; captura com sngrep/PCAP e análise no WireShark."},
                ],
            },
            {
                "title": "Simulação de atendimento: chamadas externas não completam",
                "kind": "simulation", "pass_percent": 70, "max_attempts": 2, "feedback_mode": "immediate",
                "description": "Conduza um atendimento simulado do primeiro contato até a coleta de logs.",
                "instructions": (
                    "## Situação simulada\n\n> [!EXEMPLO]\n> **Cliente:** “Os ramais daqui não conseguem ligar para fora. "
                    "Ligação interna funciona normalmente.”\n\nResponda como se estivesse no atendimento. "
                    "Considere a postura de encantividade (surpreender, empatia, conexão) e o roteiro de "
                    "chamadas externas que não completam."),
                "questions": [
                    {"qtype": "open", "points": 3,
                     "prompt": "Escreva sua primeira resposta ao cliente, já com as perguntas iniciais.",
                     "explanation": "Referência: acolher com empatia e perguntar se falha para todos os números ou alguns, "
                                    "em qual horário e frequência, em quais ramais e para quais tipos de número."},
                    {"qtype": "single", "points": 2,
                     "prompt": "No PABX do cliente, qual status do tronco indica que o registro com a operadora está ok?",
                     "explanation": "Registered indica registro aceito; Rejected indica falha.",
                     "options": [{"text": "Registered", "is_correct": True}, {"text": "Rejected", "is_correct": False},
                                 {"text": "Not in Use", "is_correct": False}]},
                    {"qtype": "open", "points": 5,
                     "prompt": "Quais verificações e quais logs você coleta para concluir o diagnóstico? Cite os comandos.",
                     "explanation": "Referência: permissão do ramal e rota usada, restrição na operadora, teste por outras "
                                    "rotas, tronco registrado; logs com `sudo debug | grep <numero>`, `sngrep` e, se "
                                    "intermitente, `tcpdump` com rotação."},
                ],
            },
        ],
        "query": [
            {
                "title": "Exercício: escrever uma Rota Query",
                "kind": "open", "pass_percent": 70, "max_attempts": 3, "feedback_mode": "immediate",
                "description": "Escreva e explique um script de troca de tronco por ramal.",
                "instructions": "Use as variáveis e os scripts prontos da aula. A gestão corrige a resposta.",
                "questions": [
                    {"qtype": "open", "points": 10,
                     "prompt": "Escreva o script que faz os ramais 2905 e 2906 saírem pelo tronco 6130229090 e explique "
                               "como validar no SSH que a query foi executada.",
                     "explanation": "Referência: pegar o ramal pelo CHANNEL (GET VARIABLE + explode), "
                                    "if($canal>'2904' and $canal<'2907') com SET VARIABLE TECNOLOGIA_TRONCO \"6130229090\"; "
                                    "validar com write_console(\"TAG ...\") e sudo debug | grep TAG."},
                ],
            },
        ],
        "ssh": [
            {
                "title": "Prática: capturar e analisar uma chamada",
                "kind": "practical", "pass_percent": 70, "max_attempts": 3, "feedback_mode": "immediate",
                "description": "Capture as pernas de uma chamada com o sngrep e analise no WireShark.",
                "instructions": (
                    "1. Acesse o servidor por SSH (porta `2222`, usuário `suporte`).\n"
                    "2. Faça uma chamada de teste e acompanhe no `sudo sngrep`.\n"
                    "3. Selecione as pernas com **SPACE**, salve com **F2** em `/opt/lampp/htdocs`.\n"
                    "4. Baixe o PCAP e abra no WireShark em **Telephony › VoIP Calls**.\n\n"
                    "Envie como evidência um print do fluxo da chamada e descreva o que observou (métodos SIP, "
                    "respostas e se houve RTP nos dois sentidos)."),
                "questions": [],
            },
        ],
        "avaliacoes": [
            {
                "title": "Prática 1: criar PABX e licenças",
                "kind": "practical", "pass_percent": 70, "max_attempts": 3, "feedback_mode": "immediate",
                "description": "Atividades práticas 1 a 3 no widevoice17.",
                "instructions": (
                    "Execute no **widevoice17.intelbrasvoice.com.br**:\n\n"
                    "1. Criar um PABX com 5 ramais ENTERPRISE.\n2. Criar um PABX com 10 ramais ENTERPRISE.\n"
                    "3. Criar um PABX com 3 STARTER, 5 ENTERPRISE e 4 PREMIUM.\n\n"
                    "Envie como evidência os nomes dos PABX criados e prints das licenças liberadas. "
                    "Não envie senhas por aqui: as credenciais vão para o N2 pelo canal combinado."),
                "questions": [],
            },
            {
                "title": "Prática 2: comunicação entre PABX e telefonista",
                "kind": "practical", "pass_percent": 70, "max_attempts": 3, "feedback_mode": "immediate",
                "description": "Atividades práticas 4 e 5 no widevoice17.",
                "instructions": (
                    "1. Liberar a comunicação entre os PABX criados.\n"
                    "2. Criar uma telefonista em cada PABX e ligar para um ramal no MicroSIP.\n\n"
                    "Envie prints da liberação de tráfego, do pool de telefonistas e da chamada realizada."),
                "questions": [],
            },
            {
                "title": "Prática 3: atendimento completo no TESTE-INTELBRAS",
                "kind": "practical", "pass_percent": 70, "max_attempts": 3, "feedback_mode": "immediate",
                "description": "Atividade prática 6: grupos, URA, música TTS e siga-me.",
                "instructions": (
                    "No PABX **TESTE-INTELBRAS**:\n\n"
                    "- Grupo Comercial com 0301 e 0302, sequencial, 3 toques\n- Grupo Suporte com os agentes 5505 e 5504\n"
                    "- Música TTS (ttsmaker.com)\n- URA: 1 Comercial, 2 Suporte; timeout e opção inválida para 0303\n"
                    "- Siga-me se não atende do 0303 para o 0302 após 3 toques\n- Testar ligando do celular\n\n"
                    "Envie prints das configurações e descreva o resultado do teste pelo celular."),
                "questions": [],
            },
        ],
    }


TF_FINAL = [
    ("Os desvios configurados em Facilities só valem quando o status do usuário está Online.", True,
     "Os desvios (siga-me) só funcionam com status Online."),
    ("O bloqueio entre setores também vale para chamadas feitas para grupos.", False,
     "O bloqueio entre setores só vale para ligação direta ao ramal, não para grupos."),
    ("O mini DAC atende até 12 agentes logados sem a licença GRUPO DAC.", True,
     "Acima de 12 agentes logados é preciso liberar a licença GRUPO DAC no Classe 5."),
    ("O DDR precisa estar liberado em Classe 5 › DDRs Permitidos antes de configurar o Redirecionar.", True,
     "Sem a liberação em DDRs Permitidos o redirecionamento não funciona."),
]


def _ts(days_ago=0, hours=0):
    return (datetime.now(timezone.utc) - timedelta(days=days_ago, hours=hours)).replace(microsecond=0).isoformat()


def _insert_activity(module_id, pos, a, lesson_id=None):
    ts = now_iso()
    aid = run(
        "INSERT INTO activities(module_id, lesson_id, title, description, instructions, kind, pass_percent, max_attempts,"
        "feedback_mode, required, position, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (module_id, lesson_id, a["title"], a.get("description", ""), a.get("instructions", ""), a["kind"],
         a["pass_percent"], a["max_attempts"], a["feedback_mode"], 1 if a.get("required", True) else 0, pos, ts, ts))
    for qi, qd in enumerate(a.get("questions", [])):
        qid = run("INSERT INTO questions(activity_id, qtype, prompt, explanation, points, position, created_at, updated_at) "
                  "VALUES (?,?,?,?,?,?,?,?)", (aid, qd["qtype"], qd["prompt"], qd.get("explanation", ""),
                                               qd.get("points", 1), qi, ts, ts))
        for oi, o in enumerate(qd.get("options", [])):
            run("INSERT INTO question_options(question_id, text, is_correct, position) VALUES (?,?,?,?)",
                (qid, o["text"], 1 if o["is_correct"] else 0, oi))
    return aid


def load_track(publish=True):
    data = json.loads((SEED_DIR / "widevoice_base.json").read_text(encoding="utf-8"))
    extras = _extra_activities()
    ts = now_iso()
    with Tx():
        existing = one("SELECT id FROM tracks WHERE title = ?", (TRACK_TITLE,))
        if existing:
            return existing["id"]
        admin = one("SELECT id FROM users WHERE role = 'admin' ORDER BY id LIMIT 1")
        tid = run("INSERT INTO tracks(title, description, status, expected_days, created_by, published_at, created_at, "
                  "updated_at) VALUES (?,?,?,?,?,?,?,?)",
                  (TRACK_TITLE,
                   "Trilha de capacitação para o suporte nível 2 do WideVoice, o PABX em nuvem da Intelbras: "
                   "conceitos, criação de PABX, troncos e rotas, call center, Rota Query, equipamentos, diagnóstico "
                   "e ferramentas SSH, com avaliações teóricas e práticas.",
                   "published" if publish else "draft", 30, admin["id"] if admin else None,
                   ts if publish else None, ts, ts))
        key_to_id = {}
        final_qs = []
        for mi, m in enumerate(data["modules"]):
            mid = run("INSERT INTO modules(track_id, title, description, objectives, position, created_at, updated_at) "
                      "VALUES (?,?,?,?,?,?,?)", (tid, m["title"], m["description"], "\n".join(m["objectives"]), mi, ts, ts))
            key_to_id[m["key"]] = mid
            for li, l in enumerate(m["lessons"]):
                run("INSERT INTO lessons(module_id, title, summary, body, position, required, completion_rule, "
                    "created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)",
                    (mid, l["title"], l.get("summary", ""), l["body"], li, 1, "confirm", ts, ts))
            pos = 0
            for a in m["activities"] + extras.get(m["key"], []):
                _insert_activity(mid, pos, a)
                pos += 1
                if a["kind"] == "quiz" and a["questions"]:
                    final_qs.append(a["questions"][0])
            if m["key"] == "avaliacoes":
                qs = [dict(x) for x in final_qs] + [
                    {"qtype": "truefalse", "points": 1, "prompt": p, "explanation": e,
                     "options": [{"text": "Verdadeiro", "is_correct": v}, {"text": "Falso", "is_correct": not v}]}
                    for p, v, e in TF_FINAL]
                _insert_activity(mid, pos, {
                    "title": "Avaliação final da trilha", "kind": "final", "pass_percent": 70, "max_attempts": 2,
                    "feedback_mode": "after_close",
                    "description": "Avaliação objetiva com questões de todos os módulos.",
                    "instructions": "Avaliação final com correção automática. Você tem **2 tentativas** e precisa de "
                                    "**70%** para aprovação. O gabarito aparece depois da aprovação ou do fim das tentativas.",
                    "questions": qs})
        for m in data["modules"]:
            for req in m.get("prerequisites", []):
                run("INSERT INTO module_prerequisites(module_id, requires_module_id) VALUES (?,?)",
                    (key_to_id[m["key"]], key_to_id[req]))
    return tid


# ------------------------------------------------------------------ demonstração
def _ensure_user(name, email, role, manager_id=None, start_days_ago=0, job=None):
    row = one("SELECT id FROM users WHERE email = ?", (email,))
    if row:
        return row["id"]
    ts = now_iso()
    start = (datetime.now(timezone.utc) - timedelta(days=start_days_ago)).date().isoformat()
    return run("INSERT INTO users(name, email, password_hash, role, active, manager_id, job_title, start_date, is_demo, "
               "created_at, updated_at) VALUES (?,?,?,?,1,?,?,?,1,?,?)",
               (name, email, hash_password(DEMO_PASSWORD), role, manager_id, job, start, ts, ts))


def _complete_lessons(uid, lessons, start_days, spread):
    for i, l in enumerate(lessons):
        d = max(0, start_days - int(i * spread))
        t = _ts(d, hours=random.randint(1, 8))
        run("INSERT OR IGNORE INTO lesson_progress(user_id, lesson_id, first_viewed_at, last_viewed_at, view_count, "
            "completed_at) VALUES (?,?,?,?,?,?)", (uid, l["id"], t, t, random.randint(1, 3), t))
        run("INSERT INTO events(user_id, kind, ref_type, ref_id, created_at) VALUES (?,?,?,?,?)",
            (uid, "lesson_completed", "lesson", l["id"], t))


def _answer(uid, activity, correct_ratio, days_ago, open_text=None):
    st = activity_state(activity, [dict(r) for r in q("SELECT * FROM attempts WHERE activity_id = ? AND user_id = ? "
                                                         "ORDER BY number", (activity["id"], uid))])
    aid = grading.start_attempt(activity, uid, st)
    at = one("SELECT * FROM attempts WHERE id = ?", (aid,))
    form = MultiDict()
    answers = q("SELECT * FROM attempt_answers WHERE attempt_id = ?", (aid,))
    n = len(answers)
    right_n = round(n * correct_ratio)
    for i, ans in enumerate(answers):
        snap = json.loads(ans["question_snapshot"])
        if snap["qtype"] == "open":
            form.add(f"q_{ans['id']}", open_text or "Resposta de demonstração.")
            continue
        opts = snap["options"]
        good = [o["id"] for o in opts if o["is_correct"]]
        bad = [o["id"] for o in opts if not o["is_correct"]]
        pick = good if (i < right_n or not bad) else [bad[0]]
        for p in pick:
            form.add(f"q_{ans['id']}", str(p))
    grading.save_answers(at, form)
    evidence = {"text": open_text or "Evidência de demonstração.", "url": None, "file": None, "original": None} \
        if activity["kind"] == "practical" else None
    grading.submit_attempt(dict(at), activity, evidence)
    t = _ts(days_ago, hours=random.randint(1, 6))
    run("UPDATE attempts SET started_at = ?, submitted_at = ?, graded_at = CASE WHEN graded_at IS NOT NULL THEN ? END "
        "WHERE id = ?", (t, t, t, aid))
    run("UPDATE events SET created_at = ? WHERE user_id = ? AND ref_id = ? AND created_at > ?",
        (t, uid, activity["id"], _ts(0, 1)))
    return aid


def load_demo():
    random.seed(42)
    tid = load_track(publish=True)
    with Tx():
        mgr = _ensure_user("Gestora Demonstração", "gestora.demo@exemplo.com", "manager", None, 60, "Coordenação Suporte N2")
        people = [
            ("Ana Demonstração", "ana.demo@exemplo.com", 40, "high"),
            ("Bruno Demonstração", "bruno.demo@exemplo.com", 22, "mid_fail"),
            ("Carla Demonstração", "carla.demo@exemplo.com", 14, "review"),
            ("Diego Demonstração", "diego.demo@exemplo.com", 10, "none"),
            ("Elisa Demonstração", "elisa.demo@exemplo.com", 3, "start"),
        ]
        ids = []
        for name, email, days, profile in people:
            uid = _ensure_user(name, email, "collaborator", mgr, days, "Analista de suporte")
            run("INSERT OR IGNORE INTO track_assignments(track_id, user_id, assigned_by, assigned_at) VALUES (?,?,?,?)",
                (tid, uid, mgr, _ts(days)))
            ids.append((uid, days, profile))
    from .services.progress import track_structure
    mods = track_structure(tid)
    by_title = {m["title"]: m for m in mods}

    def quiz_of(m):
        return next((a for a in m["activities"] if a["kind"] == "quiz"), None)

    for uid, days, profile in ids:
        if one("SELECT 1 FROM lesson_progress WHERE user_id = ?", (uid,)):
            continue
        with Tx():
            if profile == "none":
                pass
            elif profile == "start":
                m = mods[0]
                _complete_lessons(uid, m["lessons"][:3], days, 0.5)
                run("UPDATE users SET last_activity_at = ? WHERE id = ?", (_ts(0, 3), uid))
            elif profile == "high":
                for idx, m in enumerate(mods[:8]):
                    d0 = max(1, days - idx * 4)
                    _complete_lessons(uid, m["lessons"], d0, 0.3)
                    qz = quiz_of(m)
                    if qz:
                        if idx % 3 == 0:  # primeira tentativa abaixo do mínimo, aprovada na segunda
                            _answer(uid, qz, 0.34, max(0, d0 - 1))
                        _answer(uid, qz, 1.0, max(0, d0 - 1))
                for a in by_title["SIP, atendimento e diagnóstico"]["activities"]:
                    if a["kind"] == "case":
                        _answer(uid, a, 1, 6, "Pergunto o que acontece, desde quando e o que mudou; se afeta um ou vários "
                                             "ramais, WiFi ou cabo. Depois testo ramal-ramal e externo, verifico NAT/SIP ALG e capturo com sngrep.")
                run("UPDATE users SET last_activity_at = ? WHERE id = ?", (_ts(1), uid))
            elif profile == "mid_fail":
                for idx, m in enumerate(mods[:4]):
                    d0 = max(1, days - idx * 5)
                    _complete_lessons(uid, m["lessons"], d0, 0.5)
                    qz = quiz_of(m)
                    if qz:
                        if idx == 2:
                            _answer(uid, qz, 0.34, max(0, d0 - 1))
                            _answer(uid, qz, 0.34, max(0, d0 - 2))
                        else:
                            _answer(uid, qz, 1.0, max(0, d0 - 1))
                run("UPDATE users SET last_activity_at = ? WHERE id = ?", (_ts(8), uid))
            elif profile == "review":
                for idx, m in enumerate(mods[:2]):
                    _complete_lessons(uid, m["lessons"], days - idx * 4, 0.6)
                    qz = quiz_of(m)
                    if qz:
                        _answer(uid, qz, 1.0, max(0, days - idx * 4 - 1))
                q_mod = by_title["Rota Query"]
                _complete_lessons(uid, by_title["Troncos e rotas"]["lessons"][:2], 4, 1)
                run("UPDATE users SET last_activity_at = ? WHERE id = ?", (_ts(0, 5), uid))
                sip = by_title["SIP, atendimento e diagnóstico"]
                _complete_lessons(uid, sip["lessons"], 3, 0.3)
                for a in sip["activities"]:
                    if a["kind"] == "case":
                        _answer(uid, a, 1, 1, "Perguntaria desde quando ocorre e se é em todos os ramais. Verificaria "
                                             "firewall e SIP ALG e faria teste ramal a ramal.")
            st = user_track_state(uid, tid)
            sync_completion(uid, tid, st)
    emails = ["gestora.demo@exemplo.com"] + [p[1] for p in people]
    return {"password": DEMO_PASSWORD, "emails": emails}
