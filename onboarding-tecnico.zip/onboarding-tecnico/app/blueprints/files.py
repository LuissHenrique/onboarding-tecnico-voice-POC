"""Entrega de arquivos com verificação de permissão (materiais e evidências)."""
from pathlib import Path

from flask import Blueprint, abort, current_app, g, send_from_directory

from ..db import one
from ..security import can_view_user, login_required
from ..services.access import learner_gate, load_lesson_ctx

bp = Blueprint("files", __name__)


def _send(stored, download_name):
    folder = Path(current_app.config["UPLOAD_DIR"])
    if not stored or "/" in stored or "\\" in stored or not (folder / stored).is_file():
        abort(404)
    return send_from_directory(folder, stored, download_name=download_name, as_attachment=False, max_age=0)


@bp.route("/materiais/<int:material_id>")
@login_required
def material(material_id):
    mat = one("SELECT * FROM materials WHERE id = ?", (material_id,))
    if mat is None or mat["kind"] != "file":
        abort(404)
    ctx = load_lesson_ctx(mat["lesson_id"])
    learner_gate(ctx, ctx["module_id"])  # mesmas regras da aula: atribuída, ativa e liberada
    return _send(mat["stored_name"], mat["original_name"])


@bp.route("/evidencias/<int:attempt_id>")
@login_required
def evidence(attempt_id):
    at = one("SELECT * FROM attempts WHERE id = ?", (attempt_id,))
    if at is None or not at["evidence_file"]:
        abort(404)
    owner = one("SELECT * FROM users WHERE id = ?", (at["user_id"],))
    if not can_view_user(g.user, owner):
        abort(403)
    return _send(at["evidence_file"], at["evidence_original"] or at["evidence_file"])
