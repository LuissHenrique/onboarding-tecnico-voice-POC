"""Gestão de conteúdo: trilhas, módulos, aulas, materiais, atividades e questões."""
from urllib.parse import urlparse

from flask import Blueprint, abort, flash, g, redirect, render_template, request, url_for

from ..db import Tx, one, q, run
from ..markdown import render as md_render
from ..security import audit, staff_required
from ..services import grading
from ..services.progress import track_structure
from ..utils import now_iso, to_int
from .learner import save_upload

bp = Blueprint("content", __name__, url_prefix="/admin/conteudo")

PARENT = {"modules": "track_id", "lessons": "module_id", "activities": "module_id", "questions": "activity_id",
          "materials": "lesson_id"}


def _back(default):
    t = request.form.get("back") or request.args.get("back")
    if t and t.startswith("/") and not t.startswith("//") and not urlparse(t).netloc:
        return t
    return default


def _move(table, item_id, direction):
    parent = PARENT[table]
    row = one(f"SELECT id, {parent} AS p FROM {table} WHERE id = ?", (item_id,))
    if row is None:
        abort(404)
    ids = [r["id"] for r in q(f"SELECT id FROM {table} WHERE {parent} = ? ORDER BY position, id", (row["p"],))]
    i = ids.index(item_id)
    j = i - 1 if direction == "up" else i + 1
    if 0 <= j < len(ids):
        ids[i], ids[j] = ids[j], ids[i]
    with Tx():
        for pos, rid in enumerate(ids):
            run(f"UPDATE {table} SET position = ? WHERE id = ?", (pos, rid))
    return row["p"]


def _next_pos(table, parent_id):
    return (one(f"SELECT COALESCE(MAX(position), -1) + 1 FROM {table} WHERE {PARENT[table]} = ?", (parent_id,))[0])


def _int_or_none(v, lo=0, hi=100000):
    v = (v or "").strip()
    if not v:
        return None
    return to_int(v, "invalid", lo, hi)


# ------------------------------------------------------------------ trilhas
@bp.route("/")
@staff_required
def tracks():
    rows = q("SELECT t.*, (SELECT COUNT(*) FROM modules m WHERE m.track_id = t.id AND m.active = 1) AS n_modules, "
             "(SELECT COUNT(*) FROM track_assignments ta WHERE ta.track_id = t.id) AS n_assigned "
             "FROM tracks t ORDER BY t.status = 'archived', t.title")
    return render_template("content/tracks.html", rows=rows)


def _track_form():
    f = request.form
    data = {"title": (f.get("title") or "").strip()[:160], "description": (f.get("description") or "").strip()[:4000],
            "expected_days": to_int(f.get("expected_days"), None, 1, 365)}
    errors = {}
    if len(data["title"]) < 3:
        errors["title"] = "Informe um título com pelo menos 3 caracteres."
    if data["expected_days"] is None:
        errors["expected_days"] = "Informe um prazo entre 1 e 365 dias."
    return data, errors


@bp.route("/trilhas/nova", methods=["GET", "POST"])
@staff_required
def track_new():
    data, errors = {"expected_days": 30}, {}
    if request.method == "POST":
        data, errors = _track_form()
        if not errors:
            ts = now_iso()
            with Tx():
                tid = run("INSERT INTO tracks(title, description, expected_days, created_by, created_at, updated_at) "
                          "VALUES (?,?,?,?,?,?)", (data["title"], data["description"], data["expected_days"],
                                                   g.user["id"], ts, ts))
                audit("create", "track", tid, data["title"])
            flash("Trilha criada como rascunho. Adicione módulos e publique quando estiver pronta.", "success")
            return redirect(url_for("content.track", track_id=tid))
    return render_template("content/track_form.html", t=None, data=data, errors=errors)


@bp.route("/trilhas/<int:track_id>/editar", methods=["GET", "POST"])
@staff_required
def track_edit(track_id):
    t = one("SELECT * FROM tracks WHERE id = ?", (track_id,)) or abort(404)
    data, errors = dict(t), {}
    if request.method == "POST":
        data, errors = _track_form()
        if not errors:
            with Tx():
                run("UPDATE tracks SET title=?, description=?, expected_days=?, updated_at=? WHERE id=?",
                    (data["title"], data["description"], data["expected_days"], now_iso(), track_id))
                audit("update", "track", track_id, data["title"])
            flash("Trilha atualizada.", "success")
            return redirect(url_for("content.track", track_id=track_id))
    return render_template("content/track_form.html", t=t, data=data, errors=errors)


def publish_issues(track_id):
    issues = []
    mods = track_structure(track_id)
    if not mods:
        issues.append("A trilha não tem módulos ativos.")
    for m in mods:
        if not m["lessons"] and not m["activities"]:
            issues.append(f"O módulo “{m['title']}” não tem aulas nem atividades ativas.")
        for a in m["activities"]:
            p = grading.validate_activity(a, grading.questions_for(a["id"]))
            if p:
                issues.append(f"Atividade “{a['title']}”: {p}")
    return issues


@bp.route("/trilhas/<int:track_id>")
@staff_required
def track(track_id):
    t = one("SELECT * FROM tracks WHERE id = ?", (track_id,)) or abort(404)
    mods = track_structure(track_id, include_inactive=True)
    titles = {m["id"]: m["title"] for m in mods}
    counts = {}
    for r in q("SELECT a.id, COUNT(at.id) AS n FROM activities a JOIN modules m ON m.id = a.module_id "
               "LEFT JOIN attempts at ON at.activity_id = a.id AND at.status <> 'in_progress' "
               "WHERE m.track_id = ? GROUP BY a.id", (track_id,)):
        counts[r["id"]] = r["n"]
    qcounts = {r["activity_id"]: r["n"] for r in q(
        "SELECT activity_id, COUNT(*) AS n FROM questions WHERE active = 1 GROUP BY activity_id")}
    n_assigned = one("SELECT COUNT(*) FROM track_assignments WHERE track_id = ?", (track_id,))[0]
    return render_template("content/track.html", t=t, mods=mods, titles=titles, attempt_counts=counts,
                           qcounts=qcounts, issues=publish_issues(track_id), n_assigned=n_assigned)


@bp.route("/trilhas/<int:track_id>/status", methods=["POST"])
@staff_required
def track_status(track_id):
    t = one("SELECT * FROM tracks WHERE id = ?", (track_id,)) or abort(404)
    new = request.form.get("status")
    if new not in ("draft", "published", "archived"):
        abort(400)
    if new == "published":
        issues = publish_issues(track_id)
        if issues:
            flash("Corrija os pontos indicados antes de publicar.", "error")
            return redirect(url_for("content.track", track_id=track_id))
    ts = now_iso()
    with Tx():
        run("UPDATE tracks SET status = ?, published_at = CASE WHEN ? = 'published' THEN ? ELSE published_at END, "
            "updated_at = ? WHERE id = ?", (new, new, ts, ts, track_id))
        audit("status:" + new, "track", track_id, t["title"])
    msgs = {"published": "Trilha publicada. Colaboradores atribuídos já podem acessá-la.",
            "draft": "Trilha voltou para rascunho e deixou de aparecer para os colaboradores. O progresso foi preservado.",
            "archived": "Trilha arquivada. O histórico de aprendizagem foi preservado."}
    flash(msgs[new], "success")
    return redirect(url_for("content.track", track_id=track_id))


# ------------------------------------------------------------------ módulos
def _module_form(track_id, module_id=None):
    f = request.form
    data = {"title": (f.get("title") or "").strip()[:160], "description": (f.get("description") or "").strip()[:4000],
            "objectives": "\n".join(l.strip() for l in (f.get("objectives") or "").splitlines() if l.strip())[:4000],
            "estimated_minutes": _int_or_none(f.get("estimated_minutes"), 1, 10000),
            "prereqs": {to_int(x) for x in f.getlist("prereqs")} - {None}}
    errors = {}
    if len(data["title"]) < 3:
        errors["title"] = "Informe um título com pelo menos 3 caracteres."
    if data["estimated_minutes"] == "invalid":
        errors["estimated_minutes"] = "Use um número de minutos entre 1 e 10000."
    valid = {r["id"] for r in q("SELECT id FROM modules WHERE track_id = ?", (track_id,))}
    if not data["prereqs"] <= valid:
        errors["prereqs"] = "Pré-requisito inválido."
    if module_id and module_id in data["prereqs"]:
        errors["prereqs"] = "Um módulo não pode ser pré-requisito de si mesmo."
    if module_id and not errors.get("prereqs") and _creates_cycle(track_id, module_id, data["prereqs"]):
        errors["prereqs"] = "Esses pré-requisitos criariam uma dependência circular entre módulos."
    return data, errors


def _creates_cycle(track_id, module_id, new_prereqs):
    edges = {}
    for r in q("SELECT mp.module_id, mp.requires_module_id FROM module_prerequisites mp JOIN modules m "
               "ON m.id = mp.module_id WHERE m.track_id = ?", (track_id,)):
        if r["module_id"] != module_id:
            edges.setdefault(r["module_id"], set()).add(r["requires_module_id"])
    edges[module_id] = set(new_prereqs)
    seen, stack = set(), list(new_prereqs)
    while stack:
        n = stack.pop()
        if n == module_id:
            return True
        if n in seen:
            continue
        seen.add(n)
        stack.extend(edges.get(n, ()))
    return False


@bp.route("/modulos/novo", methods=["GET", "POST"])
@staff_required
def module_new():
    track_id = to_int(request.args.get("trilha"))
    t = one("SELECT * FROM tracks WHERE id = ?", (track_id,)) or abort(404)
    others = q("SELECT id, title FROM modules WHERE track_id = ? ORDER BY position", (track_id,))
    data, errors = {"prereqs": set()}, {}
    if request.method == "POST":
        data, errors = _module_form(track_id)
        if not errors:
            ts = now_iso()
            with Tx():
                mid = run("INSERT INTO modules(track_id,title,description,objectives,position,estimated_minutes,"
                          "created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)",
                          (track_id, data["title"], data["description"], data["objectives"],
                           _next_pos("modules", track_id), data["estimated_minutes"], ts, ts))
                for p in data["prereqs"]:
                    run("INSERT INTO module_prerequisites(module_id, requires_module_id) VALUES (?,?)", (mid, p))
                audit("create", "module", mid, data["title"])
            flash("Módulo criado.", "success")
            return redirect(url_for("content.track", track_id=track_id) + f"#mod-{mid}")
    return render_template("content/module_form.html", t=t, m=None, data=data, errors=errors, others=others)


@bp.route("/modulos/<int:module_id>/editar", methods=["GET", "POST"])
@staff_required
def module_edit(module_id):
    m = one("SELECT * FROM modules WHERE id = ?", (module_id,)) or abort(404)
    t = one("SELECT * FROM tracks WHERE id = ?", (m["track_id"],))
    others = q("SELECT id, title FROM modules WHERE track_id = ? AND id <> ? ORDER BY position", (m["track_id"], module_id))
    cur = {r["requires_module_id"] for r in q("SELECT requires_module_id FROM module_prerequisites WHERE module_id = ?",
                                              (module_id,))}
    data, errors = {**dict(m), "prereqs": cur}, {}
    if request.method == "POST":
        data, errors = _module_form(m["track_id"], module_id)
        if not errors:
            with Tx():
                run("UPDATE modules SET title=?, description=?, objectives=?, estimated_minutes=?, updated_at=? WHERE id=?",
                    (data["title"], data["description"], data["objectives"], data["estimated_minutes"], now_iso(),
                     module_id))
                run("DELETE FROM module_prerequisites WHERE module_id = ?", (module_id,))
                for p in data["prereqs"]:
                    run("INSERT INTO module_prerequisites(module_id, requires_module_id) VALUES (?,?)", (module_id, p))
                audit("update", "module", module_id, data["title"])
            flash("Módulo atualizado.", "success")
            return redirect(url_for("content.track", track_id=m["track_id"]) + f"#mod-{module_id}")
    return render_template("content/module_form.html", t=t, m=m, data=data, errors=errors, others=others)


def _has_history_module(module_id):
    return one("SELECT (SELECT COUNT(*) FROM lesson_progress lp JOIN lessons l ON l.id = lp.lesson_id WHERE l.module_id = ?)"
               " + (SELECT COUNT(*) FROM attempts at JOIN activities a ON a.id = at.activity_id WHERE a.module_id = ?)",
               (module_id, module_id))[0] > 0


# ------------------------------------------------------------------ ações genéricas (mover, ativar, excluir)
ENTITY = {
    "modulos": ("modules", "module"), "aulas": ("lessons", "lesson"), "atividades": ("activities", "activity"),
    "questoes": ("questions", "question"),
}


def _track_of(table, item_id):
    if table == "modules":
        r = one("SELECT track_id FROM modules WHERE id = ?", (item_id,))
    elif table in ("lessons", "activities"):
        r = one(f"SELECT m.track_id FROM {table} x JOIN modules m ON m.id = x.module_id WHERE x.id = ?", (item_id,))
    else:
        r = one("SELECT m.track_id FROM questions x JOIN activities a ON a.id = x.activity_id "
                "JOIN modules m ON m.id = a.module_id WHERE x.id = ?", (item_id,))
    if r is None:
        abort(404)
    return r[0]


@bp.route("/<kind>/<int:item_id>/mover", methods=["POST"])
@staff_required
def move(kind, item_id):
    if kind not in ENTITY:
        abort(404)
    table, label = ENTITY[kind]
    direction = request.form.get("dir")
    if direction not in ("up", "down"):
        abort(400)
    tid = _track_of(table, item_id)
    _move(table, item_id, direction)
    audit("move:" + direction, label, item_id)
    return redirect(_back(url_for("content.track", track_id=tid)))


@bp.route("/<kind>/<int:item_id>/situacao", methods=["POST"])
@staff_required
def toggle(kind, item_id):
    if kind not in ENTITY:
        abort(404)
    table, label = ENTITY[kind]
    tid = _track_of(table, item_id)
    row = one(f"SELECT active FROM {table} WHERE id = ?", (item_id,))
    new = 0 if row["active"] else 1
    with Tx():
        run(f"UPDATE {table} SET active = ?, updated_at = ? WHERE id = ?", (new, now_iso(), item_id))
        if table == "questions":
            _bump_for_question(item_id)
        audit("activate" if new else "deactivate", label, item_id)
    flash(("Item reativado." if new else "Item desativado. Ele deixa de contar no progresso, e o histórico "
                                         "já registrado é preservado."), "success")
    return redirect(_back(url_for("content.track", track_id=tid)))


@bp.route("/<kind>/<int:item_id>/excluir", methods=["POST"])
@staff_required
def delete(kind, item_id):
    if kind not in ENTITY:
        abort(404)
    table, label = ENTITY[kind]
    tid = _track_of(table, item_id)
    if table == "modules":
        blocked = _has_history_module(item_id)
    elif table == "lessons":
        blocked = one("SELECT COUNT(*) FROM lesson_progress WHERE lesson_id = ?", (item_id,))[0] > 0
    elif table == "activities":
        blocked = one("SELECT COUNT(*) FROM attempts WHERE activity_id = ?", (item_id,))[0] > 0
    else:
        blocked = one("SELECT COUNT(*) FROM attempt_answers WHERE question_id = ?", (item_id,))[0] > 0
    if blocked:
        flash("Este item já tem histórico de aprendizagem e não pode ser excluído. Desative-o para que deixe de "
              "contar, preservando o histórico.", "error")
        return redirect(_back(url_for("content.track", track_id=tid)))
    with Tx():
        if table == "questions":
            _bump_for_question(item_id)
        run(f"DELETE FROM {table} WHERE id = ?", (item_id,))
        audit("delete", label, item_id)
    flash("Item excluído.", "success")
    return redirect(_back(url_for("content.track", track_id=tid)))


# ------------------------------------------------------------------ aulas
def _lesson_form():
    f = request.form
    data = {"title": (f.get("title") or "").strip()[:200], "summary": (f.get("summary") or "").strip()[:600],
            "body": (f.get("body") or "")[:200000], "video_url": (f.get("video_url") or "").strip()[:1000] or None,
            "required": 1 if f.get("required") else 0,
            "completion_rule": f.get("completion_rule") if f.get("completion_rule") in ("confirm", "activity") else "confirm",
            "min_seconds": to_int(f.get("min_minutes"), 0, 0, 240) * 60,
            "estimated_minutes": _int_or_none(f.get("estimated_minutes"), 1, 10000)}
    errors = {}
    if len(data["title"]) < 3:
        errors["title"] = "Informe um título com pelo menos 3 caracteres."
    if data["video_url"] and not data["video_url"].lower().startswith(("http://", "https://")):
        errors["video_url"] = "O link deve começar com http:// ou https://."
    if data["estimated_minutes"] == "invalid":
        errors["estimated_minutes"] = "Use um número de minutos entre 1 e 10000."
    return data, errors


@bp.route("/aulas/nova", methods=["GET", "POST"])
@staff_required
def lesson_new():
    module_id = to_int(request.args.get("modulo"))
    m = one("SELECT * FROM modules WHERE id = ?", (module_id,)) or abort(404)
    data, errors, preview = {"required": 1, "completion_rule": "confirm", "min_seconds": 0}, {}, None
    if request.method == "POST":
        data, errors = _lesson_form()
        if request.form.get("action") == "preview":
            preview = md_render(data["body"])
        elif not errors:
            ts = now_iso()
            with Tx():
                lid = run("INSERT INTO lessons(module_id,title,summary,body,video_url,position,required,completion_rule,"
                          "min_seconds,estimated_minutes,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                          (module_id, data["title"], data["summary"], data["body"], data["video_url"],
                           _next_pos("lessons", module_id), data["required"], data["completion_rule"],
                           data["min_seconds"], data["estimated_minutes"], ts, ts))
                audit("create", "lesson", lid, data["title"])
            flash("Aula criada. Adicione materiais de apoio, se houver.", "success")
            return redirect(url_for("content.lesson_edit", lesson_id=lid))
    return render_template("content/lesson_form.html", m=m, l=None, data=data, errors=errors, preview=preview,
                           materials=[])


@bp.route("/aulas/<int:lesson_id>/editar", methods=["GET", "POST"])
@staff_required
def lesson_edit(lesson_id):
    l = one("SELECT * FROM lessons WHERE id = ?", (lesson_id,)) or abort(404)
    m = one("SELECT * FROM modules WHERE id = ?", (l["module_id"],))
    data, errors, preview = dict(l), {}, None
    if request.method == "POST":
        data, errors = _lesson_form()
        if request.form.get("action") == "preview":
            preview = md_render(data["body"])
        elif not errors:
            with Tx():
                run("UPDATE lessons SET title=?, summary=?, body=?, video_url=?, required=?, completion_rule=?, "
                    "min_seconds=?, estimated_minutes=?, updated_at=? WHERE id=?",
                    (data["title"], data["summary"], data["body"], data["video_url"], data["required"],
                     data["completion_rule"], data["min_seconds"], data["estimated_minutes"], now_iso(), lesson_id))
                audit("update", "lesson", lesson_id, data["title"])
            flash("Aula salva.", "success")
            return redirect(url_for("content.lesson_edit", lesson_id=lesson_id))
    materials = q("SELECT * FROM materials WHERE lesson_id = ? ORDER BY position, id", (lesson_id,))
    return render_template("content/lesson_form.html", m=m, l=l, data=data, errors=errors, preview=preview,
                           materials=materials)


@bp.route("/aulas/<int:lesson_id>/materiais", methods=["POST"])
@staff_required
def material_add(lesson_id):
    l = one("SELECT * FROM lessons WHERE id = ?", (lesson_id,)) or abort(404)
    title = (request.form.get("title") or "").strip()[:200]
    url = (request.form.get("url") or "").strip()[:1000]
    f = request.files.get("file")
    ts = now_iso()
    try:
        if f and f.filename:
            stored, original = save_upload(f, "mt")
            import os
            from flask import current_app
            size = os.path.getsize(f"{current_app.config['UPLOAD_DIR']}/{stored}")
            with Tx():
                mid = run("INSERT INTO materials(lesson_id,kind,title,stored_name,original_name,mime,size_bytes,position,"
                          "created_by,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
                          (lesson_id, "file", title or original, stored, original, f.mimetype, size,
                           _next_pos("materials", lesson_id), g.user["id"], ts))
                audit("create", "material", mid, original)
        elif url:
            if not url.lower().startswith(("http://", "https://")):
                raise grading.GradingError("O link deve começar com http:// ou https://.")
            with Tx():
                mid = run("INSERT INTO materials(lesson_id,kind,title,url,position,created_by,created_at) "
                          "VALUES (?,?,?,?,?,?,?)", (lesson_id, "link", title or url, url,
                                                     _next_pos("materials", lesson_id), g.user["id"], ts))
                audit("create", "material", mid, url)
        else:
            raise grading.GradingError("Envie um arquivo ou informe um link.")
    except grading.GradingError as e:
        flash(str(e), "error")
        return redirect(url_for("content.lesson_edit", lesson_id=lesson_id) + "#materiais")
    flash("Material adicionado.", "success")
    return redirect(url_for("content.lesson_edit", lesson_id=lesson_id) + "#materiais")


@bp.route("/materiais/<int:material_id>/excluir", methods=["POST"])
@staff_required
def material_delete(material_id):
    mat = one("SELECT * FROM materials WHERE id = ?", (material_id,)) or abort(404)
    with Tx():
        run("DELETE FROM materials WHERE id = ?", (material_id,))
        audit("delete", "material", material_id, mat["title"])
    if mat["stored_name"]:
        import os
        from flask import current_app
        try:
            os.remove(f"{current_app.config['UPLOAD_DIR']}/{mat['stored_name']}")
        except OSError:
            pass
    flash("Material removido.", "success")
    return redirect(url_for("content.lesson_edit", lesson_id=mat["lesson_id"]) + "#materiais")


# ------------------------------------------------------------------ atividades
CRITICAL = ("kind", "pass_percent", "max_attempts")


def _activity_form(module_id):
    f = request.form
    data = {"title": (f.get("title") or "").strip()[:200], "description": (f.get("description") or "").strip()[:4000],
            "instructions": (f.get("instructions") or "")[:50000], "kind": f.get("kind"),
            "pass_percent": to_int(f.get("pass_percent"), None, 0, 100),
            "max_attempts": to_int(f.get("max_attempts"), None, 0, 50),
            "feedback_mode": f.get("feedback_mode"), "required": 1 if f.get("required") else 0,
            "published": 1 if f.get("published") else 0, "lesson_id": to_int(f.get("lesson_id"))}
    errors = {}
    if len(data["title"]) < 3:
        errors["title"] = "Informe um título com pelo menos 3 caracteres."
    if data["kind"] not in grading.MANUAL_KINDS | {"quiz", "final"}:
        errors["kind"] = "Escolha o tipo de atividade."
    if data["pass_percent"] is None:
        errors["pass_percent"] = "Informe a nota mínima entre 0 e 100."
    if data["max_attempts"] is None:
        errors["max_attempts"] = "Informe de 0 (ilimitado) a 50 tentativas."
    if data["feedback_mode"] not in ("immediate", "after_close", "never"):
        errors["feedback_mode"] = "Escolha quando mostrar o gabarito."
    if data["lesson_id"] and not one("SELECT 1 FROM lessons WHERE id = ? AND module_id = ?", (data["lesson_id"], module_id)):
        errors["lesson_id"] = "A aula vinculada precisa ser do mesmo módulo."
    return data, errors


def _has_attempts(activity_id):
    return one("SELECT COUNT(*) FROM attempts WHERE activity_id = ?", (activity_id,))[0] > 0


def _bump(activity_id):
    """Nova versão quando a atividade já tem tentativas: preserva as anteriores (ver services/grading.py)."""
    if _has_attempts(activity_id):
        run("UPDATE activities SET version = version + 1, updated_at = ? WHERE id = ?", (now_iso(), activity_id))
        return True
    return False


def _bump_for_question(question_id):
    r = one("SELECT activity_id FROM questions WHERE id = ?", (question_id,))
    if r:
        _bump(r["activity_id"])


@bp.route("/atividades/nova", methods=["GET", "POST"])
@staff_required
def activity_new():
    module_id = to_int(request.args.get("modulo"))
    m = one("SELECT * FROM modules WHERE id = ?", (module_id,)) or abort(404)
    lessons = q("SELECT id, title FROM lessons WHERE module_id = ? ORDER BY position", (module_id,))
    data = {"kind": request.args.get("tipo") or "quiz", "pass_percent": 70, "max_attempts": 3,
            "feedback_mode": "immediate", "required": 1, "published": 1,
            "lesson_id": to_int(request.args.get("aula"))}
    errors = {}
    if request.method == "POST":
        data, errors = _activity_form(module_id)
        if not errors:
            ts = now_iso()
            with Tx():
                aid = run("INSERT INTO activities(module_id,lesson_id,title,description,instructions,kind,pass_percent,"
                          "max_attempts,feedback_mode,required,published,position,created_at,updated_at) "
                          "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                          (module_id, data["lesson_id"], data["title"], data["description"], data["instructions"],
                           data["kind"], data["pass_percent"], data["max_attempts"], data["feedback_mode"],
                           data["required"], data["published"], _next_pos("activities", module_id), ts, ts))
                audit("create", "activity", aid, data["title"])
            flash("Atividade criada." + ("" if data["kind"] == "practical" else " Agora cadastre as questões."), "success")
            return redirect(url_for("content.activity_edit", activity_id=aid))
    return render_template("content/activity_form.html", m=m, a=None, data=data, errors=errors, lessons=lessons,
                           questions=[], n_attempts=0)


@bp.route("/atividades/<int:activity_id>/editar", methods=["GET", "POST"])
@staff_required
def activity_edit(activity_id):
    a = one("SELECT * FROM activities WHERE id = ?", (activity_id,)) or abort(404)
    m = one("SELECT * FROM modules WHERE id = ?", (a["module_id"],))
    lessons = q("SELECT id, title FROM lessons WHERE module_id = ? ORDER BY position", (a["module_id"],))
    data, errors = dict(a), {}
    if request.method == "POST":
        data, errors = _activity_form(a["module_id"])
        if not errors and data["kind"] != a["kind"] and _has_attempts(activity_id):
            errors["kind"] = "O tipo não pode mudar depois que a atividade recebeu respostas. Crie uma nova atividade."
        if not errors:
            with Tx():
                run("UPDATE activities SET lesson_id=?, title=?, description=?, instructions=?, kind=?, pass_percent=?, "
                    "max_attempts=?, feedback_mode=?, required=?, published=?, updated_at=? WHERE id=?",
                    (data["lesson_id"], data["title"], data["description"], data["instructions"], data["kind"],
                     data["pass_percent"], data["max_attempts"], data["feedback_mode"], data["required"],
                     data["published"], now_iso(), activity_id))
                bumped = any(data[k] != a[k] for k in CRITICAL) and _bump(activity_id)
                audit("update", "activity", activity_id, data["title"] + (" (nova versão)" if bumped else ""))
            flash("Atividade salva." + (" Uma nova versão foi criada: tentativas anteriores mantêm a nota e o "
                                        "critério originais." if bumped else ""), "success")
            return redirect(url_for("content.activity_edit", activity_id=activity_id))
    questions = grading.questions_for(activity_id)
    inactive = q("SELECT * FROM questions WHERE activity_id = ? AND active = 0 ORDER BY position", (activity_id,))
    n_attempts = one("SELECT COUNT(*) FROM attempts WHERE activity_id = ? AND status <> 'in_progress'", (activity_id,))[0]
    return render_template("content/activity_form.html", m=m, a=a, data=data, errors=errors, lessons=lessons,
                           questions=questions, inactive=inactive, n_attempts=n_attempts,
                           problem=grading.validate_activity(a, questions))


# ------------------------------------------------------------------ questões
def _question_form():
    f = request.form
    qtype = f.get("qtype")
    data = {"qtype": qtype, "prompt": (f.get("prompt") or "").strip()[:5000],
            "explanation": (f.get("explanation") or "").strip()[:5000]}
    errors = {}
    try:
        data["points"] = float((f.get("points") or "1").replace(",", "."))
        if not 0 < data["points"] <= 100:
            raise ValueError
    except ValueError:
        errors["points"] = "Use um valor de pontos entre 0,1 e 100."
        data["points"] = 1
    if qtype not in ("single", "multiple", "truefalse", "open"):
        errors["qtype"] = "Escolha o tipo da questão."
    if len(data["prompt"]) < 5:
        errors["prompt"] = "Escreva o enunciado da questão."
    options = []
    if qtype == "truefalse":
        correct = f.get("tf_correct")
        if correct not in ("v", "f"):
            errors["options"] = "Indique se a afirmação é verdadeira ou falsa."
        options = [{"text": "Verdadeiro", "is_correct": correct == "v"}, {"text": "Falso", "is_correct": correct == "f"}]
    elif qtype in ("single", "multiple"):
        texts = f.getlist("opt_text")
        marks = set(f.getlist("opt_correct"))
        for i, t in enumerate(texts):
            t = t.strip()[:1000]
            if t:
                options.append({"text": t, "is_correct": str(i) in marks})
        n_ok = sum(o["is_correct"] for o in options)
        if len(options) < 2:
            errors["options"] = "Cadastre pelo menos duas alternativas."
        elif qtype == "single" and n_ok != 1:
            errors["options"] = "Marque exatamente uma alternativa correta."
        elif qtype == "multiple" and n_ok < 1:
            errors["options"] = "Marque pelo menos uma alternativa correta."
    data["options"] = options
    return data, errors


def _save_options(qid, options):
    run("DELETE FROM question_options WHERE question_id = ?", (qid,))
    for i, o in enumerate(options):
        run("INSERT INTO question_options(question_id,text,is_correct,position) VALUES (?,?,?,?)",
            (qid, o["text"], 1 if o["is_correct"] else 0, i))


@bp.route("/questoes/nova", methods=["GET", "POST"])
@staff_required
def question_new():
    activity_id = to_int(request.args.get("atividade"))
    a = one("SELECT * FROM activities WHERE id = ?", (activity_id,)) or abort(404)
    if a["kind"] == "practical":
        flash("Atividades práticas não usam questões: o colaborador envia uma evidência.", "info")
        return redirect(url_for("content.activity_edit", activity_id=activity_id))
    default_type = "open" if a["kind"] in ("open", "case", "simulation") else "single"
    data, errors = {"qtype": request.args.get("tipo") or default_type, "points": 1, "options": []}, {}
    if request.method == "POST":
        data, errors = _question_form()
        if not errors:
            ts = now_iso()
            with Tx():
                qid = run("INSERT INTO questions(activity_id,qtype,prompt,explanation,points,position,created_at,updated_at) "
                          "VALUES (?,?,?,?,?,?,?,?)", (activity_id, data["qtype"], data["prompt"], data["explanation"],
                                                       data["points"], _next_pos("questions", activity_id), ts, ts))
                _save_options(qid, data["options"])
                _bump(activity_id)
                audit("create", "question", qid, data["prompt"][:80])
            flash("Questão adicionada.", "success")
            if request.form.get("go") == "another":
                return redirect(url_for("content.question_new", atividade=activity_id, tipo=data["qtype"]))
            return redirect(url_for("content.activity_edit", activity_id=activity_id) + "#questoes")
    return render_template("content/question_form.html", a=a, qn=None, data=data, errors=errors)


@bp.route("/questoes/<int:question_id>/editar", methods=["GET", "POST"])
@staff_required
def question_edit(question_id):
    qn = one("SELECT * FROM questions WHERE id = ?", (question_id,)) or abort(404)
    a = one("SELECT * FROM activities WHERE id = ?", (qn["activity_id"],))
    data = {**dict(qn), "options": [dict(o) for o in q("SELECT * FROM question_options WHERE question_id = ? "
                                                         "ORDER BY position", (question_id,))]}
    errors = {}
    if request.method == "POST":
        data, errors = _question_form()
        if not errors:
            with Tx():
                run("UPDATE questions SET qtype=?, prompt=?, explanation=?, points=?, updated_at=? WHERE id=?",
                    (data["qtype"], data["prompt"], data["explanation"], data["points"], now_iso(), question_id))
                _save_options(question_id, data["options"])
                bumped = _bump(a["id"])
                audit("update", "question", question_id, data["prompt"][:80])
            flash("Questão salva." + (" A atividade ganhou uma nova versão; tentativas anteriores foram preservadas."
                                      if bumped else ""), "success")
            return redirect(url_for("content.activity_edit", activity_id=a["id"]) + "#questoes")
    return render_template("content/question_form.html", a=a, qn=qn, data=data, errors=errors)
