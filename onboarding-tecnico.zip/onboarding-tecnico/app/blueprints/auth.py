from urllib.parse import urlparse

from flask import Blueprint, flash, g, redirect, render_template, request, url_for

from ..db import one, run
from ..security import (hash_password, is_locked, log_event, login_user, logout_user, register_failure,
                        verify_password)
from ..utils import fmt_datetime, now_iso

bp = Blueprint("auth", __name__)

# hash de referência para equalizar o tempo de resposta quando o e-mail não existe
_DUMMY = hash_password("senha-inexistente-para-tempo-constante")


def _safe_next(target):
    if not target:
        return None
    p = urlparse(target)
    if p.scheme or p.netloc or not target.startswith("/") or target.startswith("//"):
        return None
    return target


@bp.route("/login", methods=["GET", "POST"])
def login():
    if g.user is not None:
        return redirect(url_for("learner.dashboard"))
    error = None
    email = ""
    if request.method == "POST":
        email = (request.form.get("email") or "").strip().lower()
        password = request.form.get("password") or ""
        user = one("SELECT * FROM users WHERE email = ?", (email,)) if email else None
        if user is None:
            verify_password(_DUMMY, password)
            error = "E-mail ou senha incorretos."
        elif is_locked(user):
            error = ("Acesso bloqueado temporariamente por excesso de tentativas. "
                     f"Tente novamente após {fmt_datetime(user['locked_until'])}.")
        elif not verify_password(user["password_hash"], password):
            lock = register_failure(user)
            error = ("Acesso bloqueado temporariamente por excesso de tentativas." if lock
                     else "E-mail ou senha incorretos.")
        elif not user["active"]:
            error = "Sua conta está desativada. Procure a gestão do onboarding."
        else:
            ts = now_iso()
            run("UPDATE users SET failed_logins = 0, locked_until = NULL, last_login_at = ?, last_activity_at = ? "
                "WHERE id = ?", (ts, ts, user["id"]))
            login_user(user)
            log_event(user["id"], "login")
            return redirect(_safe_next(request.args.get("next")) or url_for("learner.dashboard"))
    return render_template("auth/login.html", error=error, email=email), (401 if error else 200)


@bp.route("/logout", methods=["POST"])
def logout():
    logout_user()
    flash("Você saiu da plataforma.", "success")
    return redirect(url_for("auth.login"))
