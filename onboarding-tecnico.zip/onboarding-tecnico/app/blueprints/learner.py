"""Área do colaborador: dashboard, trilha, aulas, conteúdos, atividades e progresso."""
import os
import secrets
import time
from pathlib import Path

from flask import (Blueprint, abort, current_app, flash, g, redirect, render_template, request, session,
                   url_for)
from werkzeug.utils import secure_filename

from ..db import Tx, one, q, run
from ..markdown import plain
from ..security import is_staff, log_event, login_required
from ..services import grading
from ..services.access import is_assigned, learner_gate, load_activity_ctx, load_lesson_ctx
from ..services.progress import (assigned_tracks, history_points, next_step, pending_activities, performance,
                                 sync_completion, track_structure, user_track_state)
from ..utils import jload, now_iso, to_int

bp = Blueprint("learner", __name__)


def _pick_track(tracks):
    tid = to_int(request.args.get("trilha"))
    if tid:
        for t in tracks:
            if t["id"] == tid:
                return t
    for t in tracks:
        if not t["assignment_completed_at"]:
            return t
    return tracks[0] if tracks else None


def _last_event(user_id):
    return one(
        "SELECT e.*, COALESCE(l.title, a.title) AS ref_title FROM events e "
        "LEFT JOIN lessons l ON e.ref_type = 'lesson' AND l.id = e.ref_id "
        "LEFT JOIN activities a ON e.ref_type = 'activity' AND a.id = e.ref_id "
        "WHERE e.user_id = ? AND e.kind <> 'login' ORDER BY e.id DESC LIMIT 1",
        (user_id,),
    )


EVENT_LABELS = {
    "lesson_viewed": "Abriu a aula",
    "lesson_completed": "Concluiu a aula",
    "attempt_started": "Iniciou a atividade",
    "attempt_submitted": "Enviou a atividade",
    "attempt_graded": "Resultado da atividade",
    "login": "Entrou na plataforma",
}


@bp.app_context_processor
def _labels():
    return {"EVENT_LABELS": EVENT_LABELS}


# ------------------------------------------------------------------ dashboard
@bp.route("/")
@login_required
def dashboard():
    user = g.user
    tracks = assigned_tracks(user["id"])
    team = None
    if is_staff(user):
        from ..services.reports import team_overview
        rows = team_overview(user)
        team = {"rows": rows, "total": len({r["user"]["id"] for r in rows})}
        counts = {}
        for r in rows:
            counts[r["cls"]["primary"]] = counts.get(r["cls"]["primary"], 0) + 1
        team["counts"] = counts
        if not tracks:
            return render_template("learner/dashboard_staff.html", team=team)
    track = _pick_track(tracks)
    if track is None:
        return render_template("learner/dashboard.html", track=None, tracks=[], team=team)
    state = user_track_state(user["id"], track["id"])
    sync_completion(user["id"], track["id"], state)
    pend = pending_activities(state)
    awaiting = sum(1 for p in pend if p["state"]["status"] == "awaiting_review")
    return render_template(
        "learner/dashboard.html", track=track, tracks=tracks, state=state, nxt=next_step(state, track["id"]),
        pending=[p for p in pend if p["state"]["status"] != "awaiting_review"], awaiting=awaiting,
        perf=performance(user["id"], track["id"]), last=_last_event(user["id"]),
        history=history_points(user["id"], track["id"]), team=team,
    )


# ------------------------------------------------------------------ trilha e módulos
@bp.route("/trilha")
@login_required
def track():
    tracks = assigned_tracks(g.user["id"])
    t = _pick_track(tracks)
    if t is None:
        return render_template("learner/track.html", track=None, tracks=[])
    state = user_track_state(g.user["id"], t["id"])
    return render_template("learner/track.html", track=t, tracks=tracks, state=state, nxt=next_step(state, t["id"]))


@bp.route("/modulos/<int:module_id>")
@login_required
def module(module_id):
    m = one("SELECT m.*, t.status AS track_status, t.title AS track_title FROM modules m "
            "JOIN tracks t ON t.id = m.track_id WHERE m.id = ?", (module_id,))
    if m is None:
        abort(404)
    preview = is_staff(g.user) and not is_assigned(g.user["id"], m["track_id"])
    if preview:
        st = user_track_state(-1, m["track_id"], track_structure(m["track_id"], include_inactive=False))
        ms = st["by_id"].get(module_id)
        if ms is None:
            abort(404)
        ms["locked"] = False
        return render_template("learner/module.html", m=ms, track=m, preview=True)
    if m["track_status"] != "published" or not is_assigned(g.user["id"], m["track_id"]):
        abort(404)
    if not m["active"]:
        abort(410, description="Este módulo foi desativado pela gestão do onboarding.")
    st = user_track_state(g.user["id"], m["track_id"])
    return render_template("learner/module.html", m=st["by_id"][module_id], track=m, preview=False)


# ------------------------------------------------------------------ aulas
def _neighbors(lesson):
    rows = q("SELECT id, title FROM lessons WHERE module_id = ? AND active = 1 ORDER BY position, id",
             (lesson["module_id"],))
    ids = [r["id"] for r in rows]
    i = ids.index(lesson["id"]) if lesson["id"] in ids else -1
    prev = rows[i - 1] if i > 0 else None
    nxt = rows[i + 1] if 0 <= i < len(rows) - 1 else None
    return prev, nxt


@bp.route("/aulas/<int:lesson_id>")
@login_required
def lesson(lesson_id):
    ctx = load_lesson_ctx(lesson_id)
    state, mod = learner_gate(ctx, ctx["module_id"])
    preview = state is None
    lp = None
    if not preview:
        ts = now_iso()
        with Tx():
            lp = one("SELECT * FROM lesson_progress WHERE user_id = ? AND lesson_id = ?", (g.user["id"], lesson_id))
            if lp is None:
                run("INSERT INTO lesson_progress(user_id, lesson_id, first_viewed_at, last_viewed_at) VALUES (?,?,?,?)",
                    (g.user["id"], lesson_id, ts, ts))
                log_event(g.user["id"], "lesson_viewed", "lesson", lesson_id)
            else:
                run("UPDATE lesson_progress SET last_viewed_at = ?, view_count = view_count + 1 "
                    "WHERE user_id = ? AND lesson_id = ?", (ts, g.user["id"], lesson_id))
            run("UPDATE users SET last_activity_at = ? WHERE id = ?", (ts, g.user["id"]))
        opened = session.get("lesson_open", {})
        opened[str(lesson_id)] = int(time.time())
        session["lesson_open"] = {k: v for k, v in list(opened.items())[-30:]}
        lp = one("SELECT * FROM lesson_progress WHERE user_id = ? AND lesson_id = ?", (g.user["id"], lesson_id))
    lesson_state = None
    if mod:
        lesson_state = next((l for l in mod["lessons"] if l["id"] == lesson_id), None)
    materials = q("SELECT * FROM materials WHERE lesson_id = ? ORDER BY position, id", (lesson_id,))
    related = q("SELECT * FROM activities WHERE lesson_id = ? AND active = 1 AND published = 1 ORDER BY position",
                (lesson_id,))
    related_states = {}
    if mod:
        for a in mod["activities"]:
            related_states[a["id"]] = a["state"]
    prev, nxt = _neighbors(ctx)
    return render_template("learner/lesson.html", l=ctx, lp=lp, ls=lesson_state, mod=mod, materials=materials,
                           related=related, related_states=related_states, prev=prev, nxt=nxt, preview=preview)


@bp.route("/aulas/<int:lesson_id>/concluir", methods=["POST"])
@login_required
def complete_lesson(lesson_id):
    ctx = load_lesson_ctx(lesson_id)
    state, mod = learner_gate(ctx, ctx["module_id"])
    if state is None:
        flash("No modo de pré-visualização nenhum progresso é registrado.", "info")
        return redirect(url_for("learner.lesson", lesson_id=lesson_id))
    if ctx["completion_rule"] != "confirm":
        flash("Esta aula é concluída automaticamente quando a atividade vinculada for aprovada.", "info")
        return redirect(url_for("learner.lesson", lesson_id=lesson_id))
    lp = one("SELECT * FROM lesson_progress WHERE user_id = ? AND lesson_id = ?", (g.user["id"], lesson_id))
    if lp is None:
        abort(400, description="Abra a aula antes de concluí-la.")
    opened = session.get("lesson_open", {}).get(str(lesson_id))
    need = ctx["min_seconds"] or 0
    if need and (opened is None or time.time() - opened < need):
        flash(f"Dedique pelo menos {need // 60 or 1} min à leitura antes de concluir esta aula.", "warning")
        return redirect(url_for("learner.lesson", lesson_id=lesson_id))
    if not lp["completed_at"]:
        with Tx():
            run("UPDATE lesson_progress SET completed_at = ? WHERE user_id = ? AND lesson_id = ?",
                (now_iso(), g.user["id"], lesson_id))
            log_event(g.user["id"], "lesson_completed", "lesson", lesson_id)
        st = user_track_state(g.user["id"], ctx["track_id"])
        sync_completion(g.user["id"], ctx["track_id"], st)
        flash("Aula concluída.", "success")
    _, nxt = _neighbors(ctx)
    if request.form.get("go") == "next" and nxt:
        return redirect(url_for("learner.lesson", lesson_id=nxt["id"]))
    return redirect(url_for("learner.lesson", lesson_id=lesson_id))


# ------------------------------------------------------------------ biblioteca de conteúdos
@bp.route("/conteudos")
@login_required
def library():
    term = (request.args.get("q") or "").strip()
    staff = is_staff(g.user)
    tracks = assigned_tracks(g.user["id"])
    items = []
    seen_tracks = set()
    for t in tracks:
        seen_tracks.add(t["id"])
        st = user_track_state(g.user["id"], t["id"])
        for m in st["modules"]:
            for l in m["lessons"]:
                items.append({"lesson": l, "module": m, "track": t, "locked": m["locked"]})
    if staff:
        for t in q("SELECT * FROM tracks WHERE status <> 'archived' ORDER BY title"):
            if t["id"] in seen_tracks:
                continue
            for m in track_structure(t["id"]):
                for l in m["lessons"]:
                    items.append({"lesson": {**l, "viewed": False, "completed": False}, "module": m, "track": t,
                                  "locked": False, "preview": True})
    if term:
        t_low = term.lower()
        items = [i for i in items if t_low in (i["lesson"]["title"] + " " + i["lesson"]["summary"] + " "
                                                + plain(i["lesson"]["body"]) + " " + i["module"]["title"]).lower()]
        for i in items:
            body = plain(i["lesson"]["body"])
            pos = body.lower().find(t_low)
            i["snippet"] = ("…" if pos > 60 else "") + body[max(0, pos - 60): pos + 120] + "…" if pos >= 0 else None
    return render_template("learner/library.html", items=items, term=term)


# ------------------------------------------------------------------ atividades
@bp.route("/atividades")
@login_required
def activities():
    tracks = assigned_tracks(g.user["id"])
    groups = {k: [] for k in ("todo", "in_progress", "awaiting_review", "failed", "passed", "locked")}
    for t in tracks:
        st = user_track_state(g.user["id"], t["id"])
        for m in st["modules"]:
            for a in m["activities"]:
                item = {**a, "module": m, "track": t}
                s = a["state"]["status"]
                if m["locked"]:
                    groups["locked"].append(item)
                elif s == "pending":
                    groups["todo"].append(item)
                elif s == "in_progress":
                    groups["in_progress"].append(item)
                elif s == "awaiting_review":
                    groups["awaiting_review"].append(item)
                elif s in ("failed", "failed_retry"):
                    groups["failed"].append(item)
                else:
                    groups["passed"].append(item)
    tab = request.args.get("aba", "todo")
    if tab not in groups:
        tab = "todo"
    return render_template("learner/activities.html", groups=groups, tab=tab, has_tracks=bool(tracks))


def _my_attempts(activity_id, user_id):
    return [dict(r) for r in q("SELECT * FROM attempts WHERE activity_id = ? AND user_id = ? ORDER BY number",
                               (activity_id, user_id))]


@bp.route("/atividades/<int:activity_id>")
@login_required
def activity(activity_id):
    ctx = load_activity_ctx(activity_id)
    state, mod = learner_gate(ctx, ctx["module_id"])
    qs = grading.questions_for(activity_id)
    if state is None:
        return render_template("learner/activity.html", a=ctx, st=None, attempts=[], preview=True,
                               qcount=len(qs), problem=grading.validate_activity(ctx, qs))
    ast = next(x["state"] for x in mod["activities"] if x["id"] == activity_id)
    if ast["draft"] is not None and grading.discard_if_outdated(ast["draft"], ctx):
        flash("A atividade foi atualizada pela gestão. Seu rascunho anterior foi descartado e não contou como "
              "tentativa.", "warning")
        return redirect(url_for("learner.activity", activity_id=activity_id))
    return render_template("learner/activity.html", a=ctx, st=ast, attempts=_my_attempts(activity_id, g.user["id"]),
                           preview=False, qcount=len(qs), problem=grading.validate_activity(ctx, qs))


@bp.route("/atividades/<int:activity_id>/iniciar", methods=["POST"])
@login_required
def start_activity(activity_id):
    ctx = load_activity_ctx(activity_id)
    state, mod = learner_gate(ctx, ctx["module_id"])
    if state is None:
        flash("Gestores visualizam a atividade em modo de pré-visualização e não registram tentativas.", "info")
        return redirect(url_for("learner.activity", activity_id=activity_id))
    ast = next(x["state"] for x in mod["activities"] if x["id"] == activity_id)
    try:
        with Tx():
            aid = grading.start_attempt(ctx, g.user["id"], ast)
    except grading.GradingError as e:
        flash(str(e), "error")
        return redirect(url_for("learner.activity", activity_id=activity_id))
    return redirect(url_for("learner.attempt", attempt_id=aid))


def _load_own_attempt(attempt_id):
    at = one("SELECT * FROM attempts WHERE id = ?", (attempt_id,))
    if at is None or at["user_id"] != g.user["id"]:
        abort(404)
    return at


def _answers_view(attempt):
    rows = q("SELECT * FROM attempt_answers WHERE attempt_id = ? ORDER BY id", (attempt["id"],))
    out = []
    for r in rows:
        snap = jload(r["question_snapshot"], {})
        out.append({"row": r, "q": snap, "selected": set(jload(r["selected_options"], []) or [])})
    return out


@bp.route("/tentativas/<int:attempt_id>", methods=["GET", "POST"])
@login_required
def attempt(attempt_id):
    at = _load_own_attempt(attempt_id)
    ctx = load_activity_ctx(at["activity_id"])
    if at["status"] == "in_progress":
        state, mod = learner_gate(ctx, ctx["module_id"])
        if grading.discard_if_outdated(at, ctx):
            flash("A atividade foi atualizada pela gestão. Seu rascunho foi descartado e não contou como tentativa.",
                  "warning")
            return redirect(url_for("learner.activity", activity_id=ctx["id"]))
        if request.method == "POST":
            action = request.form.get("action")
            evidence = None
            try:
                with Tx():
                    blank = grading.save_answers(at, request.form)
                    if action == "submit":
                        if ctx["kind"] == "practical":
                            evidence = _evidence_from_request(at)
                        elif blank:
                            raise grading.GradingError(
                                f"Responda todas as questões antes de enviar ({blank} sem resposta). "
                                "Suas respostas foram mantidas no formulário.")
                        result = grading.submit_attempt(dict(at), ctx, evidence)
            except grading.GradingError as e:
                # mantém o rascunho salvo mesmo quando o envio é recusado
                with Tx():
                    grading.save_answers(at, request.form)
                flash(str(e), "error")
                return redirect(url_for("learner.attempt", attempt_id=attempt_id))
            if action != "submit":
                flash("Rascunho salvo. Você pode continuar depois de onde parou.", "success")
                return redirect(url_for("learner.attempt", attempt_id=attempt_id))
            st = user_track_state(g.user["id"], ctx["track_id"])
            sync_completion(g.user["id"], ctx["track_id"], st)
            if result == "pending_review":
                flash("Respostas enviadas. A atividade agora aguarda correção da gestão.", "success")
            else:
                fresh = one("SELECT * FROM attempts WHERE id = ?", (attempt_id,))
                flash(("Aprovado! " if fresh["passed"] else "Não foi desta vez. ")
                      + f"Você fez {fresh['percent']:.0f}% (mínimo {fresh['pass_percent']}%).",
                      "success" if fresh["passed"] else "warning")
            return redirect(url_for("learner.attempt", attempt_id=attempt_id))
        return render_template("learner/attempt_take.html", a=ctx, at=at, answers=_answers_view(at))
    # resultado
    st_all = user_track_state(g.user["id"], ctx["track_id"]) if ctx["track_status"] == "published" else None
    ast = None
    if st_all and ctx["module_id"] in st_all["by_id"]:
        ast = next((x["state"] for x in st_all["by_id"][ctx["module_id"]]["activities"] if x["id"] == ctx["id"]), None)
    if ast is None:
        ast = grading_state_fallback(ctx, at)
    show = grading.can_show_answers(ctx, ast, at)
    grader = one("SELECT name FROM users WHERE id = ?", (at["graded_by"],)) if at["graded_by"] else None
    return render_template("learner/attempt_result.html", a=ctx, at=at, answers=_answers_view(at), show=show,
                           st=ast, grader=grader)


def grading_state_fallback(ctx, at):
    from ..services.progress import activity_state
    return activity_state(ctx, _my_attempts(ctx["id"], at["user_id"]))


def _evidence_from_request(at):
    text = (request.form.get("evidence_text") or "").strip()[:20000] or None
    url = (request.form.get("evidence_url") or "").strip()[:2000] or None
    if url and not url.lower().startswith(("http://", "https://")):
        raise grading.GradingError("O link da evidência deve começar com http:// ou https://.")
    f = request.files.get("evidence_file")
    stored = original = None
    if f and f.filename:
        stored, original = save_upload(f, prefix="ev")
    return {"text": text, "url": url, "file": stored, "original": original}


def save_upload(f, prefix="mt"):
    original = secure_filename(f.filename) or "arquivo"
    ext = original.rsplit(".", 1)[-1].lower() if "." in original else ""
    if ext not in current_app.config["ALLOWED_UPLOAD_EXTENSIONS"]:
        raise grading.GradingError(
            "Tipo de arquivo não permitido. Use: " + ", ".join(sorted(current_app.config["ALLOWED_UPLOAD_EXTENSIONS"])))
    stored = f"{prefix}_{secrets.token_hex(16)}.{ext}"
    dest = Path(current_app.config["UPLOAD_DIR"]) / stored
    f.save(dest)
    os.chmod(dest, 0o640)
    return stored, f.filename[:200]


# ------------------------------------------------------------------ progresso
@bp.route("/progresso")
@login_required
def progress():
    tracks = assigned_tracks(g.user["id"])
    t = _pick_track(tracks)
    if t is None:
        return render_template("learner/progress.html", track=None, tracks=[])
    state = user_track_state(g.user["id"], t["id"])
    attempts = q(
        "SELECT at.*, a.title, a.kind, m.title AS module_title FROM attempts at JOIN activities a ON a.id = at.activity_id "
        "JOIN modules m ON m.id = a.module_id WHERE at.user_id = ? AND m.track_id = ? AND at.status <> 'in_progress' "
        "ORDER BY at.submitted_at DESC", (g.user["id"], t["id"]))
    events = q(
        "SELECT e.*, COALESCE(l.title, a.title) AS ref_title FROM events e "
        "LEFT JOIN lessons l ON e.ref_type='lesson' AND l.id = e.ref_id "
        "LEFT JOIN activities a ON e.ref_type='activity' AND a.id = e.ref_id "
        "WHERE e.user_id = ? AND e.kind <> 'login' ORDER BY e.id DESC LIMIT 40", (g.user["id"],))
    return render_template("learner/progress.html", track=t, tracks=tracks, state=state, attempts=attempts,
                           events=events, perf=performance(g.user["id"], t["id"]),
                           history=history_points(g.user["id"], t["id"]))
