"""Administração: acompanhamento, colaboradores, usuários, correções, relatórios e auditoria."""
import secrets
import string

from flask import Blueprint, Response, abort, flash, g, redirect, render_template, request, url_for

from ..db import Tx, one, q, run
from ..security import (admin_required, audit, can_view_user, hash_password, password_problems, require_view_user,
                        staff_required)
from ..services import grading
from ..services.progress import FLAG_LABELS, FLAG_TONES, assigned_tracks, classify, performance, sync_completion, \
    user_track_state
from ..services.reports import (attempts_for_export, module_error_stats, pending_reviews, question_error_stats,
                                team_overview, to_csv)
from ..utils import fmt_date, fmt_datetime, jload, now_iso, to_int

bp = Blueprint("admin", __name__, url_prefix="/admin")


@bp.app_context_processor
def _flags():
    return {"FLAG_LABELS": FLAG_LABELS, "FLAG_TONES": FLAG_TONES}


def _visible_tracks():
    return q("SELECT * FROM tracks WHERE status <> 'archived' ORDER BY status = 'published' DESC, title")


# ------------------------------------------------------------------ painel da equipe
def _filter_rows(rows, args):
    name = (args.get("nome") or "").strip().lower()
    status = args.get("status") or ""
    pmin = to_int(args.get("pmin"), None, 0, 100)
    pmax = to_int(args.get("pmax"), None, 0, 100)
    dfrom = args.get("de") or ""
    dto = args.get("ate") or ""
    out = []
    for r in rows:
        u = r["user"]
        if name and name not in (u["name"] + " " + u["email"]).lower():
            continue
        if status:
            if status == "unassigned":
                if r["track"] is not None:
                    continue
            elif status not in r["cls"]["flags"]:
                continue
        pct = r["state"]["percent"] if r["state"] else 0
        if pmin is not None and pct < pmin:
            continue
        if pmax is not None and pct > pmax:
            continue
        sd = r["cls"].get("start_date") or ""
        if dfrom and (not sd or sd < dfrom):
            continue
        if dto and (not sd or sd > dto):
            continue
        out.append(r)
    return out


@bp.route("/")
@staff_required
def overview():
    tracks = _visible_tracks()
    track_id = to_int(request.args.get("trilha"))
    include_inactive = request.args.get("inativos") == "1"
    rows = team_overview(g.user, track_id, include_inactive)
    counts = {k: 0 for k in FLAG_LABELS}
    for r in rows:
        for f in r["cls"]["flags"]:
            counts[f] += 1
    filtered = _filter_rows(rows, request.args)
    order = request.args.get("ordem", "atencao")
    rank = {"needs_attention": 0, "below_min": 1, "awaiting_review": 2, "not_started": 3, "on_track": 4,
            "completed": 5, "unassigned": 6}
    if order == "nome":
        filtered.sort(key=lambda r: r["user"]["name"].lower())
    elif order == "progresso":
        filtered.sort(key=lambda r: (r["state"]["percent"] if r["state"] else -1))
    elif order == "inicio":
        filtered.sort(key=lambda r: r["cls"].get("start_date") or "", reverse=True)
    else:
        filtered.sort(key=lambda r: (rank.get(r["cls"]["primary"], 9), r["state"]["percent"] if r["state"] else 0))
    return render_template("admin/overview.html", rows=filtered, total=len(rows), counts=counts, tracks=tracks,
                           track_id=track_id, args=request.args, include_inactive=include_inactive)


@bp.route("/colaboradores/<int:user_id>")
@staff_required
def collaborator(user_id):
    u = one("SELECT u.*, m.name AS manager_name FROM users u LEFT JOIN users m ON m.id = u.manager_id WHERE u.id = ?",
            (user_id,))
    require_view_user(u)
    tracks = assigned_tracks(user_id, only_published=False)
    sel = to_int(request.args.get("trilha"))
    t = next((x for x in tracks if x["id"] == sel), tracks[0] if tracks else None)
    state = cls = perf = None
    if t:
        state = user_track_state(user_id, t["id"])
        cls = classify(u, t, state)
        perf = performance(user_id, t["id"])
    attempts = q(
        "SELECT at.*, a.title, a.kind, m.title AS module_title, m.track_id FROM attempts at "
        "JOIN activities a ON a.id = at.activity_id JOIN modules m ON m.id = a.module_id "
        "WHERE at.user_id = ? AND at.status <> 'in_progress' ORDER BY at.submitted_at DESC", (user_id,))
    events = q(
        "SELECT e.*, COALESCE(l.title, a.title) AS ref_title FROM events e "
        "LEFT JOIN lessons l ON e.ref_type='lesson' AND l.id = e.ref_id "
        "LEFT JOIN activities a ON e.ref_type='activity' AND a.id = e.ref_id "
        "WHERE e.user_id = ? ORDER BY e.id DESC LIMIT 60", (user_id,))
    from ..services.progress import history_points
    history = history_points(user_id, t["id"]) if t else []
    return render_template("admin/collaborator.html", u=u, tracks=tracks, track=t, state=state, cls=cls, perf=perf,
                           attempts=attempts, events=events, history=history)


# ------------------------------------------------------------------ correções
def _attempt_ctx(attempt_id):
    at = one("SELECT * FROM attempts WHERE id = ?", (attempt_id,))
    if at is None:
        abort(404)
    owner = one("SELECT * FROM users WHERE id = ?", (at["user_id"],))
    require_view_user(owner)
    if owner["id"] == g.user["id"]:
        abort(403)  # ninguém corrige a própria tentativa
    act = one("SELECT a.*, m.title AS module_title, m.track_id FROM activities a JOIN modules m ON m.id = a.module_id "
              "WHERE a.id = ?", (at["activity_id"],))
    return at, owner, act


@bp.route("/correcoes")
@staff_required
def reviews():
    return render_template("admin/reviews.html", items=pending_reviews(g.user))


@bp.route("/tentativas/<int:attempt_id>")
@staff_required
def attempt(attempt_id):
    at, owner, act = _attempt_ctx(attempt_id)
    answers = []
    for r in q("SELECT * FROM attempt_answers WHERE attempt_id = ? ORDER BY id", (attempt_id,)):
        answers.append({"row": r, "q": jload(r["question_snapshot"], {}),
                        "selected": set(jload(r["selected_options"], []) or [])})
    grader = one("SELECT name FROM users WHERE id = ?", (at["graded_by"],)) if at["graded_by"] else None
    history = q("SELECT * FROM attempts WHERE activity_id = ? AND user_id = ? AND status <> 'in_progress' "
                "ORDER BY number", (act["id"], owner["id"]))
    return render_template("admin/attempt.html", at=at, owner=owner, a=act, answers=answers, grader=grader,
                           history=history)


@bp.route("/tentativas/<int:attempt_id>/corrigir", methods=["POST"])
@staff_required
def grade(attempt_id):
    at, owner, act = _attempt_ctx(attempt_id)
    feedback = (request.form.get("feedback") or "").strip()[:5000] or None
    try:
        with Tx():
            if act["kind"] == "practical":
                raw = (request.form.get("practical_percent") or "").replace(",", ".").strip()
                try:
                    pct = float(raw)
                except ValueError:
                    raise grading.GradingError("Informe a nota da atividade prática (0 a 100).")
                passed = grading.grade_manual(at, g.user["id"], {}, feedback, practical_percent=pct)
            else:
                per = {}
                for r in q("SELECT * FROM attempt_answers WHERE attempt_id = ?", (attempt_id,)):
                    snap = jload(r["question_snapshot"], {})
                    if snap.get("qtype") != "open":
                        continue
                    raw = (request.form.get(f"pts_{r['id']}") or "").replace(",", ".").strip()
                    try:
                        val = float(raw)
                    except ValueError:
                        val = None
                    per[r["id"]] = (val, (request.form.get(f"cmt_{r['id']}") or "").strip()[:3000])
                passed = grading.grade_manual(at, g.user["id"], per, feedback)
            audit("grade", "attempt", attempt_id, f"{owner['email']} · {act['title']} · {'aprovado' if passed else 'reprovado'}")
    except grading.GradingError as e:
        flash(str(e), "error")
        return redirect(url_for("admin.attempt", attempt_id=attempt_id))
    st = user_track_state(owner["id"], act["track_id"])
    sync_completion(owner["id"], act["track_id"], st)
    flash(f"Correção registrada: {'aprovado' if passed else 'reprovado'}.", "success")
    nxt = one("SELECT at.id FROM attempts at JOIN users u ON u.id = at.user_id WHERE at.status = 'pending_review' "
              "AND at.id <> ? ORDER BY at.submitted_at LIMIT 1", (attempt_id,))
    if request.form.get("go") == "next" and nxt:
        other = one("SELECT * FROM users WHERE id = (SELECT user_id FROM attempts WHERE id = ?)", (nxt["id"],))
        if can_view_user(g.user, other) and other["id"] != g.user["id"]:
            return redirect(url_for("admin.attempt", attempt_id=nxt["id"]))
    return redirect(url_for("admin.reviews"))


# ------------------------------------------------------------------ relatórios
@bp.route("/relatorios")
@staff_required
def reports():
    tracks = _visible_tracks()
    track_id = to_int(request.args.get("trilha")) or (tracks[0]["id"] if tracks else None)
    track = next((t for t in tracks if t["id"] == track_id), None)
    if track is None:
        return render_template("admin/reports.html", track=None, tracks=tracks)
    rows = [r for r in team_overview(g.user, track_id) if r["track"] is not None]
    n = len(rows)
    counts = {k: 0 for k in FLAG_LABELS}
    for r in rows:
        counts[r["cls"]["primary"]] = counts.get(r["cls"]["primary"], 0) + 1
    avg_pct = sum(r["state"]["percent"] for r in rows) / n if n else None
    graded = [r["perf"]["avg_percent"] for r in rows if r["perf"]["avg_percent"] is not None]
    avg_score = sum(graded) / len(graded) if graded else None
    mod_completion = []
    if rows:
        for m in rows[0]["state"]["modules"]:
            done = sum(1 for r in rows if r["state"]["by_id"][m["id"]]["completed"])
            mod_completion.append({"title": m["title"], "position": m["position"], "done": done, "total": n,
                                   "pct": done / n * 100})
    return render_template("admin/reports.html", track=track, tracks=tracks, n=n, counts=counts, avg_pct=avg_pct,
                           avg_score=avg_score, mod_completion=mod_completion,
                           mod_errors=module_error_stats(g.user, track_id),
                           q_errors=question_error_stats(g.user, track_id), rows=rows)


@bp.route("/relatorios/colaboradores.csv")
@staff_required
def export_collaborators():
    track_id = to_int(request.args.get("trilha"))
    rows = team_overview(g.user, track_id, include_inactive=True)
    data = []
    for r in rows:
        u, st, cls, perf = r["user"], r["state"], r["cls"], r["perf"]
        data.append([
            u["name"], u["email"], "Ativo" if u["active"] else "Desativado", u["manager_name"] or "",
            r["track"]["title"] if r["track"] else "Sem trilha", fmt_date(cls.get("start_date")),
            st["percent"] if st else "", f"{st['modules_done']}/{st['modules_total']}" if st else "",
            f"{st['required_done']}/{st['required_total']}" if st else "",
            round(perf["avg_percent"], 1) if perf["avg_percent"] is not None else "",
            perf["graded"], cls.get("awaiting", 0),
            FLAG_LABELS.get(cls["primary"], "Sem trilha"), " | ".join(cls.get("reasons", [])),
            fmt_datetime(u["last_activity_at"]), "Sim" if u["is_demo"] else "Não",
        ])
    csv = to_csv(["Nome", "E-mail", "Conta", "Gestor", "Trilha", "Início", "Progresso (%)", "Módulos concluídos",
                  "Etapas obrigatórias", "Média nas avaliações (%)", "Avaliações corrigidas", "Aguardando correção",
                  "Situação", "Motivos de atenção", "Última interação", "Dado de demonstração"], data)
    audit("export", "report", None, "colaboradores.csv")
    return Response(csv, mimetype="text/csv; charset=utf-8",
                    headers={"Content-Disposition": "attachment; filename=colaboradores.csv"})


@bp.route("/relatorios/tentativas.csv")
@staff_required
def export_attempts():
    track_id = to_int(request.args.get("trilha"))
    status_l = {"pending_review": "Aguardando correção", "graded": "Corrigida"}
    data = [[r["name"], r["email"], r["track"], r["module"], r["activity"], r["kind"], r["number"],
             status_l.get(r["status"], r["status"]), fmt_datetime(r["submitted_at"]), fmt_datetime(r["graded_at"]),
             r["score"], r["max_score"], round(r["percent"], 1) if r["percent"] is not None else "", r["pass_percent"],
             "" if r["passed"] is None else ("Aprovado" if r["passed"] else "Reprovado"), r["correct_count"],
             r["wrong_count"], r["activity_version"], "Sim" if r["is_demo"] else "Não"]
            for r in attempts_for_export(g.user, track_id)]
    csv = to_csv(["Nome", "E-mail", "Trilha", "Módulo", "Atividade", "Tipo", "Tentativa", "Status", "Enviada em",
                  "Corrigida em", "Pontos", "Pontos máximos", "Nota (%)", "Mínimo (%)", "Resultado", "Acertos",
                  "Erros", "Versão da atividade", "Dado de demonstração"], data)
    audit("export", "report", None, "tentativas.csv")
    return Response(csv, mimetype="text/csv; charset=utf-8",
                    headers={"Content-Disposition": "attachment; filename=tentativas.csv"})


# ------------------------------------------------------------------ usuários
def _gen_password():
    alphabet = string.ascii_letters + string.digits
    while True:
        p = "".join(secrets.choice(alphabet) for _ in range(12))
        if any(c.isdigit() for c in p) and any(c.isalpha() for c in p):
            return p


def _can_manage(target):
    me = g.user
    if me["role"] == "admin":
        return True
    return target["role"] == "collaborator" and target["manager_id"] == me["id"]


@bp.route("/usuarios")
@staff_required
def users():
    me = g.user
    term = (request.args.get("q") or "").strip()
    role = request.args.get("perfil") or ""
    status = request.args.get("situacao") or ""
    where, params = ["1=1"], []
    if me["role"] != "admin":
        where.append("(u.role = 'collaborator' AND u.manager_id = ?)")
        params.append(me["id"])
    if term:
        where.append("(u.name LIKE ? OR u.email LIKE ?)")
        params += [f"%{term}%", f"%{term}%"]
    if role in ("admin", "manager", "collaborator"):
        where.append("u.role = ?")
        params.append(role)
    if status == "ativos":
        where.append("u.active = 1")
    elif status == "desativados":
        where.append("u.active = 0")
    rows = q("SELECT u.*, m.name AS manager_name, "
             "(SELECT COUNT(*) FROM track_assignments ta WHERE ta.user_id = u.id) AS n_tracks "
             f"FROM users u LEFT JOIN users m ON m.id = u.manager_id WHERE {' AND '.join(where)} ORDER BY u.active DESC, u.name",
             params)
    return render_template("admin/users.html", rows=rows, term=term, role=role, status=status)


def _user_form_data(target=None):
    f = request.form
    data = {
        "name": (f.get("name") or "").strip()[:120],
        "email": (f.get("email") or "").strip().lower()[:200],
        "role": f.get("role") or "collaborator",
        "job_title": (f.get("job_title") or "").strip()[:120] or None,
        "start_date": (f.get("start_date") or "").strip() or None,
        "manager_id": to_int(f.get("manager_id")),
    }
    errors = {}
    if len(data["name"]) < 3:
        errors["name"] = "Informe o nome completo."
    import re
    if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", data["email"]):
        errors["email"] = "Informe um e-mail válido."
    else:
        dup = one("SELECT id FROM users WHERE email = ?", (data["email"],))
        if dup and (target is None or dup["id"] != target["id"]):
            errors["email"] = "Já existe uma conta com este e-mail."
    if g.user["role"] != "admin":
        data["role"] = "collaborator"
        data["manager_id"] = g.user["id"]
    if data["role"] not in ("admin", "manager", "collaborator"):
        errors["role"] = "Perfil inválido."
    if data["start_date"]:
        import datetime
        try:
            datetime.date.fromisoformat(data["start_date"])
        except ValueError:
            errors["start_date"] = "Data inválida."
    if data["manager_id"]:
        mgr = one("SELECT * FROM users WHERE id = ? AND role IN ('admin','manager')", (data["manager_id"],))
        if mgr is None:
            errors["manager_id"] = "Escolha um gestor válido."
    if data["role"] != "collaborator":
        data["manager_id"] = None
    if target is not None and target["id"] == g.user["id"] and data["role"] != g.user["role"]:
        errors["role"] = "Você não pode alterar o próprio perfil de acesso."
    return data, errors


def _managers():
    return q("SELECT id, name FROM users WHERE role IN ('admin','manager') AND active = 1 ORDER BY name")


@bp.route("/usuarios/novo", methods=["GET", "POST"])
@staff_required
def user_new():
    errors, data, temp = {}, {"role": "collaborator", "manager_id": g.user["id"] if g.user["role"] == "manager" else None}, None
    tracks = q("SELECT * FROM tracks WHERE status = 'published' ORDER BY title")
    if request.method == "POST":
        data, errors = _user_form_data()
        if not errors:
            temp = _gen_password()
            ts = now_iso()
            with Tx():
                uid = run(
                    "INSERT INTO users(name,email,password_hash,role,active,manager_id,job_title,start_date,"
                    "must_change_password,created_at,updated_at) VALUES (?,?,?,?,1,?,?,?,1,?,?)",
                    (data["name"], data["email"], hash_password(temp), data["role"], data["manager_id"],
                     data["job_title"], data["start_date"] or ts[:10], ts, ts))
                for tid in request.form.getlist("tracks"):
                    tid = to_int(tid)
                    if tid and one("SELECT 1 FROM tracks WHERE id = ? AND status = 'published'", (tid,)):
                        run("INSERT OR IGNORE INTO track_assignments(track_id,user_id,assigned_by,assigned_at) "
                            "VALUES (?,?,?,?)", (tid, uid, g.user["id"], ts))
                audit("create", "user", uid, f"{data['email']} ({data['role']})")
            u = one("SELECT * FROM users WHERE id = ?", (uid,))
            return render_template("admin/user_created.html", u=u, temp=temp)
    return render_template("admin/user_form.html", u=None, data=data, errors=errors, managers=_managers(),
                           tracks=tracks, assigned=set())


@bp.route("/usuarios/<int:user_id>/editar", methods=["GET", "POST"])
@staff_required
def user_edit(user_id):
    u = one("SELECT * FROM users WHERE id = ?", (user_id,))
    if u is None:
        abort(404)
    if not _can_manage(u):
        abort(403)
    tracks = q("SELECT * FROM tracks WHERE status <> 'archived' ORDER BY title")
    assigned = {r["track_id"] for r in q("SELECT track_id FROM track_assignments WHERE user_id = ?", (user_id,))}
    errors, data = {}, dict(u)
    if request.method == "POST":
        data, errors = _user_form_data(u)
        if not errors:
            ts = now_iso()
            want = {to_int(t) for t in request.form.getlist("tracks")} - {None}
            with Tx():
                run("UPDATE users SET name=?, email=?, role=?, manager_id=?, job_title=?, start_date=?, updated_at=? "
                    "WHERE id=?", (data["name"], data["email"], data["role"], data["manager_id"], data["job_title"],
                                   data["start_date"], ts, user_id))
                for tid in want - assigned:
                    if one("SELECT 1 FROM tracks WHERE id = ? AND status = 'published'", (tid,)):
                        run("INSERT OR IGNORE INTO track_assignments(track_id,user_id,assigned_by,assigned_at) "
                            "VALUES (?,?,?,?)", (tid, user_id, g.user["id"], ts))
                removed = assigned - want
                for tid in removed:
                    # o histórico (aulas e tentativas) é preservado; só a atribuição é removida
                    run("DELETE FROM track_assignments WHERE track_id = ? AND user_id = ?", (tid, user_id))
                audit("update", "user", user_id, f"{data['email']}; trilhas +{sorted(want - assigned)} -{sorted(removed)}")
            flash("Usuário atualizado.", "success")
            return redirect(url_for("admin.users"))
        assigned = {to_int(t) for t in request.form.getlist("tracks")} - {None}
    return render_template("admin/user_form.html", u=u, data=data, errors=errors, managers=_managers(),
                           tracks=tracks, assigned=assigned)


@bp.route("/usuarios/<int:user_id>/situacao", methods=["POST"])
@staff_required
def user_toggle(user_id):
    u = one("SELECT * FROM users WHERE id = ?", (user_id,))
    if u is None:
        abort(404)
    if not _can_manage(u):
        abort(403)
    if u["id"] == g.user["id"]:
        flash("Você não pode desativar a própria conta.", "error")
        return redirect(url_for("admin.users"))
    active = 0 if u["active"] else 1
    if not active and u["role"] == "admin":
        others = one("SELECT COUNT(*) FROM users WHERE role='admin' AND active=1 AND id <> ?", (user_id,))[0]
        if others == 0:
            flash("É preciso manter pelo menos um administrador ativo.", "error")
            return redirect(url_for("admin.users"))
    with Tx():
        run("UPDATE users SET active = ?, session_version = session_version + 1, updated_at = ? WHERE id = ?",
            (active, now_iso(), user_id))
        audit("activate" if active else "deactivate", "user", user_id, u["email"])
    flash(f"Conta de {u['name']} {'reativada' if active else 'desativada'}. "
          + ("" if active else "O histórico de aprendizagem foi preservado."), "success")
    back = request.form.get("back") or ""
    if not back.startswith("/") or back.startswith("//"):
        back = url_for("admin.users")
    return redirect(back)


@bp.route("/usuarios/<int:user_id>/redefinir-senha", methods=["POST"])
@staff_required
def user_reset(user_id):
    u = one("SELECT * FROM users WHERE id = ?", (user_id,))
    if u is None:
        abort(404)
    if not _can_manage(u) or u["id"] == g.user["id"]:
        abort(403)
    temp = _gen_password()
    with Tx():
        run("UPDATE users SET password_hash = ?, must_change_password = 1, session_version = session_version + 1, "
            "failed_logins = 0, locked_until = NULL, updated_at = ? WHERE id = ?", (hash_password(temp), now_iso(), user_id))
        audit("reset_password", "user", user_id, u["email"])
    return render_template("admin/user_created.html", u=u, temp=temp, reset=True)


# ------------------------------------------------------------------ auditoria
@bp.route("/auditoria")
@admin_required
def audit_log():
    rows = q("SELECT a.*, u.name AS actor FROM audit_log a LEFT JOIN users u ON u.id = a.actor_id "
             "ORDER BY a.id DESC LIMIT 300")
    return render_template("admin/audit.html", rows=rows)
