from flask import Blueprint, flash, g, redirect, render_template, request, url_for

from ..db import Tx, one, run
from ..security import hash_password, login_required, login_user, password_problems, verify_password
from ..utils import now_iso

bp = Blueprint("account", __name__, url_prefix="/conta")


@bp.route("/", methods=["GET", "POST"])
@login_required
def profile():
    errors = {}
    if request.method == "POST":
        name = (request.form.get("name") or "").strip()
        job = (request.form.get("job_title") or "").strip()[:120]
        if len(name) < 3:
            errors["name"] = "Informe seu nome completo."
        if not errors:
            run("UPDATE users SET name = ?, job_title = ?, updated_at = ? WHERE id = ?",
                (name[:120], job or None, now_iso(), g.user["id"]))
            flash("Dados atualizados.", "success")
            return redirect(url_for("account.profile"))
    manager = one("SELECT name, email FROM users WHERE id = ?", (g.user["manager_id"],)) if g.user["manager_id"] else None
    return render_template("account/profile.html", errors=errors, manager=manager)


@bp.route("/senha", methods=["GET", "POST"])
@login_required
def password():
    errors = {}
    if request.method == "POST":
        current = request.form.get("current") or ""
        new = request.form.get("new") or ""
        confirm = request.form.get("confirm") or ""
        if not verify_password(g.user["password_hash"], current):
            errors["current"] = "Senha atual incorreta."
        probs = password_problems(new)
        if probs:
            errors["new"] = "A nova senha precisa " + " e ".join(probs) + "."
        elif new == current:
            errors["new"] = "A nova senha deve ser diferente da atual."
        if new != confirm:
            errors["confirm"] = "A confirmação não confere com a nova senha."
        if not errors:
            with Tx():
                run("UPDATE users SET password_hash = ?, must_change_password = 0, "
                    "session_version = session_version + 1, updated_at = ? WHERE id = ?",
                    (hash_password(new), now_iso(), g.user["id"]))
            user = one("SELECT * FROM users WHERE id = ?", (g.user["id"],))
            login_user(user)  # mantém esta sessão e encerra as demais
            flash("Senha alterada. Outras sessões abertas foram encerradas.", "success")
            return redirect(url_for("account.profile"))
    return render_template("account/password.html", errors=errors)
