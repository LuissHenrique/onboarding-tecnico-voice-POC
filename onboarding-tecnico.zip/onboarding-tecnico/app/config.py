"""Configuração por variáveis de ambiente (ver .env.example)."""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent


def _bool(name, default=False):
    v = os.environ.get(name)
    if v is None or not v.strip():
        return default
    return v.strip().lower() in ("1", "true", "yes", "on", "sim")


class Config:
    ENV = os.environ.get("APP_ENV", "development")
    SECRET_KEY = os.environ.get("SECRET_KEY", "")
    DATABASE_PATH = os.environ.get("DATABASE_PATH", str(BASE_DIR / "instance" / "onboarding.db"))
    UPLOAD_DIR = os.environ.get("UPLOAD_DIR", str(BASE_DIR / "instance" / "uploads"))
    MAX_CONTENT_LENGTH = int(os.environ.get("MAX_UPLOAD_MB", "20")) * 1024 * 1024
    APP_NAME = os.environ.get("APP_NAME", "Onboarding Técnico")
    APP_SUBTITLE = os.environ.get("APP_SUBTITLE", "Suporte PABX em nuvem")
    # Caminho (dentro de app/static) do arquivo oficial do logotipo, quando disponibilizado.
    LOGO_FILE = os.environ.get("LOGO_FILE", "")
    TIMEZONE = os.environ.get("APP_TIMEZONE", "America/Sao_Paulo")
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = _bool("SESSION_COOKIE_SECURE", ENV == "production")
    SESSION_COOKIE_NAME = "otk_session"
    PERMANENT_SESSION_LIFETIME = int(os.environ.get("SESSION_HOURS", "10")) * 3600
    LOGIN_MAX_FAILURES = int(os.environ.get("LOGIN_MAX_FAILURES", "5"))
    LOGIN_LOCK_MINUTES = int(os.environ.get("LOGIN_LOCK_MINUTES", "15"))
    PASSWORD_MIN_LENGTH = 10
    # Ritmo: colaborador fica "abaixo do esperado" quando está X pontos percentuais atrás do ritmo previsto.
    PACE_TOLERANCE_POINTS = int(os.environ.get("PACE_TOLERANCE_POINTS", "20"))
    INACTIVITY_ALERT_DAYS = int(os.environ.get("INACTIVITY_ALERT_DAYS", "7"))
    ALLOWED_UPLOAD_EXTENSIONS = {
        "pdf", "png", "jpg", "jpeg", "gif", "webp", "txt", "csv", "pcap", "pcapng",
        "doc", "docx", "xls", "xlsx", "ppt", "pptx", "zip", "log", "mp4",
    }
    TESTING = False
