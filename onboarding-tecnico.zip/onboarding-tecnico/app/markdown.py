"""Renderizador Markdown seguro (subconjunto) para o conteúdo das aulas.

Todo HTML digitado é escapado; só as construções abaixo geram marcação:
  # a ####  títulos            - item / 1. item   listas (aninhamento com 2 espaços)
  **negrito**  *itálico*  `código`  [texto](url)  ![legenda](url)
  ```bloco de código```        | tabela | com | --- |
  > [!INFO] / [!AVISO] / [!DICA] / [!IMPORTANTE]  caixas de alerta
  :::detalhes Título ... :::   seção recolhível            ---   divisória
"""
import html
import re

from markupsafe import Markup

CALLOUTS = {
    "INFO": ("info", "Informação"),
    "AVISO": ("warn", "Atenção"),
    "ATENCAO": ("warn", "Atenção"),
    "DICA": ("tip", "Dica"),
    "IMPORTANTE": ("danger", "Importante"),
    "EXEMPLO": ("example", "Exemplo prático"),
}

_SAFE_URL = re.compile(r"^(https?://|/|#|mailto:)", re.I)


def _url(u):
    u = html.unescape(u.strip())
    if not _SAFE_URL.match(u):
        return None
    return html.escape(u, quote=True)


def inline(text):
    s = html.escape(text, quote=False)
    codes = []

    def keep_code(m):
        codes.append(m.group(1))
        return f"\x00{len(codes) - 1}\x00"

    s = re.sub(r"`([^`]+)`", keep_code, s)

    def img(m):
        u = _url(m.group(2))
        if not u:
            return m.group(0)
        alt = html.escape(html.unescape(m.group(1)), quote=True)
        return f'<figure class="md-fig"><img src="{u}" alt="{alt}" loading="lazy"><figcaption>{m.group(1)}</figcaption></figure>'

    s = re.sub(r"!\[([^\]]*)\]\(([^)\s]+)\)", img, s)

    def link(m):
        u = _url(m.group(2))
        if not u:
            return m.group(1)
        ext = u.startswith("http")
        attrs = ' target="_blank" rel="noopener noreferrer"' if ext else ""
        return f'<a href="{u}"{attrs}>{m.group(1)}</a>'

    s = re.sub(r"\[([^\]]+)\]\(([^)\s]+)\)", link, s)
    s = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", s)
    s = re.sub(r"(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?!\w)", r"<em>\1</em>", s)
    s = re.sub(r"\x00(\d+)\x00", lambda m: f"<code>{codes[int(m.group(1))]}</code>", s)
    return s


_LIST = re.compile(r"^(\s*)([-*]|\d+[.)])\s+(.*)$")


def _render_list(lines, i):
    """Renderiza uma lista a partir de lines[i]; retorna (html, próximo índice)."""
    m = _LIST.match(lines[i])
    base = len(m.group(1))
    ordered = m.group(2)[0].isdigit()
    tag = "ol" if ordered else "ul"
    items = []
    while i < len(lines):
        m = _LIST.match(lines[i])
        if not m:
            if lines[i].strip() == "":
                # lista continua se a próxima linha não vazia for item no mesmo nível
                j = i + 1
                while j < len(lines) and lines[j].strip() == "":
                    j += 1
                if j < len(lines) and _LIST.match(lines[j]) and len(_LIST.match(lines[j]).group(1)) >= base:
                    i = j
                    continue
                break
            if lines[i].startswith(" " * (base + 2)) and items:
                items[-1][1].append(lines[i].strip())
                i += 1
                continue
            break
        indent = len(m.group(1))
        if indent < base:
            break
        if indent > base and items:
            sub, i = _render_list(lines, i)
            items[-1][2].append(sub)
            continue
        items.append([m.group(3), [], []])
        i += 1
    out = [f'<{tag} class="md-list">']
    for text, extra, subs in items:
        body = inline(" ".join([text] + extra))
        out.append(f"<li>{body}{''.join(subs)}</li>")
    out.append(f"</{tag}>")
    return "".join(out), i


def _table(rows):
    def cells(r):
        r = r.strip()
        if r.startswith("|"):
            r = r[1:]
        if r.endswith("|") and not r.endswith("\\|"):
            r = r[:-1]
        # "\|" representa uma barra vertical literal dentro da célula
        parts = re.split(r"(?<!\\)\|", r)
        return [c.strip().replace("\\|", "|") for c in parts]

    head = cells(rows[0])
    body = [cells(r) for r in rows[2:]]
    h = "".join(f'<th scope="col">{inline(c)}</th>' for c in head)
    b = "".join("<tr>" + "".join(f"<td>{inline(c)}</td>" for c in r) + "</tr>" for r in body)
    return f'<div class="table-wrap" tabindex="0"><table class="md-table"><thead><tr>{h}</tr></thead><tbody>{b}</tbody></table></div>'


def render(text):
    lines = (text or "").replace("\r\n", "\n").split("\n")
    out = []
    i = 0
    para = []

    def flush():
        if para:
            out.append(f"<p>{inline(' '.join(para))}</p>")
            para.clear()

    while i < len(lines):
        line = lines[i]
        s = line.strip()
        if s.startswith("```"):
            flush()
            lang = html.escape(s[3:].strip() or "código")
            buf = []
            i += 1
            while i < len(lines) and not lines[i].strip().startswith("```"):
                buf.append(lines[i])
                i += 1
            i += 1
            code = html.escape("\n".join(buf))
            out.append(
                f'<figure class="code"><div class="code-head"><span>{lang}</span>'
                f'<button type="button" class="code-copy" data-copy>Copiar</button></div>'
                f"<pre><code>{code}</code></pre></figure>"
            )
            continue
        if s.startswith(":::detalhes"):
            flush()
            title = s[len(":::detalhes"):].strip() or "Mais detalhes"
            buf = []
            i += 1
            depth = 1
            while i < len(lines):
                t = lines[i].strip()
                if t.startswith(":::detalhes"):
                    depth += 1
                elif t == ":::":
                    depth -= 1
                    if depth == 0:
                        break
                buf.append(lines[i])
                i += 1
            i += 1
            out.append(
                f'<details class="md-details"><summary>{inline(title)}</summary>'
                f'<div class="md-details-body">{render(chr(10).join(buf))}</div></details>'
            )
            continue
        if s == "":
            flush()
            i += 1
            continue
        if re.match(r"^-{3,}$", s):
            flush()
            out.append("<hr>")
            i += 1
            continue
        m = re.match(r"^(#{1,4})\s+(.*)$", s)
        if m:
            flush()
            lvl = min(len(m.group(1)) + 1, 5)  # # vira h2 (o h1 é o título da aula)
            out.append(f"<h{lvl}>{inline(m.group(2))}</h{lvl}>")
            i += 1
            continue
        if s.startswith(">"):
            flush()
            buf = []
            while i < len(lines) and lines[i].strip().startswith(">"):
                buf.append(lines[i].strip()[1:].strip())
                i += 1
            kind, label = "info", None
            m = re.match(r"^\[!(\w+)\]\s*(.*)$", buf[0]) if buf else None
            if m and m.group(1).upper() in CALLOUTS:
                kind, label = CALLOUTS[m.group(1).upper()]
                buf[0] = m.group(2)
            body = render("\n".join(buf).strip())
            title = f'<p class="callout-title">{label}</p>' if label else ""
            out.append(f'<div class="callout callout-{kind}" role="note">{title}{body}</div>')
            continue
        if s.startswith("|") and i + 1 < len(lines) and re.match(r"^\|?\s*:?-{2,}", lines[i + 1].strip()):
            flush()
            rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                rows.append(lines[i])
                i += 1
            out.append(_table(rows))
            continue
        if _LIST.match(line):
            flush()
            h, i = _render_list(lines, i)
            out.append(h)
            continue
        para.append(s)
        i += 1
    flush()
    return Markup("\n".join(out))


def plain(text, limit=None):
    """Texto puro para buscas e resumos."""
    t = re.sub(r"```.*?```", " ", text or "", flags=re.S)
    t = re.sub(r"[#>*`|\[\]!]|:::detalhes|:::|\(\S+?\)", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    if limit and len(t) > limit:
        t = t[: limit - 1].rsplit(" ", 1)[0] + "…"
    return t
