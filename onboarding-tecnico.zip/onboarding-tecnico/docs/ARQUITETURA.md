# Arquitetura, banco de dados e regras de negócio

## Visão geral

```
navegador ──HTTPS──> proxy (Nginx/Caddy) ──> gunicorn ──> Flask (app/)
                                                   │
                                                   ├── SQLite (instance/onboarding.db, WAL)
                                                   └── uploads (instance/uploads, nomes aleatórios)
```

- **Renderização no servidor.** Cada página é montada no servidor com os dados que o usuário autenticado pode
  ver. Nenhuma regra de permissão ou de cálculo de progresso fica no navegador. O JavaScript (`app/static/js/app.js`)
  cuida apenas de menu, confirmações, cópia de código, contadores e estados de carregamento.
- **Camadas:**
  - `app/blueprints/`: rotas HTTP. `auth` (login), `learner` (área do colaborador), `account` (conta), `files`
    (arquivos protegidos), `admin` (acompanhamento, usuários, correções, relatórios e auditoria) e `admin_content`
    (trilhas, módulos, aulas, materiais, atividades e questões).
  - `app/services/`: regras de negócio. `progress` (fonte única do cálculo de progresso e situação), `grading`
    (tentativas e correção), `access` (liberação de conteúdo) e `reports` (consultas sempre limitadas ao escopo do
    usuário).
  - `app/security.py`: sessão, CSRF, decorators de perfil, regra de visibilidade (`can_view_user`), cabeçalhos de
    segurança, auditoria e eventos.
  - `app/markdown.py`: renderizador Markdown seguro. Todo HTML digitado é escapado e só URLs `http(s)` ou relativas
    são aceitas.
  - `migrations/*.sql`: esquema versionado, aplicado automaticamente na inicialização ou com `flask db-migrate`.

## Segurança

| Tema | Implementação |
| --- | --- |
| Senhas | `scrypt` (werkzeug), mínimo de 10 caracteres com letras e números ou símbolos, senha temporária com troca obrigatória. |
| Sessão | Cookie assinado, `HttpOnly`, `SameSite=Lax` e `Secure` em produção. Guarda `session_version`, incrementado ao trocar a senha, desativar ou redefinir, o que derruba as sessões antigas. |
| Força bruta | Bloqueio por 15 min após 5 falhas e tempo de resposta equalizado para e-mail inexistente. |
| CSRF | Token por sessão exigido em todo `POST`. |
| Autorização | Decorators `login_required`, `staff_required` e `admin_required`, mais a checagem por objeto `can_view_user`. O gestor só acessa colaboradores com `manager_id` igual ao seu, e ninguém corrige a própria tentativa. |
| Arquivos | Extensões permitidas, nome aleatório no disco e entrega pela rota `files`, que aplica a mesma regra da aula (atribuída, ativa e liberada). Evidências só para o dono, o gestor dele ou o admin. |
| Cabeçalhos | CSP sem scripts inline nem de terceiros, `X-Frame-Options: DENY`, `nosniff`, `Referrer-Policy`, HSTS em produção e `Cache-Control: no-store` em páginas autenticadas. |
| CSV | Prefixo `'` para impedir fórmulas e exportações registradas na auditoria. |
| Segredos | Somente em variáveis de ambiente. Nada sensível é enviado ao navegador. |

## Banco de dados

| Tabela | Conteúdo |
| --- | --- |
| `users` | Conta, perfil (`admin`/`manager`/`collaborator`), gestor responsável, data de início, situação, bloqueio, `session_version`, `is_demo` e última atividade. |
| `tracks` | Trilha: título, descrição, `status` (`draft`/`published`/`archived`) e prazo esperado em dias. |
| `track_assignments` | Atribuição de trilha a usuário e data de conclusão da trilha. |
| `modules` | Módulos da trilha: ordem, objetivos (um por linha), tempo estimado e `active`. |
| `module_prerequisites` | Pré-requisitos entre módulos (sem ciclos, validado na edição). |
| `lessons` | Aula: conteúdo Markdown, vídeo, ordem, obrigatoriedade, regra de conclusão (`confirm`/`activity`), tempo mínimo e `active`. |
| `materials` | Materiais de apoio: arquivo protegido ou link. |
| `activities` | Atividade: tipo, nota mínima, tentativas, regra de gabarito, obrigatoriedade, publicação, `active` e **`version`**. |
| `questions` / `question_options` | Questões (uma escolha, várias escolhas, V/F ou aberta), pontos, explicação e alternativas com gabarito. |
| `attempts` | Uma linha por tentativa: usuário, atividade, nº, versão, status (`in_progress`/`pending_review`/`graded`), datas, pontos, %, critério vigente (`pass_percent`), aprovação, acertos/erros, evidência, corretor e feedback. |
| `attempt_answers` | Resposta por questão, com **snapshot** do enunciado e do gabarito, alternativas marcadas, texto, acerto, pontos e comentário. |
| `lesson_progress` | Primeiro e último acesso, nº de acessos e `completed_at` (acesso ≠ conclusão). |
| `events` | Linha do tempo do colaborador (acessos, conclusões, envios e resultados). |
| `audit_log` | Ações administrativas. |
| `schema_migrations` | Migrações aplicadas. |

## Regras de negócio

1. **Progresso individual.** É sempre calculado no servidor a partir de `lesson_progress` e `attempts` do usuário
   autenticado (`services/progress.py`), com o mesmo resultado em qualquer dispositivo.
2. **Percentual.** É igual a etapas obrigatórias concluídas ÷ etapas obrigatórias. Contam as aulas obrigatórias e as
   atividades obrigatórias, ativas e publicadas, de módulos ativos.
3. **Conclusão de aula.** Na regra `confirm`, a aula conclui quando o colaborador confirma a leitura, depois de abri-la
   e, se houver, cumprir o tempo mínimo. Na regra `activity`, conclui quando uma atividade vinculada é aprovada. Abrir
   a aula só registra o acesso.
4. **Aprovação.** Exige uma tentativa corrigida com nota maior ou igual ao mínimo **vigente no envio**.
5. **Questões abertas, estudos de caso, simulações e práticas** ficam `pending_review` e **não** contam como
   aprovadas até a correção manual.
6. **Tentativas.** Só contam as enviadas. Um rascunho pode ser salvo e retomado. Não é possível abrir nova tentativa
   depois de aprovado nem enquanto há outra aguardando correção.
7. **Edição de atividade já respondida.** Alterar questões, alternativas, pontos, nota mínima ou número de
   tentativas incrementa `activities.version`. Tentativas enviadas mantêm snapshot, nota e aprovação, sem recálculo
   retroativo. Aprovação obtida em versão anterior continua valendo. Rascunhos de versão anterior são descartados sem
   consumir tentativa, e o colaborador é avisado. O tipo da atividade não pode mudar depois de haver respostas.
8. **Conteúdo com histórico** não pode ser excluído, só desativado. Desativado, sai do cálculo e da navegação, e o
   histórico continua guardado. Trilha em rascunho ou arquivada some para o colaborador sem perder o progresso.
9. **Usuário desativado** perde o acesso na hora (sessões revogadas) e continua nos relatórios com o filtro
   “incluir desativados”.
10. **Conclusão da trilha.** É registrada em `track_assignments.completed_at` e removida se novo conteúdo obrigatório
    for publicado depois.
11. **Classificação para o gestor** (`classify`):
    - *Concluiu*: 100%.
    - *Não iniciou*: nenhum acesso nem tentativa.
    - *Aguardando correção*: há tentativas pendentes.
    - *Abaixo da nota mínima*: alguma atividade obrigatória reprovada e não recuperada.
    - *Precisa de acompanhamento*: progresso mais de `PACE_TOLERANCE_POINTS` pontos abaixo do ritmo esperado (dias
      desde o início ÷ prazo da trilha), `INACTIVITY_ALERT_DAYS` dias ou mais sem atividade, ou tentativas esgotadas
      sem aprovação.
    - *Progredindo normalmente*: os demais.

## PostgreSQL

O acesso a dados usa SQL padrão por meio de `app/db.py`. Para migrar para PostgreSQL, que **não foi implementado nem
testado**:
1. Adicionar o driver `psycopg` e adaptar `connect()`, os placeholders `?` → `%s` e `lastrowid` → `RETURNING id`.
2. Traduzir `migrations/0001_initial.sql`: `INTEGER PRIMARY KEY AUTOINCREMENT` → `BIGSERIAL`, `COLLATE NOCASE` →
   `CITEXT` ou índice em `lower(email)`, e datas `TEXT` → `TIMESTAMPTZ`.
3. Substituir `json_extract` (relatório de questões) por `question_snapshot::jsonb ->> 'prompt'`, e `INSERT OR IGNORE`
   por `ON CONFLICT DO NOTHING`.
4. Rodar a suíte de testes contra o novo banco.
