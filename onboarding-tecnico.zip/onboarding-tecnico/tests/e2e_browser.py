"""Fluxos completos no navegador (Playwright). Requer o servidor rodando com os dados de demonstração:

    flask --app wsgi seed-demo && flask --app wsgi run --port 5055
    python tests/e2e_browser.py [http://127.0.0.1:5055] [pasta_screenshots]
"""
import sys
from pathlib import Path

from playwright.sync_api import sync_playwright

B = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:5055"
OUT = Path(sys.argv[2] if len(sys.argv) > 2 else "e2e_shots")
OUT.mkdir(parents=True, exist_ok=True)
DEMO = "Demo2026onboarding"


def login(pg, e, p):
    pg.goto(B + "/login")
    pg.fill("#email", e)
    pg.fill("#password", p)
    pg.click("button[type=submit]")
    pg.wait_for_load_state()


def check(cond, msg):
    print(("OK   " if cond else "FAIL ") + msg)
    if not cond:
        check.failed = True


check.failed = False

with sync_playwright() as p:
    b = p.chromium.launch()
    errs = []

    # 1. Colaboradora no celular: menu, aula, rascunho, envio com confirmação
    pg = b.new_page(viewport={"width": 390, "height": 844})
    pg.on("console", lambda m: errs.append(m.text) if m.type == "error" else None)
    login(pg, "elisa.demo@exemplo.com", DEMO)
    pg.click("#navToggle")
    check(pg.locator(".app.nav-open").count() == 1, "menu lateral abre no celular")
    pg.click(".sidebar >> text=Minha trilha")
    pg.wait_for_load_state()
    pg.click("text=Continuar módulo")
    pg.wait_for_load_state()
    pg.click("text=Servidores e portas")
    pg.wait_for_load_state()
    pg.click("button:has-text('Concluir e ir para a próxima')")
    pg.wait_for_load_state()
    check("Aula concluída" in pg.content(), "aula concluída por confirmação")
    pg.screenshot(path=str(OUT / "lesson_mobile.png"))
    pg.goto(B + "/atividades")
    pg.click("text=Checagem: Fundamentos")
    pg.wait_for_load_state()
    pg.click("button:has-text('Começar atividade')")
    pg.wait_for_load_state()
    qs = pg.locator(".question")
    for i in range(qs.count()):
        qs.nth(i).locator("label.opt").nth(1).click()
    pg.click("button:has-text('Salvar rascunho')")
    pg.wait_for_load_state()
    check("Rascunho salvo" in pg.content(), "rascunho salvo")
    pg.click("button:has-text('Enviar respostas')")
    pg.wait_for_selector("dialog[open]")
    pg.screenshot(path=str(OUT / "confirm_mobile.png"))
    pg.click("#confirmOk")
    pg.wait_for_load_state()
    pg.wait_for_timeout(400)
    txt = pg.content()
    check("Aprovado" in txt or "Não foi desta vez" in txt, "questionário corrigido automaticamente")
    pg.screenshot(path=str(OUT / "result_mobile.png"), full_page=True)

    # 2. Gestora corrige a resposta aberta da Carla
    pg2 = b.new_page(viewport={"width": 1366, "height": 900})
    pg2.on("console", lambda m: errs.append(m.text) if m.type == "error" else None)
    login(pg2, "gestora.demo@exemplo.com", DEMO)
    pg2.goto(B + "/admin/correcoes")
    pg2.locator("tr:has-text('Carla')").locator("text=Corrigir").first.click()
    pg2.wait_for_load_state()
    for inp in pg2.locator("input[name^=pts_]").all():
        inp.fill("4")
    pg2.fill("#feedback", "Boa estrutura; detalhe mais a ordem dos testes.")
    pg2.click("button:has-text('Registrar correção')")
    pg2.wait_for_selector("dialog[open]")
    pg2.click("#confirmOk")
    pg2.wait_for_load_state()
    check("Correção registrada" in pg2.content(), "correção manual registrada")

    # 3. Gestora cadastra colaborador; primeiro acesso exige troca de senha
    pg2.goto(B + "/admin/usuarios/novo")
    pg2.fill("#name", "Fábio Teste")
    pg2.fill("#email", "fabio.teste@exemplo.com")
    pg2.check("input[name=tracks]")
    pg2.click("button:has-text('Cadastrar e gerar senha')")
    pg2.wait_for_load_state()
    temp = pg2.locator(".temp-pass").inner_text().strip()
    check(len(temp) == 12, "senha temporária gerada")
    pg3 = b.new_page()
    login(pg3, "fabio.teste@exemplo.com", temp)
    check("/conta/senha" in pg3.url, "primeiro acesso redireciona para troca de senha")
    pg3.fill("#current", temp)
    pg3.fill("#new", "MinhaSenha2026")
    pg3.fill("#confirm", "MinhaSenha2026")
    pg3.click("main button[type=submit]")
    pg3.wait_for_load_state()
    pg3.goto(B + "/")
    check("Boas-vindas" in pg3.content(), "novo colaborador vê o dashboard com a trilha")

    check(not errs, "sem erros no console do navegador " + (str(errs[:3]) if errs else ""))
    b.close()

sys.exit(1 if check.failed else 0)
