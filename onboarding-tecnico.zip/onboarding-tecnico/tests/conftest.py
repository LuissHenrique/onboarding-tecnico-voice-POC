import re
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app import create_app  # noqa: E402
from app.db import connect  # noqa: E402
from app.security import hash_password  # noqa: E402

PW = "SenhaForte123"


@pytest.fixture()
def app(tmp_path):
    app = create_app({"DATABASE_PATH": str(tmp_path / "t.db"), "UPLOAD_DIR": str(tmp_path / "up"),
                      "SECRET_KEY": "test", "TESTING": True})
    app.db_path = str(tmp_path / "t.db")
    return app


class World:
    """Cria usuários e uma trilha mínima direto no banco."""

    def __init__(self, app):
        self.conn = connect(app.db_path)
        self.ts = "2026-10-01T12:00:00+00:00"

    def x(self, sql, p=()):
        cur = self.conn.execute(sql, p)
        return cur.lastrowid

    def one(self, sql, p=()):
        return self.conn.execute(sql, p).fetchone()

    def user(self, email, role="collaborator", manager_id=None, active=1, start="2026-10-01"):
        return self.x("INSERT INTO users(name,email,password_hash,role,active,manager_id,start_date,created_at,updated_at) "
                      "VALUES (?,?,?,?,?,?,?,?,?)", (email.split("@")[0].title() + " Teste", email, hash_password(PW),
                                                     role, active, manager_id, start, self.ts, self.ts))

    def track(self, status="published"):
        t = self.ts
        tid = self.x("INSERT INTO tracks(title,description,status,expected_days,created_at,updated_at) VALUES (?,?,?,?,?,?)",
                     ("Trilha Teste", "", status, 30, t, t))
        ma = self.x("INSERT INTO modules(track_id,title,position,created_at,updated_at) VALUES (?,?,?,?,?)", (tid, "Módulo A", 0, t, t))
        mb = self.x("INSERT INTO modules(track_id,title,position,created_at,updated_at) VALUES (?,?,?,?,?)", (tid, "Módulo B", 1, t, t))
        self.x("INSERT INTO module_prerequisites(module_id,requires_module_id) VALUES (?,?)", (mb, ma))
        la = self.x("INSERT INTO lessons(module_id,title,body,position,created_at,updated_at) VALUES (?,?,?,?,?,?)",
                    (ma, "Aula A1", "Texto **A1**", 0, t, t))
        lb = self.x("INSERT INTO lessons(module_id,title,body,position,created_at,updated_at) VALUES (?,?,?,?,?,?)",
                    (mb, "Aula B1", "Texto B1", 0, t, t))
        quiz = self.x("INSERT INTO activities(module_id,title,kind,pass_percent,max_attempts,feedback_mode,position,created_at,updated_at) "
                      "VALUES (?,?,?,?,?,?,?,?,?)", (ma, "Quiz A", "quiz", 50, 2, "immediate", 0, t, t))
        q1 = self.x("INSERT INTO questions(activity_id,qtype,prompt,points,position,created_at,updated_at) VALUES (?,?,?,?,?,?,?)",
                    (quiz, "single", "Porta padrão?", 1, 0, t, t))
        o_ok = self.x("INSERT INTO question_options(question_id,text,is_correct,position) VALUES (?,?,1,0)", (q1, "7048"))
        o_bad = self.x("INSERT INTO question_options(question_id,text,is_correct,position) VALUES (?,?,0,1)", (q1, "5060"))
        q2 = self.x("INSERT INTO questions(activity_id,qtype,prompt,points,position,created_at,updated_at) VALUES (?,?,?,?,?,?,?)",
                    (quiz, "truefalse", "Desvios só valem Online?", 1, 1, t, t))
        o2_ok = self.x("INSERT INTO question_options(question_id,text,is_correct,position) VALUES (?,?,1,0)", (q2, "Verdadeiro"))
        o2_bad = self.x("INSERT INTO question_options(question_id,text,is_correct,position) VALUES (?,?,0,1)", (q2, "Falso"))
        opn = self.x("INSERT INTO activities(module_id,title,kind,pass_percent,max_attempts,feedback_mode,position,created_at,updated_at) "
                     "VALUES (?,?,?,?,?,?,?,?,?)", (mb, "Caso B", "case", 70, 2, "immediate", 0, t, t))
        q3 = self.x("INSERT INTO questions(activity_id,qtype,prompt,points,position,created_at,updated_at) VALUES (?,?,?,?,?,?,?)",
                    (opn, "open", "Explique o diagnóstico.", 10, 0, t, t))
        return dict(track=tid, ma=ma, mb=mb, la=la, lb=lb, quiz=quiz, q1=q1, q2=q2, o_ok=o_ok, o_bad=o_bad,
                    o2_ok=o2_ok, o2_bad=o2_bad, open=opn, q3=q3)

    def assign(self, track_id, user_id):
        self.x("INSERT INTO track_assignments(track_id,user_id,assigned_at) VALUES (?,?,?)", (track_id, user_id, self.ts))


@pytest.fixture()
def world(app):
    w = World(app)
    yield w
    w.conn.close()


def csrf(client, url="/login"):
    r = client.get(url)
    m = re.search(r'name="csrf_token" value="([^"]+)"', r.get_data(as_text=True))
    return m.group(1)


def login(client, email, pw=PW):
    tok = csrf(client)
    return client.post("/login", data={"csrf_token": tok, "email": email, "password": pw})


def post(client, url, data=None, page="/"):
    data = dict(data or {})
    with client.session_transaction() as s:
        data["csrf_token"] = s.get("csrf")
    return client.post(url, data=data)
