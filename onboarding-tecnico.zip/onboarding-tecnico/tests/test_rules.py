"""Testes das principais regras de negócio, permissões e fluxos."""
import re

from conftest import PW, login, post


def _attempt_id(resp):
    return int(re.search(r"/tentativas/(\d+)", resp.headers["Location"]).group(1))


def _answer_ids(world, attempt_id):
    rows = world.conn.execute("SELECT id, question_id FROM attempt_answers WHERE attempt_id = ?", (attempt_id,)).fetchall()
    return {r["question_id"]: r["id"] for r in rows}


def _percent(app, uid, tid):
    from app.services.progress import user_track_state
    with app.app_context():
        return user_track_state(uid, tid)


# ------------------------------------------------------------------ autenticação
def test_login_lockout_after_failures(app, world):
    world.user("ana@x.com")
    c = app.test_client()
    for _ in range(5):
        assert login(c, "ana@x.com", "errada123456").status_code == 401
    r = login(c, "ana@x.com")  # senha certa, mas bloqueado
    assert r.status_code == 401 and "bloqueado" in r.get_data(as_text=True)


def test_deactivated_user_loses_access(app, world):
    admin = world.user("adm@x.com", "admin")
    uid = world.user("bia@x.com")
    c = app.test_client()
    assert login(c, "bia@x.com").status_code == 302
    assert c.get("/").status_code == 200
    a = app.test_client()
    login(a, "adm@x.com")
    assert post(a, f"/admin/usuarios/{uid}/situacao").status_code == 302
    assert c.get("/").status_code == 302  # sessão revogada
    assert login(app.test_client(), "bia@x.com").status_code == 401


def test_csrf_required(app, world):
    world.user("ana@x.com")
    c = app.test_client()
    login(c, "ana@x.com")
    assert c.post("/logout").status_code == 400


def test_must_change_password_redirects(app, world):
    uid = world.user("ana@x.com")
    world.x("UPDATE users SET must_change_password = 1 WHERE id = ?", (uid,))
    c = app.test_client()
    login(c, "ana@x.com")
    r = c.get("/trilha")
    assert r.status_code == 302 and "/conta/senha" in r.headers["Location"]
    r = post(c, "/conta/senha", {"current": PW, "new": "NovaSenha2026x", "confirm": "NovaSenha2026x"})
    assert r.status_code == 302
    assert c.get("/trilha").status_code == 200


# ------------------------------------------------------------------ permissões
def test_collaborator_blocked_from_admin(app, world):
    world.user("ana@x.com")
    c = app.test_client()
    login(c, "ana@x.com")
    for url in ["/admin/", "/admin/usuarios", "/admin/relatorios", "/admin/conteudo/", "/admin/relatorios/colaboradores.csv"]:
        assert c.get(url).status_code == 403, url
    assert post(c, "/admin/conteudo/trilhas/nova", {"title": "X", "expected_days": 5}).status_code == 403


def test_manager_sees_only_own_team(app, world):
    m1 = world.user("g1@x.com", "manager")
    m2 = world.user("g2@x.com", "manager")
    mine = world.user("meu@x.com", manager_id=m1)
    other = world.user("outro@x.com", manager_id=m2)
    t = world.track()
    world.assign(t["track"], mine)
    world.assign(t["track"], other)
    c = app.test_client()
    login(c, "g1@x.com")
    assert c.get(f"/admin/colaboradores/{mine}").status_code == 200
    assert c.get(f"/admin/colaboradores/{other}").status_code == 403
    csv = c.get("/admin/relatorios/colaboradores.csv").get_data(as_text=True)
    assert "meu@x.com" in csv and "outro@x.com" not in csv
    assert c.get(f"/admin/usuarios/{other}/editar").status_code == 403
    # gestor não consegue criar administrador
    r = post(c, "/admin/usuarios/novo", {"name": "Novo Usuario", "email": "novo@x.com", "role": "admin"})
    assert r.status_code == 200
    row = world.one("SELECT role, manager_id FROM users WHERE email = 'novo@x.com'")
    assert row["role"] == "collaborator" and row["manager_id"] == m1


def test_collaborator_cannot_see_others_attempts(app, world):
    a = world.user("a@x.com")
    b = world.user("b@x.com")
    t = world.track()
    world.assign(t["track"], a)
    world.assign(t["track"], b)
    ca = app.test_client()
    login(ca, "a@x.com")
    att = _attempt_id(post(ca, f"/atividades/{t['quiz']}/iniciar"))
    cb = app.test_client()
    login(cb, "b@x.com")
    assert cb.get(f"/tentativas/{att}").status_code == 404
    assert cb.get(f"/admin/tentativas/{att}").status_code == 403


# ------------------------------------------------------------------ trilha e progresso
def test_view_is_not_completion_and_confirm_completes(app, world):
    uid = world.user("ana@x.com")
    t = world.track()
    world.assign(t["track"], uid)
    c = app.test_client()
    login(c, "ana@x.com")
    assert c.get(f"/aulas/{t['la']}").status_code == 200
    st = _percent(app, uid, t["track"])
    assert st["required_done"] == 0 and st["by_id"][t["ma"]]["status"] == "in_progress"
    post(c, f"/aulas/{t['la']}/concluir", {"go": "stay"})
    st = _percent(app, uid, t["track"])
    assert st["required_done"] == 1 and st["required_total"] == 4 and st["percent"] == 25


def test_prerequisite_locks_until_completed(app, world):
    uid = world.user("ana@x.com")
    t = world.track()
    world.assign(t["track"], uid)
    c = app.test_client()
    login(c, "ana@x.com")
    assert c.get(f"/aulas/{t['lb']}").status_code == 423
    assert c.get(f"/atividades/{t['open']}").status_code == 423
    c.get(f"/aulas/{t['la']}")
    post(c, f"/aulas/{t['la']}/concluir")
    att = _attempt_id(post(c, f"/atividades/{t['quiz']}/iniciar"))
    ans = _answer_ids(world, att)
    post(c, f"/tentativas/{att}", {"action": "submit", f"q_{ans[t['q1']]}": t["o_ok"], f"q_{ans[t['q2']]}": t["o2_ok"]})
    assert c.get(f"/aulas/{t['lb']}").status_code == 200


def test_draft_track_hidden_from_collaborator(app, world):
    uid = world.user("ana@x.com")
    t = world.track(status="draft")
    world.assign(t["track"], uid)
    c = app.test_client()
    login(c, "ana@x.com")
    assert c.get(f"/aulas/{t['la']}").status_code == 404
    assert "Nenhuma trilha" in c.get("/trilha").get_data(as_text=True)


# ------------------------------------------------------------------ avaliações
def test_quiz_autograde_and_attempt_limit(app, world):
    uid = world.user("ana@x.com")
    t = world.track()
    world.assign(t["track"], uid)
    c = app.test_client()
    login(c, "ana@x.com")
    # tentativa 1: 0%
    att = _attempt_id(post(c, f"/atividades/{t['quiz']}/iniciar"))
    ans = _answer_ids(world, att)
    post(c, f"/tentativas/{att}", {"action": "submit", f"q_{ans[t['q1']]}": t["o_bad"], f"q_{ans[t['q2']]}": t["o2_bad"]})
    r = world.one("SELECT * FROM attempts WHERE id = ?", (att,))
    assert r["status"] == "graded" and r["passed"] == 0 and r["percent"] == 0 and r["wrong_count"] == 2
    # tentativa 2: 50% (mínimo 50) -> aprovado
    att2 = _attempt_id(post(c, f"/atividades/{t['quiz']}/iniciar"))
    ans = _answer_ids(world, att2)
    post(c, f"/tentativas/{att2}", {"action": "submit", f"q_{ans[t['q1']]}": t["o_ok"], f"q_{ans[t['q2']]}": t["o2_bad"]})
    r2 = world.one("SELECT * FROM attempts WHERE id = ?", (att2,))
    assert r2["passed"] == 1 and r2["percent"] == 50 and r2["correct_count"] == 1
    # aprovado: não abre nova tentativa; histórico preservado
    assert post(c, f"/atividades/{t['quiz']}/iniciar").headers["Location"].endswith(f"/atividades/{t['quiz']}")
    assert world.one("SELECT COUNT(*) FROM attempts WHERE user_id = ?", (uid,))[0] == 2


def test_attempts_exhausted(app, world):
    uid = world.user("ana@x.com")
    t = world.track()
    world.assign(t["track"], uid)
    c = app.test_client()
    login(c, "ana@x.com")
    for _ in range(2):
        att = _attempt_id(post(c, f"/atividades/{t['quiz']}/iniciar"))
        ans = _answer_ids(world, att)
        post(c, f"/tentativas/{att}", {"action": "submit", f"q_{ans[t['q1']]}": t["o_bad"], f"q_{ans[t['q2']]}": t["o2_bad"]})
    r = post(c, f"/atividades/{t['quiz']}/iniciar")
    assert "/tentativas/" not in r.headers["Location"]
    assert world.one("SELECT COUNT(*) FROM attempts WHERE user_id = ?", (uid,))[0] == 2


def test_submit_requires_all_answers_and_keeps_draft(app, world):
    uid = world.user("ana@x.com")
    t = world.track()
    world.assign(t["track"], uid)
    c = app.test_client()
    login(c, "ana@x.com")
    att = _attempt_id(post(c, f"/atividades/{t['quiz']}/iniciar"))
    ans = _answer_ids(world, att)
    post(c, f"/tentativas/{att}", {"action": "submit", f"q_{ans[t['q1']]}": t["o_ok"]})
    r = world.one("SELECT status FROM attempts WHERE id = ?", (att,))
    assert r["status"] == "in_progress"
    saved = world.one("SELECT selected_options FROM attempt_answers WHERE id = ?", (ans[t["q1"]],))
    assert str(t["o_ok"]) in saved[0]


def test_open_answer_needs_manual_grading(app, world):
    mgr = world.user("g@x.com", "manager")
    uid = world.user("ana@x.com", manager_id=mgr)
    t = world.track()
    world.assign(t["track"], uid)
    world.x("DELETE FROM module_prerequisites")
    c = app.test_client()
    login(c, "ana@x.com")
    att = _attempt_id(post(c, f"/atividades/{t['open']}/iniciar"))
    ans = _answer_ids(world, att)
    post(c, f"/tentativas/{att}", {"action": "submit", f"q_{ans[t['q3']]}": "Verifico NAT e SIP ALG."})
    r = world.one("SELECT * FROM attempts WHERE id = ?", (att,))
    assert r["status"] == "pending_review" and r["passed"] is None
    st = _percent(app, uid, t["track"])
    assert not st["by_id"][t["mb"]]["activities"][0]["state"]["passed"]
    g = app.test_client()
    login(g, "g@x.com")
    assert t["open"] and "Corrigir" in g.get("/admin/correcoes").get_data(as_text=True)
    # pontos fora da faixa são recusados
    post(g, f"/admin/tentativas/{att}/corrigir", {f"pts_{ans[t['q3']]}": "11", "feedback": "x"})
    assert world.one("SELECT status FROM attempts WHERE id = ?", (att,))[0] == "pending_review"
    post(g, f"/admin/tentativas/{att}/corrigir", {f"pts_{ans[t['q3']]}": "8", f"cmt_{ans[t['q3']]}": "Bom", "feedback": "Ok"})
    r = world.one("SELECT * FROM attempts WHERE id = ?", (att,))
    assert r["status"] == "graded" and r["passed"] == 1 and r["percent"] == 80 and r["graded_by"] == mgr
    assert _percent(app, uid, t["track"])["by_id"][t["mb"]]["activities"][0]["state"]["passed"]


def test_edit_activity_creates_version_and_preserves_history(app, world):
    world.user("adm@x.com", "admin")
    uid = world.user("ana@x.com")
    t = world.track()
    world.assign(t["track"], uid)
    c = app.test_client()
    login(c, "ana@x.com")
    att = _attempt_id(post(c, f"/atividades/{t['quiz']}/iniciar"))
    ans = _answer_ids(world, att)
    post(c, f"/tentativas/{att}", {"action": "submit", f"q_{ans[t['q1']]}": t["o_ok"], f"q_{ans[t['q2']]}": t["o2_bad"]})
    assert world.one("SELECT passed FROM attempts WHERE id = ?", (att,))[0] == 1
    a = app.test_client()
    login(a, "adm@x.com")
    r = post(a, f"/admin/conteudo/atividades/{t['quiz']}/editar",
             {"title": "Quiz A", "kind": "quiz", "pass_percent": "90", "max_attempts": "2", "feedback_mode": "immediate",
              "required": "1", "published": "1"})
    assert r.status_code == 302
    assert world.one("SELECT version FROM activities WHERE id = ?", (t["quiz"],))[0] == 2
    old = world.one("SELECT * FROM attempts WHERE id = ?", (att,))
    assert old["passed"] == 1 and old["percent"] == 50 and old["pass_percent"] == 50 and old["activity_version"] == 1
    assert _percent(app, uid, t["track"])["by_id"][t["ma"]]["activities"][0]["state"]["passed"]


def test_inactive_content_excluded_and_history_protected(app, world):
    world.user("adm@x.com", "admin")
    uid = world.user("ana@x.com")
    t = world.track()
    world.assign(t["track"], uid)
    c = app.test_client()
    login(c, "ana@x.com")
    c.get(f"/aulas/{t['la']}")
    a = app.test_client()
    login(a, "adm@x.com")
    post(a, f"/admin/conteudo/aulas/{t['la']}/excluir")
    assert world.one("SELECT COUNT(*) FROM lessons WHERE id = ?", (t["la"],))[0] == 1  # tem histórico
    post(a, f"/admin/conteudo/aulas/{t['la']}/situacao")
    st = _percent(app, uid, t["track"])
    assert st["required_total"] == 3
    assert c.get(f"/aulas/{t['la']}").status_code == 404 or c.get(f"/aulas/{t['la']}").status_code == 410
    assert world.one("SELECT COUNT(*) FROM lesson_progress WHERE lesson_id = ?", (t["la"],))[0] == 1


def test_progress_persists_across_sessions(app, world):
    uid = world.user("ana@x.com")
    t = world.track()
    world.assign(t["track"], uid)
    c = app.test_client()
    login(c, "ana@x.com")
    c.get(f"/aulas/{t['la']}")
    post(c, f"/aulas/{t['la']}/concluir")
    post(c, "/logout")
    other_device = app.test_client()
    login(other_device, "ana@x.com")
    html = other_device.get("/trilha").get_data(as_text=True)
    assert "1 de 4 etapas obrigatórias" in html


def test_publish_blocked_when_invalid(app, world):
    world.user("adm@x.com", "admin")
    t = world.track(status="draft")
    world.x("UPDATE question_options SET is_correct = 0 WHERE question_id = ?", (t["q1"],))
    a = app.test_client()
    login(a, "adm@x.com")
    post(a, f"/admin/conteudo/trilhas/{t['track']}/status", {"status": "published"})
    assert world.one("SELECT status FROM tracks WHERE id = ?", (t["track"],))[0] == "draft"
    world.x("UPDATE question_options SET is_correct = 1 WHERE id = ?", (t["o_ok"],))
    post(a, f"/admin/conteudo/trilhas/{t['track']}/status", {"status": "published"})
    assert world.one("SELECT status FROM tracks WHERE id = ?", (t["track"],))[0] == "published"


def test_prerequisite_cycle_rejected(app, world):
    world.user("adm@x.com", "admin")
    t = world.track()
    a = app.test_client()
    login(a, "adm@x.com")
    post(a, f"/admin/conteudo/modulos/{t['ma']}/editar", {"title": "Módulo A", "prereqs": [str(t["mb"])]})
    assert world.one("SELECT COUNT(*) FROM module_prerequisites WHERE module_id = ?", (t["ma"],))[0] == 0


# ------------------------------------------------------------------ utilidades
def test_markdown_escapes_html():
    from app.markdown import render
    out = str(render("<script>alert(1)</script> **ok** [x](javascript:alert(1))\n\n| a | b |\n|---|---|\n| `x \\| y` | 2 |"))
    assert "<script>" not in out and "&lt;script&gt;" in out
    assert "javascript:" not in out and "<strong>ok</strong>" in out
    assert "<code>x | y</code>" in out


def test_csv_formula_injection_escaped():
    from app.services.reports import to_csv
    out = to_csv(["a"], [["=HYPERLINK(1)"]])
    assert "'=HYPERLINK" in out
