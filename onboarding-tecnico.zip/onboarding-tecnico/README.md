# Onboarding Técnico · Suporte PABX em nuvem

Plataforma web interna para capacitar novos colaboradores do suporte técnico de PABX em nuvem. Ela já vem com a trilha
**Onboarding Suporte N2 · WideVoice** (11 módulos, 66 aulas e 18 atividades com 46 questões), montada a partir do material de
onboarding existente.

- **Colaborador:** trilha com módulos e aulas, questionários, estudos de caso, simulações e atividades práticas, com
  progresso salvo na conta e retomada de onde parou.
- **Gestor e administrador:** cadastro de usuários, montagem e publicação de trilhas, correção de respostas abertas,
  acompanhamento individual e da equipe, relatórios e exportação em CSV.

## Sumário
1. [Funcionalidades](#funcionalidades)
2. [Tecnologias](#tecnologias)
3. [Executar localmente](#executar-localmente)
4. [Configurar o ambiente](#configurar-o-ambiente)
5. [Criar o primeiro administrador](#criar-o-primeiro-administrador)
6. [Publicar em produção](#publicar-em-produção)
7. [Testes](#testes)
8. [Limitações e próximos passos](#limitações-e-próximos-passos)

Detalhes de arquitetura, banco de dados e regras de negócio: [`docs/ARQUITETURA.md`](docs/ARQUITETURA.md).

## Funcionalidades

| Área | O que está implementado |
| --- | --- |
| Autenticação | Login por e-mail e senha (hash scrypt), sessão assinada (HttpOnly, SameSite), bloqueio temporário após 5 falhas, troca obrigatória da senha temporária no primeiro acesso e sessões encerradas ao trocar a senha ou desativar a conta. |
| Perfis | **Administrador** (tudo), **Gestor** (conteúdo e os colaboradores sob sua responsabilidade) e **Colaborador** (só os próprios dados). Todas as permissões são validadas no servidor. |
| Dashboard | Boas-vindas, % de conclusão calculado sobre as etapas obrigatórias, módulos concluídos e restantes, atividades pendentes, última atividade, próxima etapa recomendada, desempenho, evolução semanal e botão para continuar. Gestores veem também o resumo da equipe. |
| Minha trilha | Trilha › módulos › aulas e atividades. Cada módulo mostra descrição, objetivos, ordem, quantidade de conteúdos, %, situação, tempo estimado e pré-requisitos. Módulos com pré-requisito ficam bloqueados até a conclusão dos anteriores. |
| Aulas | Texto formatado, imagens, tabelas, código com botão de copiar, alertas, seções recolhíveis, vídeo ou link principal, materiais de apoio (arquivos protegidos e links) e atividade relacionada. Abrir a aula **não** conta como conclusão: a conclusão exige confirmação de leitura (com tempo mínimo opcional) ou aprovação na atividade vinculada. |
| Conteúdos técnicos | Biblioteca com busca em todas as aulas liberadas. |
| Atividades | Múltipla escolha (uma ou várias respostas), verdadeiro ou falso, resposta aberta, estudo de caso, simulação de atendimento, atividade prática com evidência (texto, link e arquivo) e avaliação final. Nota mínima, número de tentativas, rascunho, histórico de tentativas e gabarito conforme a regra de feedback. |
| Correção | Correção automática das objetivas. Abertas e práticas ficam “Aguardando correção” até o gestor registrar pontos, comentários e feedback. |
| Acompanhamento | Painel da equipe com filtros por nome, situação, trilha, período de início e faixa de progresso. Identifica quem não iniciou, progride normalmente, aguarda correção, está abaixo da nota mínima, precisa de acompanhamento ou concluiu. Página individual com histórico completo. |
| Gestão de conteúdo | Criar, editar, reordenar, ativar e desativar trilhas, módulos, aulas, materiais, atividades e questões, definir pré-requisitos (com bloqueio de ciclos), validar e publicar. |
| Relatórios | Indicadores da trilha, situação dos colaboradores, conclusão por módulo, módulos e questões com mais erros e exportação de colaboradores e tentativas em CSV, sempre limitados ao que o usuário pode ver. |
| Auditoria | Registro das ações administrativas (cadastros, conteúdo, publicações, correções e exportações). |

## Tecnologias

- **Python 3.11+ e Flask 3.1**, com páginas renderizadas no servidor (Jinja2) e JavaScript leve, sem etapa de build.
- **SQLite** (banco relacional) em modo WAL, com migrações SQL versionadas em `migrations/`.
- **CSS próprio** com tokens da paleta Intelbras, ícones SVG próprios e nenhuma dependência de CDN, compatível com a
  política de segurança de conteúdo (CSP).
- **pytest** para as regras de negócio e **Playwright** para os fluxos no navegador.

A escolha privilegia uma stack pequena e estável, de fácil manutenção, que roda em qualquer servidor Linux.
O caminho para usar PostgreSQL está descrito em [`docs/ARQUITETURA.md`](docs/ARQUITETURA.md#postgresql).

## Executar localmente

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                     # ajuste se quiser

flask --app wsgi create-admin                            # pede e-mail, nome e senha
flask --app wsgi seed-content                            # carrega a trilha WideVoice já publicada
flask --app wsgi seed-demo                               # opcional: gestora e 5 colaboradores de demonstração
flask --app wsgi run --port 5000
```

Acesse `http://127.0.0.1:5000`. O banco é criado e migrado automaticamente na primeira execução, em `instance/`.

**Dados de demonstração.** O `seed-demo` cria `gestora.demo@exemplo.com` e cinco colaboradores (`ana`, `bruno`,
`carla`, `diego` e `elisa`, todos `.demo@exemplo.com`) com a senha `Demo2026onboarding` e progresso simulado. Eles
aparecem com o selo **Demo** em toda a plataforma e os relatórios avisam quando estão incluídos. Para removê-los,
use `flask --app wsgi remove-demo`.

## Configurar o ambiente

Todas as variáveis estão em `.env.example`. As principais são:

| Variável | Uso |
| --- | --- |
| `APP_ENV` | `production` exige `SECRET_KEY`, ativa o cookie seguro (HTTPS) e o HSTS. |
| `SECRET_KEY` | Chave de assinatura da sessão. Gere com `python -c "import secrets; print(secrets.token_hex(32))"`. |
| `DATABASE_PATH`, `UPLOAD_DIR` | Banco e arquivos enviados. Em produção, aponte para um volume persistente com backup. |
| `LOGO_FILE` | Caminho, dentro de `app/static/`, do **arquivo oficial** do logotipo. Enquanto estiver vazio, a interface mostra apenas o nome da plataforma. |
| `PACE_TOLERANCE_POINTS`, `INACTIVITY_ALERT_DAYS` | Critérios do alerta “Precisa de acompanhamento”. |

**Cores.** A paleta segue o brandbook da Intelbras: Verde Institucional `#06CB3F` como cor principal, mais Verde
Revendas, Verde Grandes Projetos e cinzas. Para usar outra cor principal, altere apenas os tokens `--brand*` no
início de `app/static/css/app.css`.

## Criar o primeiro administrador

```bash
flask --app wsgi create-admin --email voce@empresa.com --name "Seu Nome"
```

A senha é pedida de forma oculta e precisa ter pelo menos 10 caracteres, misturando letras e números ou símbolos.
Se o e-mail já existir, o usuário é promovido a administrador. Os demais usuários são criados pela interface, em
**Usuários › Novo usuário**. A plataforma gera uma senha temporária, exibida uma única vez, e o usuário a troca no
primeiro acesso.

## Publicar em produção

1. Servidor Linux com Python 3.11+ e um proxy HTTPS (Nginx, Caddy ou o balanceador da infraestrutura).
2. `pip install -r requirements.txt`, criar o `.env` com `APP_ENV=production`, um `SECRET_KEY` forte e
   `DATABASE_PATH`/`UPLOAD_DIR` em disco persistente.
3. `flask --app wsgi db-migrate`, depois `create-admin` e `seed-content`.
4. Iniciar com `gunicorn -w 3 -b 127.0.0.1:8000 wsgi:app` (via systemd, por exemplo) e encaminhar o HTTPS do proxy
   para essa porta. Defina no proxy um limite de upload compatível com `MAX_UPLOAD_MB`.
5. Backup: copie o arquivo do banco com `sqlite3 onboarding.db ".backup backup.db"` (seguro com a aplicação no ar) e
   copie a pasta de uploads.
6. Há um `Dockerfile` de referência, com volume em `/data`. Ele não foi testado no ambiente de desenvolvimento.

Para atualizar a aplicação, publique o código novo e rode `flask --app wsgi db-migrate`. As migrações são aplicadas em
ordem e registradas na tabela `schema_migrations`.

## Testes

```bash
python -m pytest -q tests                                  # 21 testes de regras e permissões
# fluxos no navegador (servidor rodando com dados de demonstração recém-criados):
python tests/e2e_browser.py http://127.0.0.1:5000 e2e_shots
```

Os testes automatizados cobrem:
- bloqueio por tentativas de login, revogação de sessão de conta desativada, CSRF e troca obrigatória de senha;
- bloqueio da área administrativa para colaboradores e escopo do gestor (detalhe, CSV e edição);
- isolamento das tentativas entre colaboradores;
- diferença entre acesso e conclusão, pré-requisitos e trilha em rascunho;
- correção automática, nota mínima, limite de tentativas e rascunho preservado;
- correção manual (incluindo a validação dos pontos);
- nova versão ao editar uma atividade, preservando as notas antigas;
- conteúdo desativado e exclusão bloqueada quando há histórico;
- persistência entre sessões e dispositivos, validação antes de publicar e bloqueio de ciclos de pré-requisito;
- Markdown seguro e proteção contra fórmulas no CSV.

O teste no navegador percorre o celular (menu, aula, rascunho, envio com confirmação e resultado), a correção feita
pela gestora e o cadastro de um colaborador com troca de senha no primeiro acesso.

## Limitações e próximos passos

- **Banco:** SQLite atende bem a um time interno (dezenas a poucas centenas de usuários) com um único servidor de
  aplicação. Para vários servidores ou alta concorrência, migre para PostgreSQL ([guia](docs/ARQUITETURA.md#postgresql)).
  Essa migração não foi implementada nem testada.
- **Recuperação de senha por e-mail:** não implementada, porque depende de um servidor SMTP. Hoje a senha é
  redefinida pelo gestor ou administrador.
- **SSO corporativo** (Azure AD, Google Workspace): não implementado.
- **Logotipo:** o arquivo oficial não foi fornecido. Configure `LOGO_FILE` quando ele estiver disponível.
- **Arquivos:** ficam no disco do servidor. Para armazenamento em nuvem (S3 ou similar), é preciso adaptar
  `save_upload` e a rota `files`.
- **Correções registradas** não podem ser editadas, por decisão de segurança das notas. Se for preciso, adicione um
  fluxo de revisão auditado.
- **Conteúdo:** seis páginas do onboarding original ainda não foram incorporadas (Hangup, Verificação de Bloqueio,
  Acessar outro Wide via SSH, Salvar e Baixar PCAP, Logs no WireShark e a seção “Identificando Problemas”).
- **Docker:** o `Dockerfile` é uma referência e não foi testado.
