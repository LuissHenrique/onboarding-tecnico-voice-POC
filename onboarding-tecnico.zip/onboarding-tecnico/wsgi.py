"""Ponto de entrada WSGI: `gunicorn wsgi:app` em produção ou `flask --app wsgi run` em desenvolvimento."""
from dotenv import load_dotenv

load_dotenv()

from app import create_app  # noqa: E402

app = create_app()
